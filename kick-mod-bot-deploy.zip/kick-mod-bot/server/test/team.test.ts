import { describe, it, expect, beforeEach } from 'vitest';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import Database from 'better-sqlite3';
import { BotDb } from '../src/db.js';
import { resolvePrincipal, can, ALL_PERMISSIONS } from '../src/principal.js';
import { cfg, cfgWithGoogle } from './helpers.js';

let db: BotDb;
beforeEach(() => {
  db = new BotDb(':memory:');
});

describe('team storage', () => {
  it('adds by lowercase username and rejects duplicates', () => {
    const m = db.addTeamMember('Ahmed_Mod', ['log.view']);
    expect(m).toMatchObject({ username: 'ahmed_mod', kickUserId: null, permissions: ['log.view'] });
    expect(db.addTeamMember('AHMED_MOD', ['log.view'])).toBe('duplicate');
  });

  it('binds a username to a user id once', () => {
    db.addTeamMember('ahmed', ['log.view']);
    expect(db.bindTeamMember('Ahmed', 55, 'pic.png')).toMatchObject({ kickUserId: 55, picture: 'pic.png' });
    expect(db.findTeamByUserId(55)?.username).toBe('ahmed');
    expect(db.bindTeamMember('ahmed', 66, null)).toBeNull();
  });

  it('updates permissions and removes', () => {
    const m = db.addTeamMember('sara', ['log.view']);
    if (m === 'duplicate') throw new Error();
    expect(db.updateTeamPermissions(m.id, ['lists.word'])).toBe(true);
    expect(db.getTeamMember(m.id)?.permissions).toEqual(['lists.word']);
    expect(db.removeTeamMember(m.id)).toBe(true);
    expect(db.removeTeamMember(m.id)).toBe(false);
    expect(db.updateTeamPermissions(m.id, [])).toBe(false);
  });

  it('suggestions are seen mods not on the team', () => {
    db.upsertSeenMod({ id: 1, username: 'modA', picture: null });
    db.upsertSeenMod({ id: 2, username: 'modB', picture: 'b.png' });
    db.addTeamMember('moda', ['log.view'], 1);
    expect(db.listSuggestions().map((s) => s.username)).toEqual(['modB']);
  });

  it('a corrupt audit detail does not break the listing', () => {
    const file = join(mkdtempSync(join(tmpdir(), 'kmb-audit-')), 'bot.db');
    const fileDb = new BotDb(file);
    fileDb.insertAudit({ actorSub: 'kick:1', actorName: 'm', actorPicture: null, action: 'bot.link', detail: {} });
    const raw = new Database(file);
    raw.prepare(`UPDATE audit SET detail = '{broken'`).run();
    raw.close();
    expect(fileDb.listAudit({ page: 1, pageSize: 5 }).rows[0]!.detail).toEqual({});
  });

  it('audit log lists newest first and prunes', () => {
    db.insertAudit({ actorSub: 'kick:1', actorName: 'mansourko', actorPicture: null, action: 'entry.add', detail: { kind: 'word', values: ['x'] } }, '2026-11-01T00:00:00.000Z');
    db.insertAudit({ actorSub: 'kick:1', actorName: 'mansourko', actorPicture: null, action: 'team.add', detail: { username: 'a' } }, '2026-11-06T00:00:00.000Z');
    const r = db.listAudit({ page: 1, pageSize: 10 });
    expect(r.total).toBe(2);
    expect(r.rows[0]).toMatchObject({ action: 'team.add', detail: { username: 'a' } });
    expect(db.pruneAudit(new Date('2026-12-05T00:00:00.000Z'))).toBe(1);
  });
});

describe('resolvePrincipal', () => {
  it('owner by Kick username (case-insensitive)', () => {
    db.upsertUser({ id: 7, username: 'Mansourko', picture: 'me.png' });
    const p = resolvePrincipal(cfg, db, 'kick:7');
    expect(p).toMatchObject({ kind: 'owner', name: 'Mansourko', picture: 'me.png' });
    expect(p!.permissions).toEqual(ALL_PERMISSIONS);
  });

  it('once the owner id is pinned, the username alone no longer makes an owner', () => {
    db.setOwnerKickUserId(7);
    db.upsertUser({ id: 7, username: 'Mansourko', picture: null });
    db.upsertUser({ id: 8, username: 'mansourko', picture: null });
    expect(resolvePrincipal(cfg, db, 'kick:7')?.kind).toBe('owner');
    expect(resolvePrincipal(cfg, db, 'kick:8')).toBeNull();
  });

  it('a mod who renames to the owner name stays a mod after the owner is pinned', () => {
    db.setOwnerKickUserId(7);
    db.upsertUser({ id: 9, username: 'mansourko', picture: null });
    db.addTeamMember('ahmed', ['log.view'], 9);
    expect(resolvePrincipal(cfg, db, 'kick:9')).toMatchObject({ kind: 'mod', permissions: ['log.view'] });
  });

  it('mod by bound team row', () => {
    db.upsertUser({ id: 9, username: 'ahmed', picture: null });
    db.addTeamMember('ahmed', ['lists.word'], 9);
    const p = resolvePrincipal(cfg, db, 'kick:9');
    expect(p).toMatchObject({ kind: 'mod', permissions: ['lists.word'] });
    expect(can(p!, 'lists.word')).toBe(true);
    expect(can(p!, 'lists.name')).toBe(false);
  });

  it('unknown or removed user -> null', () => {
    db.upsertUser({ id: 9, username: 'ahmed', picture: null });
    expect(resolvePrincipal(cfg, db, 'kick:9')).toBeNull();
    expect(resolvePrincipal(cfg, db, 'kick:404')).toBeNull();
    expect(resolvePrincipal(cfg, db, 'garbage')).toBeNull();
  });

  it('google owner only with google configured and matching email', () => {
    expect(resolvePrincipal(cfg, db, 'google:owner@gmail.com')).toBeNull();
    expect(resolvePrincipal(cfgWithGoogle, db, 'google:owner@gmail.com')).toMatchObject({ kind: 'owner' });
    expect(resolvePrincipal(cfgWithGoogle, db, 'google:other@gmail.com')).toBeNull();
  });
});
