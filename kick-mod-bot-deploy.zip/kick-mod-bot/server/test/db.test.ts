import { describe, it, expect, beforeEach } from 'vitest';
import { BotDb } from '../src/db.js';

let db: BotDb;
beforeEach(() => { db = new BotDb(':memory:'); });

const del = (i: number) => ({
  messageId: `m${i}`, senderId: 1, senderUsername: 'u', content: 'x', entryValue: 'حمار', entryKind: 'word' as const, status: 'deleted' as const, error: null,
});

describe('BotDb entries', () => {
  it('adds, normalizes, skips empty and duplicates', () => {
    db.addEntries('word', ['حمار'], 'word');
    const r = db.addEntries('word', ['حمااار', '!!!', 'كلب'], 'word');
    expect(r.added.map((x) => x.value)).toEqual(['كلب']);
    expect(r.added[0]!.normalized).toBe('كلب');
    expect(r.skipped).toEqual([{ value: 'حمااار', reason: 'duplicate' }, { value: '!!!', reason: 'empty' }]);
  });
  it('skips duplicates inside the same batch', () => {
    const r = db.addEntries('word', ['كلب', 'كلب'], 'word');
    expect(r.added).toHaveLength(1);
    expect(r.skipped).toEqual([{ value: 'كلب', reason: 'duplicate' }]);
  });
  it('same value allowed in different kinds', () => {
    db.addEntries('word', ['x1'], 'word');
    expect(db.addEntries('name', ['x1'], 'word').added).toHaveLength(1);
  });
  it('lists by kind and deletes', () => {
    db.addEntries('word', ['a1'], 'word');
    const [n] = db.addEntries('name', ['b2'], 'contains').added;
    expect(db.listEntries('name').map((x) => [x.value, x.mode])).toEqual([['b2', 'contains']]);
    expect(db.listEntries()).toHaveLength(2);
    expect(db.deleteEntry(n!.id)).toBe(true);
    expect(db.deleteEntry(n!.id)).toBe(false);
  });
});

describe('BotDb settings/tokens', () => {
  it('settings default true', () => {
    expect(db.getSetting('enabled')).toBe(true);
    expect(db.getSetting('exempt_mods')).toBe(true);
    db.setSetting('enabled', false);
    expect(db.getSetting('enabled')).toBe(false);
  });
  it('tokens roundtrip', () => {
    const t = { accessToken: 'a', refreshToken: 'r', expiresAt: 1, scope: 's', kickUserId: 5, kickUsername: 'm' };
    db.saveTokens(t);
    expect(db.getTokens()).toEqual(t);
    db.saveTokens({ ...t, accessToken: 'b' });
    expect(db.getTokens()!.accessToken).toBe('b');
    db.clearTokens();
    expect(db.getTokens()).toBeNull();
  });
});

describe('BotDb deletions', () => {
  it('lists newest first with user filter and counts deleted only', () => {
    db.insertDeletion({ ...del(1), senderUsername: 'Ahmed' }, '2026-11-06T10:00:00.000Z');
    db.insertDeletion({ ...del(2), senderUsername: 'sara', status: 'failed', error: 'x' }, '2026-11-06T11:00:00.000Z');
    const all = db.listDeletions({ page: 1, pageSize: 10 });
    expect(all.total).toBe(2);
    expect(all.rows[0]!.messageId).toBe('m2');
    expect(db.listDeletions({ page: 1, pageSize: 10, user: 'ahm' }).rows.map((r) => r.messageId)).toEqual(['m1']);
    expect(db.countDeletionsSince('2026-11-06T00:00:00.000Z')).toBe(1);
  });
  it('prunes old and over-limit', () => {
    const now = new Date('2026-11-06T12:00:00.000Z');
    db.insertDeletion(del(0), new Date(now.getTime() - 31 * 86400_000).toISOString());
    for (let i = 1; i <= 5002; i++) db.insertDeletion(del(i), new Date(now.getTime() - 5002_000 + i * 1000).toISOString());
    expect(db.pruneDeletions(now)).toBe(3);
    const r = db.listDeletions({ page: 1, pageSize: 1 });
    expect(r.total).toBe(5000);
    expect(r.rows[0]!.messageId).toBe('m5002');
  });
  it('seeds the allow list too', () => {
    expect(db.seedIfEmpty(['a1'], ['خولة'])).toBe(2);
    expect(db.listEntries('allow').map((e) => e.value)).toEqual(['خولة']);
  });
  it('seeds once only', () => {
    expect(db.seedIfEmpty(['a1', 'b2'])).toBe(2);
    db.deleteEntry(1);
    expect(db.seedIfEmpty(['a1'])).toBe(0);
  });
});
