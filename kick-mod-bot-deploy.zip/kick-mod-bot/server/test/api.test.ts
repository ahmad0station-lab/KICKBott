import { describe, it, expect, vi } from 'vitest';
import { KickClient } from '../src/kick/api.js';
import { BotDb } from '../src/db.js';
import { createStatus } from '../src/status.js';
import { cfg, empty, fakeFetch, freshTokens, json, tokenBody } from './helpers.js';

function setup(responses: Parameters<typeof fakeFetch>, tokens = freshTokens()) {
  const db = new BotDb(':memory:');
  if (tokens) db.saveTokens(tokens);
  const status = createStatus(db);
  const fetchFn = fakeFetch(...responses);
  const sleep = vi.fn(async (_ms: number) => {});
  const client = new KickClient({ cfg, db, status, fetchFn, sleep });
  return { db, status, fetchFn, sleep, client };
}

describe('KickClient', () => {
  it('no tokens -> not_logged_in, no fetch', async () => {
    const db = new BotDb(':memory:');
    const fetchFn = fakeFetch();
    const status = createStatus(db);
    expect(status.auth).toBe('needs_login');
    const client = new KickClient({ cfg, db, status, fetchFn });
    expect(await client.deleteMessage('m1')).toEqual({ ok: false, status: 0, error: 'not_logged_in' });
    expect(fetchFn).not.toHaveBeenCalled();
  });

  it('DELETE /public/v1/chat/m1 with bearer, 204 -> ok', async () => {
    const { client, fetchFn, status } = setup([empty(204)]);
    expect(status.auth).toBe('connected');
    expect(await client.deleteMessage('m1')).toEqual({ ok: true, data: null });
    expect(fetchFn.url(0)).toBe('https://api.kick.com/public/v1/chat/m1');
    expect(fetchFn.init(0).method).toBe('DELETE');
    expect(new Headers(fetchFn.init(0).headers).get('authorization')).toBe('Bearer a');
  });

  it('refreshes proactively when <5min left and keeps account info', async () => {
    const { client, fetchFn, db } = setup([json(tokenBody('a2', 'r2')), empty(204)], freshTokens({ expiresAt: Date.now() + 60_000 }));
    expect((await client.deleteMessage('m1')).ok).toBe(true);
    expect(fetchFn.url(0)).toBe('https://id.kick.com/oauth/token');
    expect(new Headers(fetchFn.init(1).headers).get('authorization')).toBe('Bearer a2');
    expect(db.getTokens()).toMatchObject({ accessToken: 'a2', refreshToken: 'r2', kickUserId: 7, kickUsername: 'mansourko' });
  });

  it('401 -> refresh once -> retry', async () => {
    const { client, fetchFn } = setup([empty(401), json(tokenBody()), empty(204)]);
    expect((await client.deleteMessage('m1')).ok).toBe(true);
    expect(fetchFn).toHaveBeenCalledTimes(3);
  });

  it('401 twice -> needs_login', async () => {
    const { client, status } = setup([empty(401), json(tokenBody()), empty(401)]);
    const r = await client.deleteMessage('m1');
    expect(r).toMatchObject({ ok: false, status: 401 });
    expect(status.auth).toBe('needs_login');
  });

  it('failed refresh -> needs_login', async () => {
    const { client, status } = setup([empty(401), json({ error: 'invalid_grant' }, 400)]);
    expect(await client.deleteMessage('m1')).toMatchObject({ ok: false, status: 401 });
    expect(status.auth).toBe('needs_login');
  });

  it('concurrent 401s share one refresh', async () => {
    const { client, fetchFn } = setup([empty(401), empty(401), json(tokenBody()), empty(204), empty(204)]);
    const [a, b] = await Promise.all([client.deleteMessage('m1'), client.deleteMessage('m2')]);
    expect(a.ok && b.ok).toBe(true);
    const refreshCalls = fetchFn.mock.calls.filter((c) => String(c[0]).includes('id.kick.com'));
    expect(refreshCalls).toHaveLength(1);
  });

  it('429 retried up to 3 attempts with sleep', async () => {
    const { client, sleep } = setup([empty(429), new Response(null, { status: 429, headers: { 'retry-after': '2' } }), empty(204)]);
    expect((await client.deleteMessage('m1')).ok).toBe(true);
    expect(sleep.mock.calls.map((c) => c[0])).toEqual([1000, 2000]);
  });

  it('429 three times -> fails', async () => {
    const { client } = setup([empty(429), empty(429), empty(429)]);
    expect(await client.deleteMessage('m1')).toMatchObject({ ok: false, status: 429 });
  });

  it('403 -> error body surfaced', async () => {
    const { client } = setup([json({ message: 'Forbidden: not a moderator' }, 403)]);
    expect(await client.deleteMessage('m1')).toEqual({ ok: false, status: 403, error: 'Forbidden: not a moderator' });
    const { client: c2 } = setup([empty(404)]);
    expect(await c2.deleteMessage('m1')).toEqual({ ok: false, status: 404, error: 'HTTP 404' });
  });

  it('network error -> status 0', async () => {
    const { client } = setup([() => { throw new Error('ECONNRESET'); }]);
    expect(await client.deleteMessage('m1')).toEqual({ ok: false, status: 0, error: 'ECONNRESET' });
  });

  it('getCurrentUser returns data[0]', async () => {
    const { client, fetchFn } = setup([json({ data: [{ user_id: 7, name: 'mansourko' }], message: 'OK' })]);
    expect(await client.getCurrentUser()).toEqual({ ok: true, data: { user_id: 7, name: 'mansourko' } });
    expect(fetchFn.url(0)).toBe('https://api.kick.com/public/v1/users');
  });

  it('createChatSubscription body', async () => {
    const { client, fetchFn } = setup([json({ data: [{ name: 'chat.message.sent', version: 1, subscription_id: 's1' }] })]);
    const r = await client.createChatSubscription();
    expect(r).toEqual({ ok: true, data: [{ name: 'chat.message.sent', version: 1, subscription_id: 's1' }] });
    expect(fetchFn.url(0)).toBe('https://api.kick.com/public/v1/events/subscriptions');
    expect(fetchFn.init(0).method).toBe('POST');
    expect(JSON.parse(String(fetchFn.init(0).body))).toEqual({ events: [{ name: 'chat.message.sent', version: 1 }], method: 'webhook' });
  });

  it('listSubscriptions returns data', async () => {
    const { client } = setup([json({ data: [{ id: 's1', event: 'chat.message.sent', method: 'webhook', version: 1 }] })]);
    expect(await client.listSubscriptions()).toEqual({ ok: true, data: [{ id: 's1', event: 'chat.message.sent', method: 'webhook', version: 1 }] });
  });
});
