import { describe, it, expect } from 'vitest';
import { loadConfig } from '../src/config.js';

const base = { KICK_CLIENT_ID: 'id', KICK_CLIENT_SECRET: 'sec', PUBLIC_URL: 'https://x.up.railway.app/', OWNER_KICK_USERNAME: 'Mansourko', SESSION_SECRET: 'a'.repeat(32) };
const google = { GOOGLE_CLIENT_ID: 'gid', GOOGLE_CLIENT_SECRET: 'gsec', OWNER_EMAIL: 'Owner@Gmail.com' };

describe('loadConfig', () => {
  it('parses and normalizes', () => {
    const c = loadConfig(base);
    expect(c.publicUrl).toBe('https://x.up.railway.app');
    expect(c.dataDir).toBe('/data');
    expect(c.port).toBe(3000);
    expect(c.secureCookies).toBe(true);
    expect(c.ownerKickUsername).toBe('mansourko');
    expect(c.google).toBeNull();
  });
  it('localhost disables secure cookies', () => {
    expect(loadConfig({ ...base, PUBLIC_URL: 'http://localhost:3000' }).secureCookies).toBe(false);
  });
  it('requires OWNER_KICK_USERNAME', () => {
    const { OWNER_KICK_USERNAME: _omit, ...rest } = base;
    expect(() => loadConfig(rest)).toThrow(/OWNER_KICK_USERNAME/);
  });
  it('google config: all three or none', () => {
    expect(loadConfig({ ...base, ...google }).google).toEqual({ clientId: 'gid', clientSecret: 'gsec', ownerEmail: 'owner@gmail.com' });
    expect(() => loadConfig({ ...base, GOOGLE_CLIENT_ID: 'gid' })).toThrow(/GOOGLE/);
  });
  it('rejects short SESSION_SECRET', () => {
    expect(() => loadConfig({ ...base, SESSION_SECRET: 'short' })).toThrow(/SESSION_SECRET/);
  });
});
