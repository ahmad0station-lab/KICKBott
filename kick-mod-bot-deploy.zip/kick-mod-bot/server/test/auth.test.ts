import { describe, it, expect, vi, beforeEach, type Mock } from 'vitest';
import { authRoutes } from '../src/routes/auth.js';
import { BotDb } from '../src/db.js';
import { createStatus, type BotStatus } from '../src/status.js';
import { SESSION_COOKIE, signSession, verifySession } from '../src/session.js';
import type { KickClient } from '../src/kick/api.js';
import type { exchangeCode } from '../src/kick/oauth.js';
import type { Config } from '../src/config.js';
import type { KickProfile } from '../src/types.js';
import { cfg, cfgWithGoogle, freshTokens, json } from './helpers.js';

const tokens = { accessToken: 'NEW', refreshToken: 'R', expiresAt: Date.now() + 3600_000, scope: 's', kickUserId: null, kickUsername: null };

let db: BotDb;
let status: BotStatus;
let client: { listSubscriptions: Mock<KickClient['listSubscriptions']>; createChatSubscription: Mock<KickClient['createChatSubscription']> };
let exchange: Mock<typeof exchangeCode>;
let fetchUser: Mock<(token: string) => Promise<KickProfile>>;
let googleFetch: Mock<typeof fetch>;

function makeApp(config: Config = cfg) {
  return authRoutes({ cfg: config, db, client, status, exchange, fetchUser, fetchFn: googleFetch });
}

const cookieOf = (r: Response, name: string) =>
  (r.headers.getSetCookie?.() ?? [r.headers.get('set-cookie') ?? '']).map((c) => c.split(';')[0]!).find((c) => c.startsWith(`${name}=`));

async function start(app: ReturnType<typeof makeApp>, path: string, cookie = '') {
  const r = await app.request(path, { headers: cookie ? { cookie } : {} });
  const loc = new URL(r.headers.get('location')!);
  return { r, loc, oauth: cookieOf(r, path.startsWith('/auth/google') ? 'kmb_google' : 'kmb_oauth')! };
}

async function kickCallback(app: ReturnType<typeof makeApp>, state: string, cookie: string) {
  return app.request(`/auth/kick/callback?code=C&state=${state}`, { headers: { cookie } });
}

const ownerSession = () => {
  db.upsertUser({ id: 7, username: 'Mansourko', picture: null });
  return `${SESSION_COOKIE}=${signSession(cfg.sessionSecret, 'kick:7', Date.now() + 60_000)}`;
};

beforeEach(() => {
  db = new BotDb(':memory:');
  status = createStatus(db);
  client = {
    listSubscriptions: vi.fn<KickClient['listSubscriptions']>(async () => ({ ok: true, data: [] })),
    createChatSubscription: vi.fn<KickClient['createChatSubscription']>(async () => ({ ok: true, data: [{ subscription_id: 's1' }] })),
  };
  exchange = vi.fn<typeof exchangeCode>(async () => ({ ...tokens }));
  fetchUser = vi.fn(async () => ({ id: 7, username: 'Mansourko', picture: 'me.png' }));
  googleFetch = vi.fn<typeof fetch>();
});

describe('kick login', () => {
  it('asks Kick for user:read only', async () => {
    const { r, loc, oauth } = await start(makeApp(), '/auth/kick/login');
    expect(r.status).toBe(302);
    expect(loc.origin + loc.pathname).toBe('https://id.kick.com/oauth/authorize');
    expect(loc.searchParams.get('scope')).toBe('user:read');
    expect(oauth).toMatch(/^kmb_oauth=login\./);
  });

  it('owner login sets a kick:<id> session and does not touch bot tokens', async () => {
    const app = makeApp();
    const { loc, oauth } = await start(app, '/auth/kick/login');
    const r = await kickCallback(app, loc.searchParams.get('state')!, oauth);
    expect(r.headers.get('location')).toBe('/');
    const session = cookieOf(r, SESSION_COOKIE)!.split('=')[1];
    expect(verifySession(cfg.sessionSecret, session, Date.now())).toBe('kick:7');
    expect(db.getUser(7)).toEqual({ id: 7, username: 'Mansourko', picture: 'me.png' });
    expect(db.getTokens()).toBeNull();
  });

  it('first owner login pins the owner id; a later account with the same name is denied', async () => {
    const app = makeApp();
    let s = await start(app, '/auth/kick/login');
    await kickCallback(app, s.loc.searchParams.get('state')!, s.oauth);
    expect(db.getOwnerKickUserId()).toBe(7);
    fetchUser.mockResolvedValueOnce({ id: 8, username: 'Mansourko', picture: null });
    s = await start(app, '/auth/kick/login');
    const r = await kickCallback(app, s.loc.searchParams.get('state')!, s.oauth);
    expect(r.headers.get('location')).toBe('/?login=denied');
  });

  it('team member logging in for the first time gets bound', async () => {
    db.addTeamMember('ahmed', ['log.view']);
    fetchUser.mockResolvedValueOnce({ id: 55, username: 'Ahmed', picture: 'a.png' });
    const app = makeApp();
    const { loc, oauth } = await start(app, '/auth/kick/login');
    const r = await kickCallback(app, loc.searchParams.get('state')!, oauth);
    expect(r.headers.get('location')).toBe('/');
    expect(db.findTeamByUserId(55)?.username).toBe('ahmed');
  });

  it('stranger is denied without a session', async () => {
    fetchUser.mockResolvedValueOnce({ id: 99, username: 'random', picture: null });
    const app = makeApp();
    const { loc, oauth } = await start(app, '/auth/kick/login');
    const r = await kickCallback(app, loc.searchParams.get('state')!, oauth);
    expect(r.headers.get('location')).toBe('/?login=denied');
    expect(cookieOf(r, SESSION_COOKIE)?.split('=')[1] ?? '').toBe('');
    expect(db.getUser(99)).toBeNull();
  });

  it('wrong state -> /?login=failed', async () => {
    const app = makeApp();
    const { oauth } = await start(app, '/auth/kick/login');
    const r = await kickCallback(app, 'WRONG', oauth);
    expect(r.headers.get('location')).toBe('/?login=failed');
    expect(exchange).not.toHaveBeenCalled();
  });
});

describe('kick bot link', () => {
  it('requires the owner (signed-out link click goes back to the dashboard)', async () => {
    const out = await makeApp().request('/auth/kick/link');
    expect(out.status).toBe(302);
    expect(out.headers.get('location')).toBe('/?linked=0#settings');
    db.upsertUser({ id: 9, username: 'ahmed', picture: null });
    db.addTeamMember('ahmed', ['bot.control'], 9);
    const mod = `${SESSION_COOKIE}=${signSession(cfg.sessionSecret, 'kick:9', Date.now() + 60_000)}`;
    expect((await makeApp().request('/auth/kick/link', { headers: { cookie: mod } })).status).toBe(403);
  });

  it('owner links bot with moderation scopes, saves tokens, subscribes, audits', async () => {
    const session = ownerSession();
    fetchUser.mockResolvedValueOnce({ id: 300, username: 'MansourkoBot', picture: null });
    const app = makeApp();
    const { loc, oauth } = await start(app, '/auth/kick/link', session);
    expect(loc.searchParams.get('scope')).toBe('user:read events:subscribe moderation:chat_message:manage');
    const r = await kickCallback(app, loc.searchParams.get('state')!, `${session}; ${oauth}`);
    expect(r.headers.get('location')).toBe('/?linked=1#settings');
    expect(db.getTokens()).toMatchObject({ accessToken: 'NEW', kickUserId: 300, kickUsername: 'MansourkoBot' });
    expect(status.account).toEqual({ id: 300, username: 'MansourkoBot' });
    expect(client.createChatSubscription).toHaveBeenCalled();
    expect(db.listAudit({ page: 1, pageSize: 5 }).rows[0]).toMatchObject({ action: 'bot.link', actorName: 'Mansourko', detail: { username: 'MansourkoBot' } });
  });

  it('failed re-link keeps the working tokens', async () => {
    db.saveTokens(freshTokens({ accessToken: 'OLD' }));
    const session = ownerSession();
    exchange.mockRejectedValueOnce(new Error('bad code'));
    const app = makeApp();
    const { loc, oauth } = await start(app, '/auth/kick/link', session);
    const r = await kickCallback(app, loc.searchParams.get('state')!, `${session}; ${oauth}`);
    expect(r.headers.get('location')).toBe('/?linked=0#settings');
    expect(db.getTokens()?.accessToken).toBe('OLD');
  });
});

describe('google fallback', () => {
  it('404 when google is not configured', async () => {
    expect((await makeApp().request('/auth/google/login')).status).toBe(404);
  });

  it('redirects to google with pkce', async () => {
    const { loc, oauth } = await start(makeApp(cfgWithGoogle), '/auth/google/login');
    expect(loc.origin + loc.pathname).toBe('https://accounts.google.com/o/oauth2/v2/auth');
    expect(loc.searchParams.get('scope')).toBe('openid email');
    expect(loc.searchParams.get('code_challenge_method')).toBe('S256');
    expect(loc.searchParams.get('redirect_uri')).toBe('https://x.up.railway.app/auth/google/callback');
    expect(oauth).toMatch(/^kmb_google=/);
  });

  async function googleLogin(userinfo: unknown) {
    googleFetch.mockResolvedValueOnce(json({ access_token: 'g-at' })).mockResolvedValueOnce(json(userinfo));
    const app = makeApp(cfgWithGoogle);
    const { loc, oauth } = await start(app, '/auth/google/login');
    return app.request(`/auth/google/callback?code=G&state=${loc.searchParams.get('state')}`, { headers: { cookie: oauth } });
  }

  it('verified owner email -> session google:<email>', async () => {
    const r = await googleLogin({ email: 'Owner@gmail.com', email_verified: true });
    expect(r.headers.get('location')).toBe('/');
    expect(verifySession(cfg.sessionSecret, cookieOf(r, SESSION_COOKIE)!.split('=')[1], Date.now())).toBe('google:owner@gmail.com');
    expect(String(googleFetch.mock.calls[0]![0])).toBe('https://oauth2.googleapis.com/token');
    expect(String(googleFetch.mock.calls[1]![0])).toBe('https://openidconnect.googleapis.com/v1/userinfo');
  });

  it('unverified or other email -> denied', async () => {
    expect((await googleLogin({ email: 'owner@gmail.com', email_verified: false })).headers.get('location')).toBe('/?login=denied');
    expect((await googleLogin({ email: 'x@gmail.com', email_verified: true })).headers.get('location')).toBe('/?login=denied');
  });
});
