import { describe, it, expect, vi } from 'vitest';
import { webhookRoutes } from '../src/routes/webhook.js';
import { RecentIds } from '../src/recentIds.js';
import type { BotStatus } from '../src/status.js';

const NOW = Date.parse('2026-11-06T12:00:00.000Z');
const body = JSON.stringify({ message_id: 'm1', content: 'x', sender: { user_id: 2 }, broadcaster: { user_id: 1 } });

function setup(verifyResult = true) {
  const verify = vi.fn(async () => verifyResult);
  const handle = vi.fn(async () => 'clean' as const);
  const log = { error: vi.fn() };
  const status: BotStatus = { auth: 'connected', account: null, subscription: { ok: true, checkedAt: null, error: null }, lastEventAt: null };
  const app = webhookRoutes({ verifier: { verify }, moderator: { handle }, status, recent: new RecentIds(15 * 60_000, 10_000, () => NOW), now: () => NOW, log });
  return { app, verify, handle, log };
}

const headers = (over: Record<string, string> = {}) => ({
  'Kick-Event-Message-Id': '01J1',
  'Kick-Event-Message-Timestamp': '2026-11-06T11:59:00Z',
  'Kick-Event-Signature': 'c2ln',
  'Kick-Event-Type': 'chat.message.sent',
  'Kick-Event-Version': '1',
  'content-type': 'application/json',
  ...over,
});

const post = (app: ReturnType<typeof setup>["app"], h: Record<string, string> = headers(), b = body) => app.request('/webhook', { method: 'POST', headers: h, body: b });
const flush = () => new Promise((r) => setTimeout(r, 0));

describe('POST /webhook', () => {
  it('missing header -> 400', async () => {
    const { app } = setup();
    const h: Record<string, string> = headers();
    delete h['Kick-Event-Signature'];
    expect((await post(app, h)).status).toBe(400);
  });

  it('bad signature -> 401', async () => {
    const { app, handle } = setup(false);
    expect((await post(app)).status).toBe(401);
    expect(handle).not.toHaveBeenCalled();
  });

  it('verifies against raw body', async () => {
    const { app, verify } = setup();
    await post(app);
    expect(verify).toHaveBeenCalledWith('01J1', '2026-11-06T11:59:00Z', body, 'c2ln');
  });

  it('stale timestamp -> 400', async () => {
    const { app } = setup();
    expect((await post(app, headers({ 'Kick-Event-Message-Timestamp': '2026-11-06T11:49:00Z' }))).status).toBe(400);
  });

  it('valid chat message -> 200 and handled', async () => {
    const { app, handle } = setup();
    expect((await post(app)).status).toBe(200);
    await flush();
    expect(handle).toHaveBeenCalledWith(JSON.parse(body));
  });

  it('duplicate message id handled once', async () => {
    const { app, handle } = setup();
    expect((await post(app)).status).toBe(200);
    expect((await post(app)).status).toBe(200);
    await flush();
    expect(handle).toHaveBeenCalledTimes(1);
  });

  it('other event types ignored', async () => {
    const { app, handle } = setup();
    expect((await post(app, headers({ 'Kick-Event-Type': 'channel.followed' }))).status).toBe(200);
    await flush();
    expect(handle).not.toHaveBeenCalled();
  });

  it('oversized body -> 413 before signature check', async () => {
    const { app, verify } = setup();
    const res = await post(app, headers(), JSON.stringify({ content: 'x'.repeat(70 * 1024) }));
    expect(res.status).toBe(413);
    expect(verify).not.toHaveBeenCalled();
  });

  it('invalid json -> 400', async () => {
    const { app } = setup();
    expect((await post(app, headers(), '{not json')).status).toBe(400);
  });

  it('handler rejection still 200 and logged', async () => {
    const { app, handle, log } = setup();
    handle.mockRejectedValueOnce(new Error('boom'));
    expect((await post(app)).status).toBe(200);
    await flush();
    expect(log.error).toHaveBeenCalled();
  });
});

describe('RecentIds', () => {
  it('expires after ttl', () => {
    let t = 0;
    const r = new RecentIds(1000, 10, () => t);
    expect(r.checkAndAdd('a')).toBe(false);
    expect(r.checkAndAdd('a')).toBe(true);
    t = 1001;
    expect(r.checkAndAdd('a')).toBe(false);
  });
  it('evicts oldest over max', () => {
    const r = new RecentIds(60_000, 2, () => 0);
    r.checkAndAdd('a');
    r.checkAndAdd('b');
    r.checkAndAdd('c');
    expect(r.checkAndAdd('a')).toBe(false);
    expect(r.checkAndAdd('c')).toBe(true);
  });
});
