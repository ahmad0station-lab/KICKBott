import { describe, it, expect, beforeAll } from 'vitest';
import { mkdtempSync, writeFileSync, mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp, buildDeps } from '../src/app.js';
import { BotDb } from '../src/db.js';
import { cfg, fakeFetch } from './helpers.js';

let staticDir: string;
beforeAll(() => {
  staticDir = mkdtempSync(join(tmpdir(), 'kmb-web-'));
  writeFileSync(join(staticDir, 'index.html'), '<!doctype html><title>KMB</title>');
  mkdirSync(join(staticDir, 'assets'));
  writeFileSync(join(staticDir, 'assets', 'app.js'), 'console.log(1)');
});

const app = () => createApp(buildDeps({ cfg, db: new BotDb(':memory:'), fetchFn: fakeFetch(), staticDir }));

describe('createApp', () => {
  it('/health', async () => {
    const r = await app().request('/health');
    expect(r.status).toBe(200);
    expect(await r.json()).toEqual({ ok: true, auth: 'needs_login', subscription: false });
  });

  it('serves assets with content type', async () => {
    const r = await app().request('/assets/app.js');
    expect(r.status).toBe(200);
    expect(r.headers.get('content-type')).toMatch(/javascript/);
  });

  it('spa fallback to index.html', async () => {
    const r = await app().request('/lists');
    expect(r.status).toBe(200);
    expect(await r.text()).toContain('<title>KMB</title>');
  });

  it('no path traversal', async () => {
    const r = await app().request('/..%2F..%2Fetc%2Fpasswd');
    expect(await r.text()).toContain('<title>KMB</title>');
  });

  it('api routes are not swallowed by spa fallback', async () => {
    expect((await app().request('/api/status')).status).toBe(401);
    expect((await app().request('/api/unknown')).status).toBe(401);
  });

  it('backend prefixes never fall back to index.html', async () => {
    expect((await app().request('/webhook/anything')).status).toBe(404);
  });

  it('webhook is mounted', async () => {
    expect((await app().request('/webhook', { method: 'POST' })).status).toBe(400);
  });
});
