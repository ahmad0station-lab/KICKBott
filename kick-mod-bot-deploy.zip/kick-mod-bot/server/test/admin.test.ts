import { describe, it, expect, beforeEach } from 'vitest';
import { adminRoutes } from '../src/routes/admin.js';
import { BotDb } from '../src/db.js';
import { MatcherStore } from '../src/matcherStore.js';
import { createStatus } from '../src/status.js';
import { SESSION_COOKIE, signSession } from '../src/session.js';
import type { Config } from '../src/config.js';
import type { Permission } from '../src/types.js';
import { cfg, cfgWithGoogle, freshTokens } from './helpers.js';

const ORIGIN = 'https://x.up.railway.app';
let db: BotDb;

const appFor = (config: Config = cfg) => adminRoutes({ cfg: config, db, matchers: new MatcherStore(db), status: createStatus(db) });

const cookieFor = (sub: string) => `${SESSION_COOKIE}=${signSession(cfg.sessionSecret, sub, Date.now() + 60_000)}`;

function owner() {
  db.upsertUser({ id: 7, username: 'Mansourko', picture: 'me.png' });
  return cookieFor('kick:7');
}

function mod(perms: Permission[], id = 9, name = 'ahmed') {
  db.upsertUser({ id, username: name, picture: null });
  const m = db.addTeamMember(name, perms, id);
  if (m === 'duplicate') throw new Error('dup');
  return { cookie: cookieFor(`kick:${id}`), member: m };
}

async function call(app: ReturnType<typeof appFor>, path: string, cookie?: string, init: { method?: string; body?: unknown; origin?: string | null } = {}) {
  const headers: Record<string, string> = { 'content-type': 'application/json' };
  if (cookie) headers.cookie = cookie;
  if (init.origin !== null) headers.origin = init.origin ?? ORIGIN;
  return app.request(path, { method: init.method ?? 'GET', headers, body: init.body === undefined ? undefined : JSON.stringify(init.body) });
}

beforeEach(() => {
  db = new BotDb(':memory:');
});

describe('/api/me', () => {
  it('answers 200 with no user when logged out, and reports google availability', async () => {
    expect(await (await call(appFor(), '/api/me')).json()).toEqual({ user: null, google: false });
    expect(await (await call(appFor(cfgWithGoogle), '/api/me')).json()).toEqual({ user: null, google: true });
  });
  it('returns the principal when logged in', async () => {
    const r = (await (await call(appFor(), '/api/me', owner())).json()) as { user: { kind: string; name: string; permissions: string[] } };
    expect(r.user).toMatchObject({ kind: 'owner', name: 'Mansourko', picture: 'me.png' });
    expect(r.user.permissions).toHaveLength(5);
  });
});

describe('access control', () => {
  it('no session -> 401', async () => {
    expect((await call(appFor(), '/api/status')).status).toBe(401);
  });

  it('removed mod is locked out on the next request', async () => {
    const app = appFor();
    const { cookie, member } = mod(['log.view']);
    expect((await call(app, '/api/status', cookie)).status).toBe(200);
    db.removeTeamMember(member.id);
    expect((await call(app, '/api/status', cookie)).status).toBe(401);
  });

  it('mod with lists.word cannot touch names', async () => {
    const app = appFor();
    const { cookie } = mod(['lists.word']);
    const [nameEntry] = db.addEntries('name', ['سارة'], 'word').added;
    expect((await call(app, '/api/entries?kind=word', cookie)).status).toBe(200);
    expect((await call(app, '/api/entries?kind=name', cookie)).status).toBe(403);
    expect((await call(app, '/api/entries', cookie, { method: 'POST', body: { kind: 'name', values: ['x1'], mode: 'word' } })).status).toBe(403);
    expect((await call(app, `/api/entries/${nameEntry!.id}`, cookie, { method: 'DELETE' })).status).toBe(403);
    expect(db.getEntry(nameEntry!.id)).not.toBeNull();
  });

  it('log, settings and team need their permissions', async () => {
    const app = appFor();
    const { cookie } = mod(['lists.word']);
    expect((await call(app, '/api/deletions', cookie)).status).toBe(403);
    expect((await call(app, '/api/settings', cookie, { method: 'PATCH', body: { enabled: false } })).status).toBe(403);
    expect((await call(app, '/api/team', cookie)).status).toBe(403);
    expect((await call(app, '/api/audit', cookie)).status).toBe(403);
    expect((await call(app, '/api/test', cookie, { method: 'POST', body: { text: 'hi' } })).status).toBe(200);
  });

  it('mutation without origin -> 403', async () => {
    expect((await call(appFor(), '/api/entries', owner(), { method: 'POST', body: { kind: 'word', values: ['x1'], mode: 'word' }, origin: null })).status).toBe(403);
  });
});

describe('lists and audit', () => {
  it('mod edits words; change is audited with their name', async () => {
    const app = appFor();
    const { cookie } = mod(['lists.word']);
    const r = (await (await call(app, '/api/entries', cookie, { method: 'POST', body: { kind: 'word', values: ['حمار', '!!!'], mode: 'word' } })).json()) as { added: unknown[] };
    expect(r.added).toHaveLength(1);
    const t = (await (await call(app, '/api/test', cookie, { method: 'POST', body: { text: 'يا حمار' } })).json()) as { matched: boolean };
    expect(t.matched).toBe(true);
    const audit = db.listAudit({ page: 1, pageSize: 5 }).rows[0];
    expect(audit).toMatchObject({ action: 'entry.add', actorName: 'ahmed', actorSub: 'kick:9', detail: { kind: 'word', values: ['حمار'] } });
  });

  it('delete is audited and rebuilds the matcher', async () => {
    const app = appFor();
    const c = owner();
    const [e] = db.addEntries('word', ['كلب'], 'word').added;
    expect((await call(app, '/api/entries/999', c, { method: 'DELETE' })).status).toBe(404);
    expect((await call(app, `/api/entries/${e!.id}`, c, { method: 'DELETE' })).status).toBe(200);
    expect(db.listAudit({ page: 1, pageSize: 5 }).rows[0]).toMatchObject({ action: 'entry.delete', detail: { kind: 'word', value: 'كلب' } });
  });

  it('settings patch is reflected in status and audited', async () => {
    const app = appFor();
    const { cookie } = mod(['bot.control']);
    expect(await (await call(app, '/api/settings', cookie, { method: 'PATCH', body: { enabled: false } })).json()).toEqual({ enabled: false, exemptMods: true });
    expect(await (await call(app, '/api/status', cookie)).json()).toMatchObject({ enabled: false, deletedToday: 0 });
    expect(db.listAudit({ page: 1, pageSize: 5 }).rows[0]).toMatchObject({ action: 'settings.update', detail: { enabled: false } });
  });
});

describe('team (owner only)', () => {
  it('adds, rejects duplicates and bad permissions, updates, removes', async () => {
    const app = appFor();
    const c = owner();
    const add = await call(app, '/api/team', c, { method: 'POST', body: { username: '@Ahmed', permissions: ['log.view'] } });
    expect(add.status).toBe(201);
    const { member } = (await add.json()) as { member: { id: number; username: string } };
    expect(member.username).toBe('ahmed');
    expect((await call(app, '/api/team', c, { method: 'POST', body: { username: 'ahmed', permissions: [] } })).status).toBe(409);
    expect((await call(app, '/api/team', c, { method: 'POST', body: { username: 'x', permissions: ['root'] } })).status).toBe(400);
    expect((await call(app, `/api/team/${member.id}`, c, { method: 'PATCH', body: { permissions: ['lists.word', 'log.view'] } })).status).toBe(200);
    expect(db.getTeamMember(member.id)?.permissions).toEqual(['lists.word', 'log.view']);
    expect((await call(app, `/api/team/${member.id}`, c, { method: 'DELETE' })).status).toBe(200);
    expect((await call(app, `/api/team/${member.id}`, c, { method: 'DELETE' })).status).toBe(404);
    const actions = db.listAudit({ page: 1, pageSize: 10 }).rows.map((r) => r.action);
    expect(actions).toEqual(['team.remove', 'team.update', 'team.add']);
  });

  it('lists members and chat suggestions; adding a suggestion binds its id', async () => {
    const app = appFor();
    const c = owner();
    db.upsertSeenMod({ id: 31, username: 'SaraMod', picture: 's.png' });
    const before = (await (await call(app, '/api/team', c)).json()) as { members: unknown[]; suggestions: { kickUserId: number }[] };
    expect(before.suggestions.map((s) => s.kickUserId)).toEqual([31]);
    await call(app, '/api/team', c, { method: 'POST', body: { username: 'edited-name', permissions: ['log.view'], kickUserId: 31 } });
    expect(db.findTeamByUserId(31)?.username).toBe('saramod');
    const after = (await (await call(app, '/api/team', c)).json()) as { members: { kickUserId: number; picture: string }[]; suggestions: unknown[] };
    expect(after.members[0]).toMatchObject({ kickUserId: 31, picture: 's.png' });
    expect(after.suggestions).toEqual([]);
  });

  it('audit is paginated', async () => {
    const c = owner();
    db.insertAudit({ actorSub: 'kick:7', actorName: 'Mansourko', actorPicture: null, action: 'bot.link', detail: {} });
    const r = (await (await call(appFor(), '/api/audit?page=1', c)).json()) as { total: number };
    expect(r.total).toBe(1);
  });
});

describe('hygiene', () => {
  it('logout clears cookie', async () => {
    const r = await call(appFor(), '/api/logout', owner(), { method: 'POST' });
    expect(r.status).toBe(200);
    expect(r.headers.get('set-cookie')).toMatch(/kmb_session=;/);
  });

  it('never leaks bot tokens', async () => {
    db.saveTokens(freshTokens({ accessToken: 'SECRET_ACCESS', refreshToken: 'SECRET_REFRESH' }));
    const app = appFor();
    const c = owner();
    for (const p of ['/api/me', '/api/status', '/api/entries', '/api/deletions', '/api/team', '/api/audit']) {
      const b = await (await call(app, p, c)).text();
      expect(b).not.toMatch(/SECRET_|accessToken|refreshToken/);
    }
  });
});
