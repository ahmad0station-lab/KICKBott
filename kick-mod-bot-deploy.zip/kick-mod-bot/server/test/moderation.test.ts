import { describe, it, expect, vi, beforeEach } from 'vitest';
import { BotDb } from '../src/db.js';
import { MatcherStore } from '../src/matcherStore.js';
import { Moderator } from '../src/moderation.js';
import { createStatus, type BotStatus } from '../src/status.js';
import type { ApiResult } from '../src/kick/api.js';
import type { ChatMessageEvent, KickUser } from '../src/types.js';

const user = (id: number, username: string, badges: string[] = []): KickUser => ({
  user_id: id, username, identity: { badges: badges.map((type) => ({ type, text: type })) },
});

const event = (content: string, sender: KickUser = user(2, 'viewer')): ChatMessageEvent => ({
  message_id: 'm1', broadcaster: user(1, 'mansourko'), sender, content,
});

let db: BotDb;
let status: BotStatus;
let deleteMessage: ReturnType<typeof vi.fn<(id: string) => Promise<ApiResult<null>>>>;
let mod: Moderator;

beforeEach(() => {
  db = new BotDb(':memory:');
  db.addEntries('word', ['حمار'], 'word');
  status = createStatus(db);
  deleteMessage = vi.fn(async () => ({ ok: true as const, data: null }));
  mod = new Moderator({ db, client: { deleteMessage }, matchers: new MatcherStore(db), status });
});

describe('Moderator', () => {
  it('deletes matching message and logs it', async () => {
    expect(await mod.handle(event('يا حمااار'))).toBe('deleted');
    expect(deleteMessage).toHaveBeenCalledWith('m1');
    const [row] = db.listDeletions({ page: 1, pageSize: 5 }).rows;
    expect(row).toMatchObject({ messageId: 'm1', senderId: 2, senderUsername: 'viewer', content: 'يا حمااار', status: 'deleted', entryValue: 'حمار', entryKind: 'word', error: null });
  });

  it('clean message -> no call, no row', async () => {
    expect(await mod.handle(event('اهلا يا شباب'))).toBe('clean');
    expect(deleteMessage).not.toHaveBeenCalled();
    expect(db.listDeletions({ page: 1, pageSize: 5 }).total).toBe(0);
  });

  it('broadcaster is exempt', async () => {
    expect(await mod.handle(event('حمار', user(1, 'mansourko')))).toBe('exempt');
  });

  it('moderators exempt unless exempt_mods is off', async () => {
    expect(await mod.handle(event('حمار', user(3, 'mod', ['moderator'])))).toBe('exempt');
    db.setSetting('exempt_mods', false);
    expect(await mod.handle(event('حمار', user(3, 'mod', ['moderator'])))).toBe('deleted');
  });

  it('records moderators seen in chat as team suggestions', async () => {
    const m = { ...user(3, 'SaraMod', ['moderator']), profile_picture: 's.png' };
    await mod.handle(event('اهلا', m));
    await mod.handle(event('اهلا', user(4, 'viewer', ['subscriber'])));
    expect(db.listSuggestions()).toEqual([expect.objectContaining({ kickUserId: 3, username: 'SaraMod', picture: 's.png' })]);
  });

  it('identity null does not throw', async () => {
    expect(await mod.handle(event('حمار', { user_id: 5, username: 'x', identity: null }))).toBe('deleted');
  });

  it('disabled bot does nothing', async () => {
    db.setSetting('enabled', false);
    expect(await mod.handle(event('حمار'))).toBe('disabled');
    expect(deleteMessage).not.toHaveBeenCalled();
  });

  it('failed delete is logged with error', async () => {
    deleteMessage.mockResolvedValueOnce({ ok: false, status: 0, error: 'not_logged_in' });
    expect(await mod.handle(event('حمار'))).toBe('failed');
    expect(db.listDeletions({ page: 1, pageSize: 5 }).rows[0]).toMatchObject({ status: 'failed', error: 'not_logged_in' });
  });

  it('every handled event sets lastEventAt', async () => {
    await mod.handle(event('اهلا'));
    expect(status.lastEventAt).not.toBeNull();
  });

  it('uses rebuilt matcher after list change', async () => {
    const store = new MatcherStore(db);
    const m2 = new Moderator({ db, client: { deleteMessage }, matchers: store, status });
    expect(await m2.handle(event('كلب'))).toBe('clean');
    db.addEntries('word', ['كلب'], 'word');
    store.rebuild();
    expect(await m2.handle(event('كلب'))).toBe('deleted');
  });
});
