import { describe, it, expect, vi } from 'vitest';
import { ensureChatSubscription } from '../src/kick/subscriptions.js';
import type { BotStatus } from '../src/status.js';
import type { KickClient } from '../src/kick/api.js';

const now = () => new Date('2026-11-06T12:00:00.000Z');
const newStatus = (): BotStatus => ({ auth: 'connected', account: null, subscription: { ok: false, checkedAt: null, error: null }, lastEventAt: null });

function client(list: Awaited<ReturnType<KickClient['listSubscriptions']>>, create?: Awaited<ReturnType<KickClient['createChatSubscription']>>) {
  return {
    listSubscriptions: vi.fn(async () => list),
    createChatSubscription: vi.fn(async () => create ?? { ok: true as const, data: [{ subscription_id: 's2' }] }),
  };
}

describe('ensureChatSubscription', () => {
  it('existing webhook subscription -> no create', async () => {
    const c = client({ ok: true, data: [{ id: 's1', event: 'chat.message.sent', method: 'webhook', version: 1 }] });
    const s = newStatus();
    await ensureChatSubscription(c, s, now);
    expect(c.createChatSubscription).not.toHaveBeenCalled();
    expect(s.subscription).toEqual({ ok: true, checkedAt: '2026-11-06T12:00:00.000Z', error: null });
  });

  it('missing -> creates once', async () => {
    const c = client({ ok: true, data: [{ id: 's9', event: 'channel.followed', method: 'webhook', version: 1 }] });
    const s = newStatus();
    await ensureChatSubscription(c, s, now);
    expect(c.createChatSubscription).toHaveBeenCalledTimes(1);
    expect(s.subscription.ok).toBe(true);
  });

  it('create item error -> not ok', async () => {
    const c = client({ ok: true, data: [] }, { ok: true, data: [{ subscription_id: '', error: 'limit reached' }] });
    const s = newStatus();
    await ensureChatSubscription(c, s, now);
    expect(s.subscription).toEqual({ ok: false, checkedAt: '2026-11-06T12:00:00.000Z', error: 'limit reached' });
  });

  it('create request fails -> not ok', async () => {
    const c = client({ ok: true, data: [] }, { ok: false, status: 403, error: 'Forbidden' });
    const s = newStatus();
    await ensureChatSubscription(c, s, now);
    expect(s.subscription).toMatchObject({ ok: false, error: 'Forbidden' });
  });

  it('list fails -> not ok with error', async () => {
    const c = client({ ok: false, status: 0, error: 'not_logged_in' });
    const s = newStatus();
    await ensureChatSubscription(c, s, now);
    expect(s.subscription).toMatchObject({ ok: false, error: 'not_logged_in' });
    expect(c.createChatSubscription).not.toHaveBeenCalled();
  });
});
