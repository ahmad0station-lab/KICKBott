import { describe, it, expect, vi } from 'vitest';
import { createSign, generateKeyPairSync } from 'node:crypto';
import { buildDeps, createApp } from '../src/app.js';
import { BotDb } from '../src/db.js';
import { SESSION_COOKIE, signSession } from '../src/session.js';
import { cfg, freshTokens } from './helpers.js';

const { publicKey, privateKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
const pem = publicKey.export({ type: 'spki', format: 'pem' }).toString();

describe('end to end', () => {
  it('a signed chat message with a banned word is deleted and logged', async () => {
    const db = new BotDb(':memory:');
    db.saveTokens(freshTokens());
    db.addEntries('word', ['حمار'], 'word');

    const kickCalls: string[] = [];
    const fetchFn = vi.fn(async (input: string | URL | Request, init?: RequestInit) => {
      const url = String(input);
      if (url === 'https://api.kick.com/public/v1/public-key') {
        return new Response(JSON.stringify({ data: { public_key: pem }, message: 'OK' }));
      }
      kickCalls.push(`${init?.method ?? 'GET'} ${url}`);
      return new Response(null, { status: 204 });
    });

    const app = createApp(buildDeps({ cfg, db, fetchFn: fetchFn as typeof fetch }));

    const body = JSON.stringify({
      message_id: 'msg-42',
      broadcaster: { user_id: 1, username: 'mansourko', identity: null },
      sender: { user_id: 99, username: 'troll', identity: { badges: [] } },
      content: 'يا حمااار',
      emotes: [],
      created_at: new Date().toISOString(),
    });
    const id = '01JE2E';
    const ts = new Date().toISOString();
    const signature = createSign('RSA-SHA256').update(`${id}.${ts}.${body}`).sign(privateKey, 'base64');

    const res = await app.request('/webhook', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'Kick-Event-Message-Id': id,
        'Kick-Event-Message-Timestamp': ts,
        'Kick-Event-Signature': signature,
        'Kick-Event-Type': 'chat.message.sent',
        'Kick-Event-Version': '1',
      },
      body,
    });
    expect(res.status).toBe(200);

    await vi.waitFor(() => expect(kickCalls).toEqual(['DELETE https://api.kick.com/public/v1/chat/msg-42']));

    db.upsertUser({ id: 7, username: 'mansourko', picture: null });
    const cookie = `${SESSION_COOKIE}=${signSession(cfg.sessionSecret, 'kick:7', Date.now() + 60_000)}`;
    const log = (await (await app.request('/api/deletions', { headers: { cookie } })).json()) as { rows: { status: string; senderUsername: string }[]; total: number };
    expect(log.total).toBe(1);
    expect(log.rows[0]).toMatchObject({ status: 'deleted', senderUsername: 'troll' });
  });
});
