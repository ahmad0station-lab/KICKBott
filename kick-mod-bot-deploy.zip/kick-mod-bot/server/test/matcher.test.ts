import { describe, it, expect } from 'vitest';
import { Matcher } from '../src/filter/matcher.js';
import { normalizeEntry } from '../src/filter/normalize.js';
import type { Entry, EntryKind, MatchMode } from '../src/types.js';

const e = (id: number, kind: EntryKind, value: string, mode: MatchMode = 'word'): Entry => ({
  id, kind, value, normalized: normalizeEntry(value), mode, createdAt: '2026-11-06T00:00:00Z',
});

const m = new Matcher([
  e(1, 'word', 'حمار'), e(2, 'word', 'كلب'), e(3, 'word', '7mar'), e(4, 'word', 'fuck'),
  e(5, 'word', 'خول', 'contains'), e(6, 'name', 'محمد منصور'), e(7, 'name', 'سارة'),
  e(8, 'allow', 'كلبش'),
]);

describe('Matcher', () => {
  it.each(['يا حمار', 'والحمار ده', 'ياحمار', 'حمارين', '7maaar', 'F.U.C.K', 'ح م ا ر', 'بقيت خولات', 'اسمه محمد منصور', 'سارة فين', 'ساره'])(
    'deletes: %s', (t) => expect(m.match(t).matched).toBe(true),
  );

  it.each(['انا كل بس', 'كلبش الحرامي', 'حما', 'محمد بس', 'منصور جه', 'hello', '[emote:1:KEKW]', ''])(
    'keeps: %s', (t) => expect(m.match(t).matched).toBe(false),
  );

  it('reports entry and token', () => {
    const r = m.match('والحمار');
    expect(r.matched && r.entry.id).toBe(1);
    expect(r.matched && r.token).toBe('والحمار');
  });

  it('returns normalized tokens either way', () => {
    expect(m.match('يا حمااار').tokens).toEqual(['يا', 'حمار']);
    expect(m.match('اهلا').tokens).toEqual(['اهلا']);
  });

  it('suffix stripping never leaves a 2-letter stem (زبون is not زب)', () => {
    const short = new Matcher([e(10, 'word', 'زب')]);
    expect(short.match('الزبون دايما على حق').matched).toBe(false);
    expect(short.match('زبون').matched).toBe(false);
    expect(short.match('يا زب').matched).toBe(true);
  });

  it('stem must stay >=2 chars', () => expect(new Matcher([e(9, 'word', 'يا')]).match('و').matched).toBe(false));
});
