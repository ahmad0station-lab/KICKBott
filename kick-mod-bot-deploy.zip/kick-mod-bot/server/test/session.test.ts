import { describe, it, expect } from 'vitest';
import { signSession, verifySession } from '../src/session.js';

const secret = 's'.repeat(32);

describe('session tokens', () => {
  it('round-trips the subject', () => {
    expect(verifySession(secret, signSession(secret, 'kick:42', 2000), 1000)).toBe('kick:42');
    expect(verifySession(secret, signSession(secret, 'google:a.b@gmail.com', 2000), 1000)).toBe('google:a.b@gmail.com');
  });
  it('expired session fails', () => expect(verifySession(secret, signSession(secret, 'kick:1', 2000), 2001)).toBeNull());
  it('tampered hmac fails', () => {
    const t = signSession(secret, 'kick:1', 2000);
    expect(verifySession(secret, t.slice(0, -2) + 'xx', 1000)).toBeNull();
  });
  it('swapped subject fails', () => {
    const [, exp, mac] = signSession(secret, 'kick:1', 2000).split('.');
    const forged = `${Buffer.from('kick:7').toString('base64url')}.${exp}.${mac}`;
    expect(verifySession(secret, forged, 1000)).toBeNull();
  });
  it('other secret fails', () => expect(verifySession('o'.repeat(32), signSession(secret, 'kick:1', 2000), 1000)).toBeNull());
  it('undefined or garbage fails', () => {
    expect(verifySession(secret, undefined, 1000)).toBeNull();
    expect(verifySession(secret, 'nope', 1000)).toBeNull();
    expect(verifySession(secret, 'a.b.c.d', 1000)).toBeNull();
  });
});
