import { describe, it, expect, vi } from 'vitest';
import { generateKeyPairSync, createSign } from 'node:crypto';
import { SignatureVerifier, fetchKickPublicKey } from '../src/kick/signature.js';

const keyPair = () => {
  const { publicKey, privateKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
  return { pem: publicKey.export({ type: 'spki', format: 'pem' }).toString(), privateKey };
};
const sign = (privateKey: ReturnType<typeof keyPair>['privateKey'], data: string) =>
  createSign('RSA-SHA256').update(data).sign(privateKey, 'base64');

const oldKey = keyPair();
const newKey = keyPair();
const id = '01JABCDEF';
const ts = '2026-11-06T12:00:00Z';
const body = JSON.stringify({ message_id: 'm1', content: 'hi' });
const sig = sign(oldKey.privateKey, `${id}.${ts}.${body}`);
const sigByNewKey = sign(newKey.privateKey, `${id}.${ts}.${body}`);

describe('SignatureVerifier', () => {
  const v = new SignatureVerifier(async () => oldKey.pem);

  it('accepts valid signature', async () => expect(await v.verify(id, ts, body, sig)).toBe(true));
  it('rejects tampered body', async () => expect(await v.verify(id, ts, body + 'x', sig)).toBe(false));
  it('rejects tampered message id', async () => expect(await v.verify('other', ts, body, sig)).toBe(false));
  it('rejects garbage signature', async () => expect(await v.verify(id, ts, body, '!!notbase64')).toBe(false));

  it('refetches key once on failure (rotation)', async () => {
    const load = vi.fn().mockResolvedValueOnce(oldKey.pem).mockResolvedValueOnce(newKey.pem);
    const v2 = new SignatureVerifier(load);
    expect(await v2.verify(id, ts, body, sigByNewKey)).toBe(true);
    expect(load).toHaveBeenCalledTimes(2);
    expect(await v2.verify(id, ts, body, sigByNewKey)).toBe(true);
    expect(load).toHaveBeenCalledTimes(2);
  });

  it('bad signatures refetch the key at most once per cooldown', async () => {
    let t = 0;
    const load = vi.fn(async () => oldKey.pem);
    const v4 = new SignatureVerifier(load, { refetchCooldownMs: 60_000, now: () => t });
    for (let i = 0; i < 5; i++) expect(await v4.verify(id, ts, body, sigByNewKey)).toBe(false);
    expect(load).toHaveBeenCalledTimes(2);
    t = 60_001;
    await v4.verify(id, ts, body, sigByNewKey);
    expect(load).toHaveBeenCalledTimes(3);
  });

  it('returns false when the key cannot be loaded', async () => {
    const v3 = new SignatureVerifier(async () => { throw new Error('network'); });
    expect(await v3.verify(id, ts, body, sig)).toBe(false);
  });
});

describe('fetchKickPublicKey', () => {
  it('unwraps data.public_key', async () => {
    const f = vi.fn().mockResolvedValue(new Response(JSON.stringify({ data: { public_key: 'PEM' }, message: '' })));
    expect(await fetchKickPublicKey(f)).toBe('PEM');
    expect(f).toHaveBeenCalledWith('https://api.kick.com/public/v1/public-key');
  });
  it('throws on non-2xx', async () => {
    const f = vi.fn().mockResolvedValue(new Response('no', { status: 500 }));
    await expect(fetchKickPublicKey(f)).rejects.toThrow(/500/);
  });
});
