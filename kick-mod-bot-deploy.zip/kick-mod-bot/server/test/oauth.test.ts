import { describe, it, expect } from 'vitest';
import { createHash } from 'node:crypto';
import { buildAuthorizeUrl, createPkce, exchangeCode, refreshTokens, KickAuthError } from '../src/kick/oauth.js';
import { cfg, fakeFetch, json, tokenBody } from './helpers.js';

describe('oauth', () => {
  it('authorize url', () => {
    const u = new URL(buildAuthorizeUrl(cfg, { challenge: 'C', state: 'S' }));
    expect(u.origin + u.pathname).toBe('https://id.kick.com/oauth/authorize');
    expect(Object.fromEntries(u.searchParams)).toEqual({
      response_type: 'code',
      client_id: 'id',
      redirect_uri: 'https://x.up.railway.app/auth/kick/callback',
      scope: 'user:read events:subscribe moderation:chat_message:manage',
      code_challenge: 'C',
      code_challenge_method: 'S256',
      state: 'S',
    });
  });

  it('pkce challenge = b64url(sha256(verifier))', () => {
    const p = createPkce();
    expect(p.verifier).toMatch(/^[A-Za-z0-9_-]{64}$/);
    expect(p.challenge).toBe(createHash('sha256').update(p.verifier).digest('base64url'));
    expect(p.state).not.toBe(createPkce().state);
  });

  it('exchangeCode posts form body', async () => {
    const f = fakeFetch(json(tokenBody('A', 'R')));
    const before = Date.now();
    const t = await exchangeCode(cfg, 'CODE', 'VER', f);
    expect(f.url(0)).toBe('https://id.kick.com/oauth/token');
    const init = f.init(0);
    expect(init.method).toBe('POST');
    expect(new Headers(init.headers).get('content-type')).toBe('application/x-www-form-urlencoded');
    expect(Object.fromEntries(new URLSearchParams(String(init.body)))).toEqual({
      grant_type: 'authorization_code', code: 'CODE', code_verifier: 'VER',
      redirect_uri: 'https://x.up.railway.app/auth/kick/callback', client_id: 'id', client_secret: 'sec',
    });
    expect(t.accessToken).toBe('A');
    expect(t.refreshToken).toBe('R');
    expect(t.expiresAt).toBeGreaterThanOrEqual(before + 3600_000);
    expect(t.kickUserId).toBeNull();
  });

  it('refreshTokens posts refresh grant', async () => {
    const f = fakeFetch(json(tokenBody('A3', 'R3')));
    const t = await refreshTokens(cfg, 'OLD', f);
    expect(Object.fromEntries(new URLSearchParams(String(f.init(0).body)))).toEqual({
      grant_type: 'refresh_token', refresh_token: 'OLD', client_id: 'id', client_secret: 'sec',
    });
    expect(t.accessToken).toBe('A3');
  });

  it('throws KickAuthError on non-2xx', async () => {
    await expect(refreshTokens(cfg, 'OLD', fakeFetch(json({ error: 'invalid_grant' }, 400)))).rejects.toBeInstanceOf(KickAuthError);
  });
});
