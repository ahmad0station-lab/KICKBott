import { describe, it, expect } from 'vitest';
import { normalizeTokens, normalizeEntry } from '../src/filter/normalize.js';

const n = (s: string) => normalizeTokens(s).join(' ');

describe('normalizeTokens', () => {
  it.each([
    ['حمااااار', 'حمار'],
    ['ح م ا ر', 'حمار'],
    ['يا ح م ا ا ا ر انت', 'يا حمار انت'],
    ['حِمـــار', 'حمار'],
    ['أحمد إبراهيم آدم', 'احمد ابراهيم ادم'],
    ['مستشفى مدرسة', 'مستشفي مدرسه'],
    ['ح​مار', 'حمار'],
    ['حمار😂', 'حمار'],
    ['F U C K', 'fuck'],
    ['fuuuck', 'fuck'],
    ['sh1t', 'shit'],
    ['7mar', '7mar'],
    ['hello [emote:4148074:HYPERCLAP] يا', 'helo يا'],
    ['انا كل بس', 'انا كل بس'],
    ['ا ب', 'ا ب'],
    ['fuck!', 'fuck'],
    ['fuck!!!', 'fuck'],
    ['shit!', 'shit'],
    ['hey @baduser', 'hey baduser'],
    ['a$$hole', 'ashole'],
    ['ح­مار', 'حمار'],
    ['b!tch', 'bitch'],
  ])('%s -> %s', (input, out) => expect(n(input)).toBe(out));

  it('empty after emotes', () => expect(normalizeTokens('[emote:1:KEKW]')).toEqual([]));
});

describe('normalizeEntry', () => {
  it('joins tokens with single spaces', () => expect(normalizeEntry('  محمد   منصور ')).toBe('محمد منصور'));
});
