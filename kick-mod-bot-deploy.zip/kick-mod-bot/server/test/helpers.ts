import { vi } from 'vitest';
import { loadConfig } from '../src/config.js';
import type { Tokens } from '../src/types.js';

const baseEnv = {
  KICK_CLIENT_ID: 'id',
  KICK_CLIENT_SECRET: 'sec',
  PUBLIC_URL: 'https://x.up.railway.app',
  OWNER_KICK_USERNAME: 'mansourko',
  SESSION_SECRET: 'a'.repeat(32),
};

export const cfg = loadConfig(baseEnv);
export const cfgWithGoogle = loadConfig({ ...baseEnv, GOOGLE_CLIENT_ID: 'gid', GOOGLE_CLIENT_SECRET: 'gsec', OWNER_EMAIL: 'owner@gmail.com' });

export const json = (body: unknown, status = 200, headers: Record<string, string> = {}) =>
  new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json', ...headers } });

export const empty = (status: number) => new Response(null, { status });

export const tokenBody = (access = 'a2', refresh = 'r2') => ({
  access_token: access,
  token_type: 'Bearer',
  refresh_token: refresh,
  expires_in: 3600,
  scope: 'user:read events:subscribe moderation:chat_message:manage',
});

/** fetch stub that returns queued responses in order and records every call. */
export function fakeFetch(...responses: (Response | (() => Response))[]) {
  const queue = [...responses];
  const fn = vi.fn(async (_url: string | URL | Request, _init?: RequestInit) => {
    const next = queue.shift();
    if (!next) throw new Error('fakeFetch: no response queued');
    return typeof next === 'function' ? next() : next;
  });
  return Object.assign(fn, {
    url: (i: number) => String(fn.mock.calls[i]![0]),
    init: (i: number) => fn.mock.calls[i]![1] ?? {},
  });
}

export const freshTokens = (over: Partial<Tokens> = {}): Tokens => ({
  accessToken: 'a',
  refreshToken: 'r',
  expiresAt: Date.now() + 3600_000,
  scope: 's',
  kickUserId: 7,
  kickUsername: 'mansourko',
  ...over,
});
