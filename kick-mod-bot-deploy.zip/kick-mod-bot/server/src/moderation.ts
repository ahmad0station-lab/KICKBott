import type { BotDb } from './db.js';
import type { KickClient } from './kick/api.js';
import type { MatcherStore } from './matcherStore.js';
import type { BotStatus } from './status.js';
import type { ChatMessageEvent } from './types.js';

export type Outcome = 'disabled' | 'exempt' | 'clean' | 'deleted' | 'failed';

const STAFF_BADGES = new Set(['moderator', 'broadcaster']);

type Deps = {
  db: BotDb;
  client: Pick<KickClient, 'deleteMessage'>;
  matchers: MatcherStore;
  status: BotStatus;
};

export class Moderator {
  constructor(private readonly d: Deps) {}

  private isExempt(ev: ChatMessageEvent): boolean {
    if (ev.sender.user_id === ev.broadcaster.user_id) return true;
    if (!this.d.db.getSetting('exempt_mods')) return false;
    return (ev.sender.identity?.badges ?? []).some((b) => STAFF_BADGES.has(b.type));
  }

  async handle(ev: ChatMessageEvent): Promise<Outcome> {
    const { db, client, matchers, status } = this.d;
    status.lastEventAt = new Date().toISOString();
    if (ev.sender.user_id !== ev.broadcaster.user_id && (ev.sender.identity?.badges ?? []).some((b) => b.type === 'moderator')) {
      db.upsertSeenMod({ id: ev.sender.user_id, username: ev.sender.username, picture: ev.sender.profile_picture || null });
    }
    if (!db.getSetting('enabled')) return 'disabled';
    if (this.isExempt(ev)) return 'exempt';

    const result = matchers.get().match(ev.content ?? '');
    if (!result.matched) return 'clean';

    const res = await client.deleteMessage(ev.message_id);
    db.insertDeletion({
      messageId: ev.message_id,
      senderId: ev.sender.user_id,
      senderUsername: ev.sender.username,
      content: ev.content,
      entryValue: result.entry.value,
      entryKind: result.entry.kind,
      status: res.ok ? 'deleted' : 'failed',
      error: res.ok ? null : res.error,
    });
    return res.ok ? 'deleted' : 'failed';
  }
}
