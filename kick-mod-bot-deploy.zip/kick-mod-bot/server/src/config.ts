import { z } from 'zod';

export type GoogleConfig = { clientId: string; clientSecret: string; ownerEmail: string };

export type Config = {
  kickClientId: string;
  kickClientSecret: string;
  publicUrl: string;
  /** Lowercased Kick username of the channel owner; that account controls everything. */
  ownerKickUsername: string;
  /** Optional Google sign-in fallback for the owner; null when not configured. */
  google: GoogleConfig | null;
  sessionSecret: string;
  dataDir: string;
  port: number;
  secureCookies: boolean;
};

const schema = z
  .object({
    KICK_CLIENT_ID: z.string().min(1),
    KICK_CLIENT_SECRET: z.string().min(1),
    PUBLIC_URL: z.string().url(),
    OWNER_KICK_USERNAME: z.string().min(1).max(64),
    GOOGLE_CLIENT_ID: z.string().min(1).optional(),
    GOOGLE_CLIENT_SECRET: z.string().min(1).optional(),
    OWNER_EMAIL: z.string().email().optional(),
    SESSION_SECRET: z.string().min(32),
    DATA_DIR: z.string().min(1).default('/data'),
    PORT: z.coerce.number().int().positive().default(3000),
  })
  .superRefine((e, ctx) => {
    const set = [e.GOOGLE_CLIENT_ID, e.GOOGLE_CLIENT_SECRET, e.OWNER_EMAIL].filter(Boolean).length;
    if (set !== 0 && set !== 3) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET/OWNER_EMAIL'], message: 'set all three or none' });
    }
  });

export function loadConfig(env: Record<string, string | undefined>): Config {
  const cleaned = Object.fromEntries(Object.entries(env).filter(([, v]) => v !== undefined && v !== ''));
  const parsed = schema.safeParse(cleaned);
  if (!parsed.success) {
    const fields = [...new Set(parsed.error.issues.map((i) => i.path.join('.')))].join(', ');
    throw new Error(`Invalid config: ${fields}`);
  }
  const e = parsed.data;
  const publicUrl = e.PUBLIC_URL.replace(/\/+$/, '');
  return {
    kickClientId: e.KICK_CLIENT_ID,
    kickClientSecret: e.KICK_CLIENT_SECRET,
    publicUrl,
    ownerKickUsername: e.OWNER_KICK_USERNAME.trim().replace(/^@/, '').toLowerCase(),
    google:
      e.GOOGLE_CLIENT_ID && e.GOOGLE_CLIENT_SECRET && e.OWNER_EMAIL
        ? { clientId: e.GOOGLE_CLIENT_ID, clientSecret: e.GOOGLE_CLIENT_SECRET, ownerEmail: e.OWNER_EMAIL.toLowerCase() }
        : null,
    sessionSecret: e.SESSION_SECRET,
    dataDir: e.DATA_DIR,
    port: e.PORT,
    secureCookies: !/^http:\/\/(localhost|127\.0\.0\.1)(:|\/|$)/.test(publicUrl),
  };
}
