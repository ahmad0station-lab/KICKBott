import { existsSync, mkdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { serve } from '@hono/node-server';
import pino from 'pino';
import { createApp, buildDeps } from './app.js';
import { loadConfig } from './config.js';
import { BotDb } from './db.js';
import { ensureChatSubscription } from './kick/subscriptions.js';

const SUBSCRIPTION_CHECK_MS = 30 * 60_000;
const PRUNE_MS = 60 * 60_000;

const log = pino({ redact: ['*.accessToken', '*.refreshToken', '*.access_token', '*.refresh_token'] });

const cfg = loadConfig(process.env);
mkdirSync(cfg.dataDir, { recursive: true });
const db = new BotDb(join(cfg.dataDir, 'bot.db'));

const starter = JSON.parse(readFileSync(new URL('../seed/starter-words.json', import.meta.url), 'utf8')) as { words: string[]; allow: string[] };
const seeded = db.seedIfEmpty(starter.words, starter.allow);
if (seeded) log.info({ seeded }, 'starter word list loaded');

const webDist = fileURLToPath(new URL('../../web/dist', import.meta.url));
const staticDir = existsSync(join(webDist, 'index.html')) ? webDist : undefined;
if (!staticDir) log.info({ webDist }, 'dashboard build not found; serving API only');

const deps = buildDeps({ cfg, db, staticDir, log });
const app = createApp(deps);

const checkSubscription = async () => {
  if (!db.getTokens()) return;
  try {
    await ensureChatSubscription(deps.client, deps.status);
    if (!deps.status.subscription.ok) log.error({ error: deps.status.subscription.error }, 'chat subscription not ok');
  } catch (err) {
    log.error({ err }, 'subscription check failed');
  }
};

const prune = () => {
  try {
    const removed = db.pruneDeletions(new Date()) + db.pruneAudit(new Date());
    if (removed) log.info({ removed }, 'pruned deletion and audit logs');
  } catch (err) {
    log.error({ err }, 'prune failed');
  }
};

serve({ fetch: app.fetch, port: cfg.port }, (info) => {
  log.info({ port: info.port, publicUrl: cfg.publicUrl }, 'kick mod bot listening');
});

void checkSubscription();
prune();
setInterval(() => void checkSubscription(), SUBSCRIPTION_CHECK_MS);
setInterval(prune, PRUNE_MS);
