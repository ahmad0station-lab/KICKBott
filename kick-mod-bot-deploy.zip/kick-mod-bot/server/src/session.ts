import { createHash, createHmac, timingSafeEqual } from 'node:crypto';
import type { Context, MiddlewareHandler } from 'hono';
import { deleteCookie, getCookie, setCookie } from 'hono/cookie';
import type { Config } from './config.js';
import type { BotDb } from './db.js';
import { resolvePrincipal } from './principal.js';
import type { Principal } from './types.js';

export const SESSION_COOKIE = 'kmb_session';
export const SESSION_TTL_MS = 7 * 24 * 60 * 60_000;

export type AppEnv = { Variables: { principal: Principal } };

const mac = (secret: string, data: string) => createHmac('sha256', secret).update(data).digest('base64url');

const safeEqual = (a: string, b: string) =>
  timingSafeEqual(createHash('sha256').update(a).digest(), createHash('sha256').update(b).digest());

/** Session token: base64url(sub).expiresAt.hmac — the subject is who logged in (kick:<id> or google:<email>). */
export function signSession(secret: string, sub: string, expiresAt: number): string {
  const payload = `${Buffer.from(sub).toString('base64url')}.${expiresAt}`;
  return `${payload}.${mac(secret, payload)}`;
}

export function verifySession(secret: string, token: string | undefined, now: number): string | null {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [sub64, exp, sig] = parts as [string, string, string];
  if (!/^\d+$/.test(exp) || !safeEqual(sig, mac(secret, `${sub64}.${exp}`))) return null;
  if (Number(exp) <= now) return null;
  return Buffer.from(sub64, 'base64url').toString('utf8') || null;
}

export function setSessionCookie(c: Context, cfg: Config, sub: string): void {
  setCookie(c, SESSION_COOKIE, signSession(cfg.sessionSecret, sub, Date.now() + SESSION_TTL_MS), {
    httpOnly: true,
    secure: cfg.secureCookies,
    sameSite: 'Lax',
    path: '/',
    maxAge: SESSION_TTL_MS / 1000,
  });
}

export function clearSessionCookie(c: Context): void {
  deleteCookie(c, SESSION_COOKIE, { path: '/' });
}

/** The principal behind the request's session cookie, or null. */
export function currentPrincipal(c: Context, cfg: Config, db: BotDb): Principal | null {
  const sub = verifySession(cfg.sessionSecret, getCookie(c, SESSION_COOKIE), Date.now());
  return sub ? resolvePrincipal(cfg, db, sub) : null;
}

const MUTATING = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

/** Rejects state-changing requests whose Origin is not the dashboard itself (CSRF guard). */
export function requireSameOrigin(cfg: Config): MiddlewareHandler {
  return async (c, next) => {
    if (MUTATING.has(c.req.method) && c.req.header('origin') !== cfg.publicUrl) {
      return c.json({ error: 'bad_origin' }, 403);
    }
    await next();
  };
}

export function requirePrincipal(cfg: Config, db: BotDb): MiddlewareHandler<AppEnv> {
  return async (c, next) => {
    const p = currentPrincipal(c, cfg, db);
    if (!p) return c.json({ error: 'unauthorized' }, 401);
    c.set('principal', p);
    await next();
  };
}
