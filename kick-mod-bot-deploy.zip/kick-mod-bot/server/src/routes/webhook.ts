import { Hono } from 'hono';
import { bodyLimit } from 'hono/body-limit';
import type { Moderator } from '../moderation.js';
import type { RecentIds } from '../recentIds.js';
import type { SignatureVerifier } from '../kick/signature.js';
import type { BotStatus } from '../status.js';
import type { ChatMessageEvent } from '../types.js';

const REPLAY_WINDOW_MS = 10 * 60_000;
/** A chat event is well under 8 KB; anything far larger is not from Kick. */
const MAX_BODY_BYTES = 64 * 1024;

type Deps = {
  verifier: Pick<SignatureVerifier, 'verify'>;
  moderator: Pick<Moderator, 'handle'>;
  status: BotStatus;
  recent: RecentIds;
  now?: () => number;
  log: { error(o: object, msg: string): void };
};

export function webhookRoutes(d: Deps): Hono {
  const app = new Hono();
  const now = d.now ?? Date.now;

  app.post('/webhook', bodyLimit({ maxSize: MAX_BODY_BYTES, onError: (c) => c.json({ error: 'too_large' }, 413) }), async (c) => {
    const messageId = c.req.header('Kick-Event-Message-Id');
    const timestamp = c.req.header('Kick-Event-Message-Timestamp');
    const signature = c.req.header('Kick-Event-Signature');
    const type = c.req.header('Kick-Event-Type');
    if (!messageId || !timestamp || !signature || !type) return c.json({ error: 'missing_headers' }, 400);

    const raw = await c.req.text();
    if (!(await d.verifier.verify(messageId, timestamp, raw, signature))) return c.json({ error: 'bad_signature' }, 401);

    const sentAt = Date.parse(timestamp);
    if (Number.isNaN(sentAt) || Math.abs(now() - sentAt) > REPLAY_WINDOW_MS) return c.json({ error: 'stale' }, 400);

    if (d.recent.checkAndAdd(messageId)) return c.body(null, 200);
    if (type !== 'chat.message.sent') return c.body(null, 200);

    let ev: ChatMessageEvent;
    try {
      ev = JSON.parse(raw) as ChatMessageEvent;
    } catch {
      return c.json({ error: 'bad_json' }, 400);
    }

    void d.moderator.handle(ev).catch((err: unknown) => {
      d.log.error({ err, messageId: ev.message_id }, 'moderation failed');
    });
    return c.body(null, 200);
  });

  return app;
}
