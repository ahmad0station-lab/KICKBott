import { Hono, type Context } from 'hono';
import { z } from 'zod';
import type { Config } from '../config.js';
import type { BotDb } from '../db.js';
import type { MatcherStore } from '../matcherStore.js';
import { can } from '../principal.js';
import { type AppEnv, clearSessionCookie, currentPrincipal, requirePrincipal, requireSameOrigin } from '../session.js';
import type { BotStatus } from '../status.js';
import { ALL_PERMISSIONS, type AuditAction, type EntryKind, type Permission, type Principal } from '../types.js';

type Deps = { cfg: Config; db: BotDb; matchers: MatcherStore; status: BotStatus };

const kindSchema = z.enum(['word', 'name', 'allow']);
const permissionSchema = z.enum(ALL_PERMISSIONS);
const addSchema = z.object({
  kind: kindSchema,
  values: z.array(z.string().min(1).max(100)).min(1).max(500),
  mode: z.enum(['word', 'contains']).default('word'),
});
const settingsSchema = z.object({ enabled: z.boolean().optional(), exemptMods: z.boolean().optional() });
const testSchema = z.object({ text: z.string().max(2000) });
const teamAddSchema = z.object({
  username: z.string().trim().min(1).max(64),
  permissions: z.array(permissionSchema).max(ALL_PERMISSIONS.length),
  kickUserId: z.number().int().positive().optional(),
});
const teamPatchSchema = z.object({ permissions: z.array(permissionSchema).max(ALL_PERMISSIONS.length) });

const listPermission = (kind: EntryKind): Permission => `lists.${kind}`;

const startOfTodayUtc = () => {
  const d = new Date();
  d.setUTCHours(0, 0, 0, 0);
  return d.toISOString();
};

async function body<T>(req: { json(): Promise<unknown> }, schema: z.ZodType<T>): Promise<T | null> {
  try {
    const parsed = schema.safeParse(await req.json());
    return parsed.success ? parsed.data : null;
  } catch {
    return null;
  }
}

const unique = <T,>(xs: T[]) => [...new Set(xs)];
const pageOf = (c: Context, max = 100, fallback = 25) => ({
  page: Math.max(1, Number(c.req.query('page')) || 1),
  pageSize: Math.min(max, Math.max(1, Number(c.req.query('pageSize')) || fallback)),
});

export function adminRoutes(d: Deps): Hono<AppEnv> {
  const { cfg, db, matchers, status } = d;
  const app = new Hono<AppEnv>();

  const audit = (p: Principal, action: AuditAction, detail: Record<string, unknown>) =>
    db.insertAudit({ actorSub: p.sub, actorName: p.name, actorPicture: p.picture, action, detail });

  const forbidden = (c: Context) => c.json({ error: 'forbidden' }, 403);

  app.use('/api/*', requireSameOrigin(cfg));

  app.get('/api/me', (c) => c.json({ user: currentPrincipal(c, cfg, db), google: cfg.google !== null }));

  app.post('/api/logout', (c) => {
    clearSessionCookie(c);
    return c.json({ ok: true });
  });

  app.use('/api/*', requirePrincipal(cfg, db));

  app.get('/api/status', (c) =>
    c.json({
      auth: status.auth,
      account: status.account,
      subscription: status.subscription,
      lastEventAt: status.lastEventAt,
      enabled: db.getSetting('enabled'),
      exemptMods: db.getSetting('exempt_mods'),
      deletedToday: db.countDeletionsSince(startOfTodayUtc()),
    }),
  );

  app.post('/api/test', async (c) => {
    const b = await body(c.req, testSchema);
    if (!b) return c.json({ error: 'invalid_body' }, 400);
    return c.json(matchers.get().match(b.text));
  });

  app.get('/api/entries', (c) => {
    const p = c.get('principal');
    const kind = kindSchema.safeParse(c.req.query('kind'));
    if (kind.success) return can(p, listPermission(kind.data)) ? c.json({ entries: db.listEntries(kind.data) }) : forbidden(c);
    return c.json({ entries: db.listEntries().filter((e) => can(p, listPermission(e.kind))) });
  });

  app.post('/api/entries', async (c) => {
    const p = c.get('principal');
    const b = await body(c.req, addSchema);
    if (!b) return c.json({ error: 'invalid_body' }, 400);
    if (!can(p, listPermission(b.kind))) return forbidden(c);
    const result = db.addEntries(b.kind, b.values, b.mode);
    if (result.added.length) {
      matchers.rebuild();
      audit(p, 'entry.add', { kind: b.kind, values: result.added.map((e) => e.value), mode: b.mode });
    }
    return c.json(result);
  });

  app.delete('/api/entries/:id', (c) => {
    const p = c.get('principal');
    const id = Number(c.req.param('id'));
    const entry = Number.isInteger(id) ? db.getEntry(id) : null;
    if (!entry) return c.json({ error: 'not_found' }, 404);
    if (!can(p, listPermission(entry.kind))) return forbidden(c);
    db.deleteEntry(id);
    matchers.rebuild();
    audit(p, 'entry.delete', { kind: entry.kind, value: entry.value });
    return c.json({ ok: true });
  });

  app.get('/api/deletions', (c) => {
    if (!can(c.get('principal'), 'log.view')) return forbidden(c);
    const user = c.req.query('user')?.trim() || undefined;
    return c.json(db.listDeletions({ ...pageOf(c), user }));
  });

  app.patch('/api/settings', async (c) => {
    const p = c.get('principal');
    if (!can(p, 'bot.control')) return forbidden(c);
    const b = await body(c.req, settingsSchema);
    if (!b) return c.json({ error: 'invalid_body' }, 400);
    if (b.enabled !== undefined) db.setSetting('enabled', b.enabled);
    if (b.exemptMods !== undefined) db.setSetting('exempt_mods', b.exemptMods);
    audit(p, 'settings.update', b);
    return c.json({ enabled: db.getSetting('enabled'), exemptMods: db.getSetting('exempt_mods') });
  });

  const owner = new Hono<AppEnv>();
  owner.use('/api/*', async (c, next) => {
    if (c.get('principal').kind !== 'owner') return forbidden(c);
    await next();
  });

  owner.get('/api/team', (c) => c.json({ members: db.listTeam(), suggestions: db.listSuggestions() }));

  owner.post('/api/team', async (c) => {
    const b = await body(c.req, teamAddSchema);
    if (!b) return c.json({ error: 'invalid_body' }, 400);
    const seen = b.kickUserId ? db.listSuggestions().find((s) => s.kickUserId === b.kickUserId) : undefined;
    const permissions = unique(b.permissions);
    const member = db.addTeamMember(seen?.username ?? b.username, permissions, seen?.kickUserId ?? null, seen?.picture ?? null);
    if (member === 'duplicate') return c.json({ error: 'duplicate' }, 409);
    audit(c.get('principal'), 'team.add', { username: member.username, permissions });
    return c.json({ member }, 201);
  });

  owner.patch('/api/team/:id', async (c) => {
    const id = Number(c.req.param('id'));
    const b = await body(c.req, teamPatchSchema);
    if (!b) return c.json({ error: 'invalid_body' }, 400);
    const member = db.getTeamMember(id);
    if (!member) return c.json({ error: 'not_found' }, 404);
    const permissions = unique(b.permissions);
    db.updateTeamPermissions(id, permissions);
    audit(c.get('principal'), 'team.update', { username: member.username, permissions });
    return c.json({ member: db.getTeamMember(id) });
  });

  owner.delete('/api/team/:id', (c) => {
    const member = db.getTeamMember(Number(c.req.param('id')));
    if (!member) return c.json({ error: 'not_found' }, 404);
    db.removeTeamMember(member.id);
    audit(c.get('principal'), 'team.remove', { username: member.username });
    return c.json({ ok: true });
  });

  owner.get('/api/audit', (c) => c.json(db.listAudit(pageOf(c, 100, 30))));

  app.route('/', owner);
  return app;
}
