import { Hono, type Context } from 'hono';
import { deleteCookie, getCookie, setCookie } from 'hono/cookie';
import type { Config } from '../config.js';
import type { BotDb } from '../db.js';
import { buildGoogleAuthUrl, fetchGoogleEmail } from '../google.js';
import type { KickClient } from '../kick/api.js';
import { KICK_LOGIN_SCOPES, KICK_SCOPES, buildAuthorizeUrl, createPkce, exchangeCode, fetchKickUser } from '../kick/oauth.js';
import { ensureChatSubscription } from '../kick/subscriptions.js';
import { isOwnerAccount } from '../principal.js';
import { currentPrincipal, setSessionCookie } from '../session.js';
import type { BotStatus } from '../status.js';
import type { KickProfile } from '../types.js';

const KICK_COOKIE = 'kmb_oauth';
const GOOGLE_COOKIE = 'kmb_google';

type Purpose = 'login' | 'link';

type Deps = {
  cfg: Config;
  db: BotDb;
  client: Pick<KickClient, 'listSubscriptions' | 'createChatSubscription'>;
  status: BotStatus;
  exchange?: typeof exchangeCode;
  fetchUser?: (accessToken: string) => Promise<KickProfile>;
  fetchFn?: typeof fetch;
};

export function authRoutes(d: Deps): Hono {
  const { cfg, db, client, status } = d;
  const exchange = d.exchange ?? exchangeCode;
  const fetchFn = d.fetchFn ?? fetch;
  const fetchUser = d.fetchUser ?? ((token: string) => fetchKickUser(token, fetchFn));
  const app = new Hono();

  const tempCookie = (c: Context, name: string, value: string, path: string) =>
    setCookie(c, name, value, { httpOnly: true, secure: cfg.secureCookies, sameSite: 'Lax', path, maxAge: 600 });

  const startKick = (c: Context, purpose: Purpose) => {
    const pkce = createPkce();
    tempCookie(c, KICK_COOKIE, `${purpose}.${pkce.state}.${pkce.verifier}`, '/auth/kick');
    return c.redirect(buildAuthorizeUrl(cfg, pkce, purpose === 'login' ? KICK_LOGIN_SCOPES : KICK_SCOPES), 302);
  };

  app.get('/auth/kick/login', (c) => startKick(c, 'login'));

  app.get('/auth/kick/link', (c) => {
    const p = currentPrincipal(c, cfg, db);
    if (!p) return c.redirect('/?linked=0#settings', 302);
    if (p.kind !== 'owner') return c.json({ error: 'forbidden' }, 403);
    return startKick(c, 'link');
  });

  app.get('/auth/kick/callback', async (c) => {
    const [purpose, savedState, verifier] = (getCookie(c, KICK_COOKIE) ?? '').split('.');
    deleteCookie(c, KICK_COOKIE, { path: '/auth/kick' });
    const code = c.req.query('code');
    const state = c.req.query('state');
    const valid = code && state && savedState && verifier && state === savedState && (purpose === 'login' || purpose === 'link');
    const fail = purpose === 'link' ? '/?linked=0#settings' : '/?login=failed';
    if (!valid) return c.redirect(fail, 302);

    if (purpose === 'login') {
      try {
        const tokens = await exchange(cfg, code, verifier);
        const me = await fetchUser(tokens.accessToken);
        const isOwner = isOwnerAccount(cfg, db, me.id, me.username);
        const member = isOwner ? null : (db.findTeamByUserId(me.id) ?? db.bindTeamMember(me.username, me.id, me.picture));
        if (!isOwner && !member) return c.redirect('/?login=denied', 302);
        if (isOwner && db.getOwnerKickUserId() === null) db.setOwnerKickUserId(me.id);
        db.upsertUser(me);
        setSessionCookie(c, cfg, `kick:${me.id}`);
        return c.redirect('/', 302);
      } catch {
        return c.redirect('/?login=failed', 302);
      }
    }

    const owner = currentPrincipal(c, cfg, db);
    if (owner?.kind !== 'owner') return c.redirect(fail, 302);
    try {
      const tokens = await exchange(cfg, code, verifier);
      const bot = await fetchUser(tokens.accessToken);
      db.saveTokens({ ...tokens, kickUserId: bot.id, kickUsername: bot.username });
      status.auth = 'connected';
      status.account = { id: bot.id, username: bot.username };
      db.insertAudit({ actorSub: owner.sub, actorName: owner.name, actorPicture: owner.picture, action: 'bot.link', detail: { username: bot.username } });
    } catch {
      return c.redirect(fail, 302);
    }
    await ensureChatSubscription(client, status);
    return c.redirect('/?linked=1#settings', 302);
  });

  app.get('/auth/google/login', (c) => {
    if (!cfg.google) return c.notFound();
    const pkce = createPkce();
    tempCookie(c, GOOGLE_COOKIE, `${pkce.state}.${pkce.verifier}`, '/auth/google');
    return c.redirect(buildGoogleAuthUrl(cfg, cfg.google, pkce), 302);
  });

  app.get('/auth/google/callback', async (c) => {
    if (!cfg.google) return c.notFound();
    const [savedState, verifier] = (getCookie(c, GOOGLE_COOKIE) ?? '').split('.');
    deleteCookie(c, GOOGLE_COOKIE, { path: '/auth/google' });
    const code = c.req.query('code');
    const state = c.req.query('state');
    if (!code || !state || !savedState || !verifier || state !== savedState) return c.redirect('/?login=failed', 302);
    try {
      const { email, verified } = await fetchGoogleEmail(cfg, cfg.google, code, verifier, fetchFn);
      if (!verified || email !== cfg.google.ownerEmail) return c.redirect('/?login=denied', 302);
      setSessionCookie(c, cfg, `google:${email}`);
      return c.redirect('/', 302);
    } catch {
      return c.redirect('/?login=failed', 302);
    }
  });

  return app;
}
