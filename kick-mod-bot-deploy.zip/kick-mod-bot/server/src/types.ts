export type EntryKind = 'word' | 'name' | 'allow';
export type MatchMode = 'word' | 'contains';

export type Entry = {
  id: number;
  kind: EntryKind;
  value: string;
  normalized: string;
  mode: MatchMode;
  createdAt: string;
};

export type Tokens = {
  accessToken: string;
  refreshToken: string;
  /** epoch ms */
  expiresAt: number;
  scope: string;
  kickUserId: number | null;
  kickUsername: string | null;
};

export type KickBadge = { text: string; type: string; count?: number };

export type KickUser = {
  is_anonymous?: boolean;
  user_id: number;
  username: string;
  profile_picture?: string | null;
  identity: { username_color?: string; badges: KickBadge[] } | null;
};

export type ChatMessageEvent = {
  message_id: string;
  broadcaster: KickUser;
  sender: KickUser;
  content: string;
  emotes?: unknown[];
  created_at?: string;
};

export const ALL_PERMISSIONS = ['lists.word', 'lists.name', 'lists.allow', 'log.view', 'bot.control'] as const;
export type Permission = (typeof ALL_PERMISSIONS)[number];

export type Principal = {
  kind: 'owner' | 'mod';
  sub: string;
  name: string;
  picture: string | null;
  permissions: Permission[];
};

export type KickProfile = { id: number; username: string; picture: string | null };

export type TeamMember = {
  id: number;
  username: string;
  kickUserId: number | null;
  picture: string | null;
  permissions: Permission[];
  addedAt: string;
  lastLoginAt: string | null;
};

export type SeenMod = { kickUserId: number; username: string; picture: string | null; lastSeenAt: string };

export type AuditAction = 'entry.add' | 'entry.delete' | 'settings.update' | 'team.add' | 'team.update' | 'team.remove' | 'bot.link';

export type AuditInput = {
  actorSub: string;
  actorName: string;
  actorPicture: string | null;
  action: AuditAction;
  detail: Record<string, unknown>;
};

export type AuditRow = AuditInput & { id: number; createdAt: string };
