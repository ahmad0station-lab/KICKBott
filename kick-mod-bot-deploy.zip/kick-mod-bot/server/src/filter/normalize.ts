const EMOTE_RE = /\[emote:\d+:[^\]]+\]/g;
const STRIP_RE = /[\u00AD\u034F\u064B-\u065F\u0670\u0640\u180E\u200B-\u200F\u202A-\u202E\u2060-\u2064\uFEFF]/g;
const ARABIC_FOLD: Record<string, string> = { 'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ٱ': 'ا', 'ى': 'ي', 'ة': 'ه', 'ؤ': 'و', 'ئ': 'ي' };
const LEET: Record<string, string> = { '0': 'o', '1': 'i', '4': 'a', '@': 'a', '$': 's', '!': 'i' };

/** Leet characters count as letters only inside a word: a run of them with a Latin letter on both sides (sh1t, a$$hole). */
function applyLeet(s: string): string {
  return s.replace(/(?<=[a-z])[014@$!]+(?=[a-z])/g, (run) => [...run].map((ch) => LEET[ch]!).join(''));
}

const collapseRepeats = (t: string) => t.replace(/(.)\1+/gu, '$1');

function mergeSingleCharRuns(tokens: string[]): string[] {
  const out: string[] = [];
  let run: string[] = [];
  const flush = () => {
    if (run.length >= 3) out.push(collapseRepeats(run.join('')));
    else out.push(...run);
    run = [];
  };
  for (const t of tokens) {
    if ([...t].length === 1) run.push(t);
    else {
      flush();
      out.push(t);
    }
  }
  flush();
  return out;
}

export function normalizeTokens(input: string): string[] {
  let s = input.replace(EMOTE_RE, ' ');
  s = s.normalize('NFKC').toLowerCase();
  s = s.replace(STRIP_RE, '');
  s = s.replace(/[أإآٱىةؤئ]/g, (ch) => ARABIC_FOLD[ch]!);
  s = applyLeet(s);
  const tokens = s
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .split(' ')
    .filter(Boolean)
    .map(collapseRepeats);
  return mergeSingleCharRuns(tokens);
}

export function normalizeEntry(value: string): string {
  return normalizeTokens(value).join(' ');
}
