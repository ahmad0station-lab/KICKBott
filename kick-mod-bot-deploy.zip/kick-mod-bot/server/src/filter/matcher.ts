import { normalizeTokens } from './normalize.js';
import type { Entry, EntryKind } from '../types.js';

export const PREFIXES = ['وال', 'بال', 'فال', 'كال', 'لل', 'ال', 'يا', 'و', 'ف', 'ب', 'ل', 'ك'];
export const SUFFIXES = ['ين', 'ات', 'ون', 'ها', 'هم', 'كم', 'ه', 'ك', 'ي'];

type MatchedEntry = { id: number; kind: EntryKind; value: string };

export type MatchResult =
  | { matched: false; tokens: string[] }
  | { matched: true; entry: MatchedEntry; token: string; tokens: string[] };

const len = (s: string) => [...s].length;

/**
 * The token itself plus every form left after stripping one prefix and/or one suffix.
 * A prefix may leave a 2-letter stem (يازب -> زب); a suffix must leave at least 3 letters,
 * otherwise everyday words collapse onto short insults (زبون -> زب).
 */
export function candidates(token: string): Set<string> {
  const out = new Set<string>();
  if (len(token) >= 2) out.add(token);
  const stems = [token];
  for (const p of PREFIXES) {
    const stem = token.slice(p.length);
    if (token.startsWith(p) && len(stem) >= 2) stems.push(stem);
  }
  for (const stem of stems) {
    out.add(stem);
    for (const s of SUFFIXES) {
      const base = stem.slice(0, -s.length);
      if (stem.endsWith(s) && len(base) >= 3) out.add(base);
    }
  }
  return out;
}

const pick = (e: Entry): MatchedEntry => ({ id: e.id, kind: e.kind, value: e.value });

export class Matcher {
  private wordMap = new Map<string, Entry>();
  private contains: Entry[] = [];
  private phrases: { tokens: string[]; entry: Entry }[] = [];
  private allow = new Set<string>();

  constructor(entries: Entry[]) {
    for (const e of entries) {
      const parts = e.normalized.split(' ').filter(Boolean);
      if (parts.length === 0) continue;
      if (e.kind === 'allow') {
        if (parts.length === 1) this.allow.add(parts[0]!);
        continue;
      }
      if (parts.length > 1) this.phrases.push({ tokens: parts, entry: e });
      else if (e.mode === 'contains') this.contains.push(e);
      else if (!this.wordMap.has(parts[0]!)) this.wordMap.set(parts[0]!, e);
    }
  }

  match(text: string): MatchResult {
    const tokens = normalizeTokens(text);
    const cands = tokens.map(candidates);
    const allowed = cands.map((c) => [...c].some((x) => this.allow.has(x)));

    for (const { tokens: pt, entry } of this.phrases) {
      for (let i = 0; i + pt.length <= tokens.length; i++) {
        if (pt.every((p, j) => !allowed[i + j] && cands[i + j]!.has(p))) {
          return { matched: true, entry: pick(entry), token: tokens.slice(i, i + pt.length).join(' '), tokens };
        }
      }
    }
    for (let i = 0; i < tokens.length; i++) {
      if (allowed[i]) continue;
      for (const c of cands[i]!) {
        const hit = this.wordMap.get(c);
        if (hit) return { matched: true, entry: pick(hit), token: tokens[i]!, tokens };
      }
    }
    for (let i = 0; i < tokens.length; i++) {
      if (allowed[i]) continue;
      const hit = this.contains.find((e) => tokens[i]!.includes(e.normalized));
      if (hit) return { matched: true, entry: pick(hit), token: tokens[i]!, tokens };
    }
    return { matched: false, tokens };
  }
}
