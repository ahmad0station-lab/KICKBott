import type { Config } from './config.js';
import type { BotDb } from './db.js';
import { ALL_PERMISSIONS, type Permission, type Principal } from './types.js';

export { ALL_PERMISSIONS };

/**
 * Turns a session subject into who is acting right now. The DB is read on every call, so removing
 * a mod or a permission takes effect on their very next request.
 */
export function resolvePrincipal(cfg: Config, db: BotDb, sub: string): Principal | null {
  const kick = /^kick:(\d+)$/.exec(sub);
  if (kick) {
    const user = db.getUser(Number(kick[1]));
    if (!user) return null;
    if (isOwnerAccount(cfg, db, user.id, user.username)) {
      return { kind: 'owner', sub, name: user.username, picture: user.picture, permissions: [...ALL_PERMISSIONS] };
    }
    const member = db.findTeamByUserId(user.id);
    if (!member) return null;
    return { kind: 'mod', sub, name: user.username, picture: user.picture ?? member.picture, permissions: member.permissions };
  }
  const google = /^google:(.+)$/.exec(sub);
  if (google && cfg.google && google[1] === cfg.google.ownerEmail) {
    return { kind: 'owner', sub, name: cfg.ownerKickUsername, picture: null, permissions: [...ALL_PERMISSIONS] };
  }
  return null;
}

/**
 * Before the owner's first login, the owner is whoever holds OWNER_KICK_USERNAME. After it, only the
 * pinned Kick user id counts, so a renamed or reclaimed username cannot take over.
 */
export function isOwnerAccount(cfg: Config, db: BotDb, kickUserId: number, username: string): boolean {
  const pinned = db.getOwnerKickUserId();
  if (pinned !== null) return pinned === kickUserId;
  return username.toLowerCase() === cfg.ownerKickUsername;
}

export const can =(p: Principal, perm: Permission) => p.kind === 'owner' || p.permissions.includes(perm);
