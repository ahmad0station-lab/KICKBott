import { readFile, stat } from 'node:fs/promises';
import { extname, resolve, sep } from 'node:path';
import { Hono } from 'hono';
import type { Config } from './config.js';
import type { BotDb } from './db.js';
import { KickClient } from './kick/api.js';
import { SignatureVerifier, fetchKickPublicKey } from './kick/signature.js';
import { MatcherStore } from './matcherStore.js';
import { Moderator } from './moderation.js';
import { RecentIds } from './recentIds.js';
import { adminRoutes } from './routes/admin.js';
import { authRoutes } from './routes/auth.js';
import { webhookRoutes } from './routes/webhook.js';
import { createStatus, type BotStatus } from './status.js';

export type Logger = { error(o: object, msg: string): void; info?(o: object, msg: string): void };

export type AppDeps = {
  cfg: Config;
  db: BotDb;
  status: BotStatus;
  matchers: MatcherStore;
  client: KickClient;
  verifier: SignatureVerifier;
  moderator: Moderator;
  recent: RecentIds;
  log: Logger;
  staticDir?: string;
};

const DEDUPE_TTL_MS = 15 * 60_000;
const DEDUPE_MAX = 10_000;

/** Wires the real collaborators together; tests pass a fake fetch. */
export function buildDeps(o: { cfg: Config; db: BotDb; fetchFn?: typeof fetch; staticDir?: string; log?: Logger }): AppDeps {
  const fetchFn = o.fetchFn ?? fetch;
  const status = createStatus(o.db);
  const matchers = new MatcherStore(o.db);
  const client = new KickClient({ cfg: o.cfg, db: o.db, status, fetchFn });
  return {
    cfg: o.cfg,
    db: o.db,
    status,
    matchers,
    client,
    verifier: new SignatureVerifier(() => fetchKickPublicKey(fetchFn)),
    moderator: new Moderator({ db: o.db, client, matchers, status }),
    recent: new RecentIds(DEDUPE_TTL_MS, DEDUPE_MAX),
    log: o.log ?? { error: () => {} },
    staticDir: o.staticDir,
  };
}

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.json': 'application/json',
  '.woff2': 'font/woff2',
  '.webmanifest': 'application/manifest+json',
};

async function readStatic(root: string, urlPath: string): Promise<{ body: Buffer; type: string } | null> {
  let decoded: string;
  try {
    decoded = decodeURIComponent(urlPath);
  } catch {
    return null;
  }
  const file = resolve(root, '.' + decoded);
  if (file !== root && !file.startsWith(root + sep)) return null;
  try {
    if (!(await stat(file)).isFile()) return null;
    return { body: await readFile(file), type: MIME[extname(file)] ?? 'application/octet-stream' };
  } catch {
    return null;
  }
}

export function createApp(d: AppDeps): Hono {
  const app = new Hono();

  app.get('/health', (c) => c.json({ ok: true, auth: d.status.auth, subscription: d.status.subscription.ok }));
  app.route('/', webhookRoutes({ verifier: d.verifier, moderator: d.moderator, status: d.status, recent: d.recent, log: d.log }));
  app.route('/', authRoutes({ cfg: d.cfg, db: d.db, client: d.client, status: d.status }));
  app.route('/', adminRoutes({ cfg: d.cfg, db: d.db, matchers: d.matchers, status: d.status }));

  if (d.staticDir) {
    const root = resolve(d.staticDir);
    app.get('*', async (c) => {
      if (/^\/(api|auth|webhook)(\/|$)/.test(c.req.path)) return c.notFound();
      const asset = await readStatic(root, c.req.path);
      if (asset) {
        const cache = c.req.path.startsWith('/assets/') ? 'public, max-age=31536000, immutable' : 'no-cache';
        return c.body(new Uint8Array(asset.body), 200, { 'content-type': asset.type, 'cache-control': cache });
      }
      const index = await readStatic(root, '/index.html');
      if (!index) return c.notFound();
      return c.body(new Uint8Array(index.body), 200, { 'content-type': index.type, 'cache-control': 'no-cache' });
    });
  }

  return app;
}
