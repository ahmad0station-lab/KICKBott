/** Remembers recently seen webhook message ids so Kick retries are processed once. */
export class RecentIds {
  private seen = new Map<string, number>();

  constructor(
    private readonly ttlMs: number,
    private readonly max: number,
    private readonly now: () => number = Date.now,
  ) {}

  /** Returns true if the id was already seen (and still fresh); otherwise records it. */
  checkAndAdd(id: string): boolean {
    const t = this.now();
    const at = this.seen.get(id);
    if (at !== undefined && t - at <= this.ttlMs) return true;
    this.seen.delete(id);
    this.seen.set(id, t);
    for (const [key, ts] of this.seen) {
      if (this.seen.size <= this.max && t - ts <= this.ttlMs) break;
      this.seen.delete(key);
    }
    return false;
  }
}
