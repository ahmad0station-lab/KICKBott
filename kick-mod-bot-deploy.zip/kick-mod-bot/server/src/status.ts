import type { BotDb } from './db.js';

export type BotStatus = {
  auth: 'connected' | 'needs_login';
  account: { id: number; username: string } | null;
  subscription: { ok: boolean; checkedAt: string | null; error: string | null };
  lastEventAt: string | null;
};

export function createStatus(db: BotDb): BotStatus {
  const t = db.getTokens();
  return {
    auth: t ? 'connected' : 'needs_login',
    account: t && t.kickUserId !== null && t.kickUsername ? { id: t.kickUserId, username: t.kickUsername } : null,
    subscription: { ok: false, checkedAt: null, error: null },
    lastEventAt: null,
  };
}
