import type { Config, GoogleConfig } from './config.js';

export const GOOGLE_AUTHORIZE_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
export const GOOGLE_TOKEN_URL = 'https://oauth2.googleapis.com/token';
export const GOOGLE_USERINFO_URL = 'https://openidconnect.googleapis.com/v1/userinfo';

export const googleRedirectUri = (cfg: Config) => `${cfg.publicUrl}/auth/google/callback`;

export function buildGoogleAuthUrl(cfg: Config, g: GoogleConfig, p: { challenge: string; state: string }): string {
  const params = new URLSearchParams({
    client_id: g.clientId,
    redirect_uri: googleRedirectUri(cfg),
    response_type: 'code',
    scope: 'openid email',
    state: p.state,
    code_challenge: p.challenge,
    code_challenge_method: 'S256',
    prompt: 'select_account',
  });
  return `${GOOGLE_AUTHORIZE_URL}?${params}`;
}

/** Exchanges the code and returns the Google account's email (lowercased) and whether Google verified it. */
export async function fetchGoogleEmail(
  cfg: Config,
  g: GoogleConfig,
  code: string,
  verifier: string,
  fetchFn: typeof fetch = fetch,
): Promise<{ email: string; verified: boolean }> {
  const tokenRes = await fetchFn(GOOGLE_TOKEN_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      client_id: g.clientId,
      client_secret: g.clientSecret,
      redirect_uri: googleRedirectUri(cfg),
      grant_type: 'authorization_code',
      code_verifier: verifier,
    }).toString(),
  });
  if (!tokenRes.ok) throw new Error(`Google token request failed: HTTP ${tokenRes.status}`);
  const { access_token } = (await tokenRes.json()) as { access_token?: string };
  if (!access_token) throw new Error('Google token response missing access_token');

  const infoRes = await fetchFn(GOOGLE_USERINFO_URL, { headers: { authorization: `Bearer ${access_token}` } });
  if (!infoRes.ok) throw new Error(`Google userinfo failed: HTTP ${infoRes.status}`);
  const info = (await infoRes.json()) as { email?: string; email_verified?: boolean };
  return { email: (info.email ?? '').toLowerCase(), verified: info.email_verified === true };
}
