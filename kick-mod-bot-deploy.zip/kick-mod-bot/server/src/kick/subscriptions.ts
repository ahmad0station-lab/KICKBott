import type { BotStatus } from '../status.js';
import type { KickClient } from './api.js';

/** Makes sure Kick still sends chat messages to our webhook (Kick drops subscriptions after a day of failures). */
export async function ensureChatSubscription(
  client: Pick<KickClient, 'listSubscriptions' | 'createChatSubscription'>,
  status: BotStatus,
  now: () => Date = () => new Date(),
): Promise<void> {
  const set = (ok: boolean, error: string | null) => {
    status.subscription = { ok, checkedAt: now().toISOString(), error };
  };

  const list = await client.listSubscriptions();
  if (!list.ok) return set(false, list.error);
  if (list.data.some((s) => s.event === 'chat.message.sent' && s.method === 'webhook')) return set(true, null);

  const created = await client.createChatSubscription();
  if (!created.ok) return set(false, created.error);
  const failed = created.data.find((d) => d.error);
  set(!failed, failed?.error ?? null);
}
