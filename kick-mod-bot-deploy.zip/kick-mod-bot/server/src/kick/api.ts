import type { Config } from '../config.js';
import type { BotDb } from '../db.js';
import type { BotStatus } from '../status.js';
import type { Tokens } from '../types.js';
import { refreshTokens } from './oauth.js';

export const KICK_API = 'https://api.kick.com';

export type ApiResult<T> = { ok: true; data: T } | { ok: false; status: number; error: string };

export type Subscription = { id: string; event: string; method: string; version: number };
export type CreatedSubscription = { name?: string; version?: number; subscription_id: string; error?: string };

const REFRESH_MARGIN_MS = 5 * 60_000;
const MAX_429_ATTEMPTS = 3;

type Options = {
  cfg: Config;
  db: BotDb;
  status: BotStatus;
  fetchFn?: typeof fetch;
  sleep?: (ms: number) => Promise<void>;
};

async function errorText(res: Response): Promise<string> {
  try {
    const body = (await res.json()) as { message?: unknown; error?: unknown };
    const msg = body.message ?? body.error;
    if (typeof msg === 'string' && msg) return msg;
  } catch {
    /* body is not JSON */
  }
  return `HTTP ${res.status}`;
}

export class KickClient {
  private readonly cfg: Config;
  private readonly db: BotDb;
  private readonly status: BotStatus;
  private readonly fetchFn: typeof fetch;
  private readonly sleep: (ms: number) => Promise<void>;
  private refreshing: Promise<Tokens | null> | null = null;

  constructor(o: Options) {
    this.cfg = o.cfg;
    this.db = o.db;
    this.status = o.status;
    this.fetchFn = o.fetchFn ?? fetch;
    this.sleep = o.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
  }

  /** Refreshes the stored tokens once, even when several requests ask at the same time. */
  private refresh(staleAccessToken: string): Promise<Tokens | null> {
    const current = this.db.getTokens();
    if (!current) return Promise.resolve(null);
    if (current.accessToken !== staleAccessToken && current.expiresAt - Date.now() >= REFRESH_MARGIN_MS) {
      return Promise.resolve(current);
    }
    this.refreshing ??= (async () => {
      try {
        const next = await refreshTokens(this.cfg, current.refreshToken, this.fetchFn);
        const merged = { ...next, kickUserId: current.kickUserId, kickUsername: current.kickUsername };
        this.db.saveTokens(merged);
        this.status.auth = 'connected';
        return merged;
      } catch {
        this.status.auth = 'needs_login';
        return null;
      } finally {
        this.refreshing = null;
      }
    })();
    return this.refreshing;
  }

  private async accessToken(): Promise<string | null> {
    if (this.refreshing) return (await this.refreshing)?.accessToken ?? null;
    const t = this.db.getTokens();
    if (!t) return null;
    if (t.expiresAt - Date.now() < REFRESH_MARGIN_MS) return (await this.refresh(t.accessToken))?.accessToken ?? null;
    return t.accessToken;
  }

  private async send(method: string, path: string, token: string, body?: unknown): Promise<Response> {
    const headers: Record<string, string> = { authorization: `Bearer ${token}`, accept: 'application/json' };
    if (body !== undefined) headers['content-type'] = 'application/json';
    return this.fetchFn(`${KICK_API}${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  }

  private async request<T>(method: string, path: string, body?: unknown): Promise<ApiResult<T>> {
    let token = await this.accessToken();
    if (!token) {
      this.status.auth = 'needs_login';
      return { ok: false, status: 0, error: 'not_logged_in' };
    }
    try {
      let refreshed = false;
      for (let attempt = 1; ; attempt++) {
        const res = await this.send(method, path, token, body);
        if (res.status === 401 && !refreshed) {
          refreshed = true;
          const next = await this.refresh(token);
          if (!next) return { ok: false, status: 401, error: 'needs_login' };
          token = next.accessToken;
          attempt--;
          continue;
        }
        if (res.status === 401) {
          this.status.auth = 'needs_login';
          return { ok: false, status: 401, error: await errorText(res) };
        }
        if (res.status === 429 && attempt < MAX_429_ATTEMPTS) {
          const retryAfter = Number(res.headers.get('retry-after'));
          await this.sleep(retryAfter > 0 ? retryAfter * 1000 : 1000 * 2 ** (attempt - 1));
          continue;
        }
        if (!res.ok) return { ok: false, status: res.status, error: await errorText(res) };
        if (res.status === 204) return { ok: true, data: null as T };
        const json = (await res.json()) as { data: T };
        return { ok: true, data: json.data };
      }
    } catch (err) {
      return { ok: false, status: 0, error: err instanceof Error ? err.message : String(err) };
    }
  }

  deleteMessage(messageId: string): Promise<ApiResult<null>> {
    return this.request<null>('DELETE', `/public/v1/chat/${encodeURIComponent(messageId)}`);
  }

  async getCurrentUser(): Promise<ApiResult<{ user_id: number; name: string }>> {
    const r = await this.request<{ user_id: number; name: string }[]>('GET', '/public/v1/users');
    if (!r.ok) return r;
    const me = r.data[0];
    return me ? { ok: true, data: { user_id: me.user_id, name: me.name } } : { ok: false, status: 200, error: 'no_user' };
  }

  listSubscriptions(): Promise<ApiResult<Subscription[]>> {
    return this.request<Subscription[]>('GET', '/public/v1/events/subscriptions');
  }

  createChatSubscription(): Promise<ApiResult<CreatedSubscription[]>> {
    return this.request<CreatedSubscription[]>('POST', '/public/v1/events/subscriptions', {
      events: [{ name: 'chat.message.sent', version: 1 }],
      method: 'webhook',
    });
  }
}
