import { createHash, randomBytes } from 'node:crypto';
import type { Config } from '../config.js';
import type { KickProfile, Tokens } from '../types.js';

export const KICK_AUTHORIZE_URL = 'https://id.kick.com/oauth/authorize';
export const KICK_TOKEN_URL = 'https://id.kick.com/oauth/token';
/** Scopes for the bot account that deletes messages. */
export const KICK_SCOPES = 'user:read events:subscribe moderation:chat_message:manage';
/** Dashboard sign-in only needs to know who the person is. */
export const KICK_LOGIN_SCOPES = 'user:read';

export class KickAuthError extends Error {}

export const redirectUri = (cfg: Config) => `${cfg.publicUrl}/auth/kick/callback`;

export function createPkce(): { verifier: string; challenge: string; state: string } {
  const verifier = randomBytes(48).toString('base64url');
  const challenge = createHash('sha256').update(verifier).digest('base64url');
  const state = randomBytes(24).toString('base64url');
  return { verifier, challenge, state };
}

export function buildAuthorizeUrl(cfg: Config, p: { challenge: string; state: string }, scopes: string = KICK_SCOPES): string {
  const params = new URLSearchParams({
    response_type: 'code',
    client_id: cfg.kickClientId,
    redirect_uri: redirectUri(cfg),
    scope: scopes,
    code_challenge: p.challenge,
    code_challenge_method: 'S256',
    state: p.state,
  });
  return `${KICK_AUTHORIZE_URL}?${params}`;
}

type TokenResponse = { access_token: string; refresh_token: string; expires_in: number; scope?: string };

async function postToken(body: Record<string, string>, fetchFn: typeof fetch): Promise<Tokens> {
  const res = await fetchFn(KICK_TOKEN_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(body).toString(),
  });
  if (!res.ok) throw new KickAuthError(`Kick token request failed: HTTP ${res.status}`);
  const t = (await res.json()) as TokenResponse;
  if (!t.access_token || !t.refresh_token) throw new KickAuthError('Kick token response missing tokens');
  return {
    accessToken: t.access_token,
    refreshToken: t.refresh_token,
    expiresAt: Date.now() + t.expires_in * 1000,
    scope: t.scope ?? KICK_SCOPES,
    kickUserId: null,
    kickUsername: null,
  };
}

export function exchangeCode(cfg: Config, code: string, verifier: string, fetchFn: typeof fetch = fetch): Promise<Tokens> {
  return postToken(
    {
      grant_type: 'authorization_code',
      code,
      code_verifier: verifier,
      redirect_uri: redirectUri(cfg),
      client_id: cfg.kickClientId,
      client_secret: cfg.kickClientSecret,
    },
    fetchFn,
  );
}

export function refreshTokens(cfg: Config, refreshToken: string, fetchFn: typeof fetch = fetch): Promise<Tokens> {
  return postToken(
    {
      grant_type: 'refresh_token',
      refresh_token: refreshToken,
      client_id: cfg.kickClientId,
      client_secret: cfg.kickClientSecret,
    },
    fetchFn,
  );
}

/** Reads the profile behind a user token (GET /public/v1/users -> data[0]). */
export async function fetchKickUser(accessToken: string, fetchFn: typeof fetch = fetch): Promise<KickProfile> {
  const res = await fetchFn('https://api.kick.com/public/v1/users', {
    headers: { authorization: `Bearer ${accessToken}`, accept: 'application/json' },
  });
  if (!res.ok) throw new KickAuthError(`Kick user request failed: HTTP ${res.status}`);
  const json = (await res.json()) as { data?: { user_id: number; name: string; profile_picture?: string | null }[] };
  const me = json.data?.[0];
  if (!me) throw new KickAuthError('Kick user response empty');
  return { id: me.user_id, username: me.name, picture: me.profile_picture || null };
}
