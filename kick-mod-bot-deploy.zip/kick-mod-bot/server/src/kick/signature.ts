import { verify as cryptoVerify } from 'node:crypto';

export const KICK_PUBLIC_KEY_URL = 'https://api.kick.com/public/v1/public-key';

export async function fetchKickPublicKey(fetchFn: typeof fetch = fetch): Promise<string> {
  const res = await fetchFn(KICK_PUBLIC_KEY_URL);
  if (!res.ok) throw new Error(`Kick public key request failed: HTTP ${res.status}`);
  const json = (await res.json()) as { data?: { public_key?: string } };
  const key = json.data?.public_key;
  if (!key) throw new Error('Kick public key missing in response');
  return key;
}

/** Verifies Kick webhook signatures (RSA PKCS#1 v1.5, SHA-256) and follows key rotation. */
export class SignatureVerifier {
  private key: string | null = null;
  private loading: Promise<string> | null = null;
  private lastRefetch = -Infinity;
  private readonly cooldownMs: number;
  private readonly now: () => number;

  /** Bad signatures may trigger a key refetch (rotation), but at most once per cooldown so junk POSTs can't hammer Kick. */
  constructor(
    private readonly loadKey: () => Promise<string>,
    opts: { refetchCooldownMs?: number; now?: () => number } = {},
  ) {
    this.cooldownMs = opts.refetchCooldownMs ?? 60_000;
    this.now = opts.now ?? Date.now;
  }

  private load(): Promise<string> {
    this.loading ??= this.loadKey().finally(() => {
      this.loading = null;
    });
    return this.loading;
  }

  private check(key: string, data: Buffer, signature: Buffer): boolean {
    try {
      return cryptoVerify('sha256', data, key, signature);
    } catch {
      return false;
    }
  }

  async verify(messageId: string, timestamp: string, rawBody: string, signatureB64: string): Promise<boolean> {
    const data = Buffer.from(`${messageId}.${timestamp}.${rawBody}`);
    const signature = Buffer.from(signatureB64, 'base64');
    try {
      if (!this.key) this.key = await this.load();
      if (this.check(this.key, data, signature)) return true;
      if (this.now() - this.lastRefetch <= this.cooldownMs) return false;
      this.lastRefetch = this.now();
      const fresh = await this.load();
      if (fresh === this.key) return false;
      this.key = fresh;
      return this.check(fresh, data, signature);
    } catch {
      return false;
    }
  }
}
