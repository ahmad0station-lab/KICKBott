import Database from 'better-sqlite3';
import { normalizeEntry } from './filter/normalize.js';
import {
  ALL_PERMISSIONS,
  type AuditInput,
  type AuditRow,
  type Entry,
  type EntryKind,
  type KickProfile,
  type MatchMode,
  type Permission,
  type SeenMod,
  type TeamMember,
  type Tokens,
} from './types.js';

export type SettingKey = 'enabled' | 'exempt_mods';

export type DeletionInput = {
  messageId: string;
  senderId: number;
  senderUsername: string;
  content: string;
  entryValue: string;
  entryKind: EntryKind;
  status: 'deleted' | 'failed';
  error: string | null;
};

export type DeletionRow = DeletionInput & { id: number; createdAt: string };

export type AddResult = { added: Entry[]; skipped: { value: string; reason: 'empty' | 'duplicate' }[] };

const MAX_LOG_ROWS = 5000;
const LOG_DAYS = 30;

type EntryRow = { id: number; kind: EntryKind; value: string; normalized: string; mode: MatchMode; created_at: string };
type TokenRow = {
  access_token: string;
  refresh_token: string;
  expires_at: number;
  scope: string;
  kick_user_id: number | null;
  kick_username: string | null;
};

const toEntry = (r: EntryRow): Entry => ({
  id: r.id,
  kind: r.kind,
  value: r.value,
  normalized: r.normalized,
  mode: r.mode,
  createdAt: r.created_at,
});

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL CHECK (kind IN ('word','name','allow')),
    value TEXT NOT NULL,
    normalized TEXT NOT NULL,
    mode TEXT NOT NULL CHECK (mode IN ('word','contains')),
    created_at TEXT NOT NULL,
    UNIQUE (kind, normalized)
  );
  CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS tokens (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    access_token TEXT NOT NULL,
    refresh_token TEXT NOT NULL,
    expires_at INTEGER NOT NULL,
    scope TEXT NOT NULL,
    kick_user_id INTEGER,
    kick_username TEXT
  );
  CREATE TABLE IF NOT EXISTS deletions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT NOT NULL,
    sender_id INTEGER NOT NULL,
    sender_username TEXT NOT NULL,
    content TEXT NOT NULL,
    entry_value TEXT NOT NULL,
    entry_kind TEXT NOT NULL,
    status TEXT NOT NULL,
    error TEXT,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS deletions_created_at ON deletions (created_at);
  CREATE TABLE IF NOT EXISTS users (
    kick_user_id INTEGER PRIMARY KEY,
    username TEXT NOT NULL,
    profile_picture TEXT,
    last_login_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS team (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kick_username TEXT NOT NULL UNIQUE,
    kick_user_id INTEGER UNIQUE,
    profile_picture TEXT,
    permissions TEXT NOT NULL,
    added_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS seen_mods (
    kick_user_id INTEGER PRIMARY KEY,
    username TEXT NOT NULL,
    profile_picture TEXT,
    last_seen_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_sub TEXT NOT NULL,
    actor_name TEXT NOT NULL,
    actor_picture TEXT,
    action TEXT NOT NULL,
    detail TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS audit_created_at ON audit (created_at);
`;

type TeamRow = {
  id: number;
  kick_username: string;
  kick_user_id: number | null;
  profile_picture: string | null;
  permissions: string;
  added_at: string;
  last_login_at: string | null;
};

const TEAM_SELECT = `SELECT t.*, u.last_login_at FROM team t LEFT JOIN users u ON u.kick_user_id = t.kick_user_id`;

const parsePermissions = (raw: string): Permission[] => {
  try {
    const v = JSON.parse(raw) as unknown;
    return Array.isArray(v) ? (v.filter((p) => (ALL_PERMISSIONS as readonly string[]).includes(p)) as Permission[]) : [];
  } catch {
    return [];
  }
};

const toTeam = (r: TeamRow): TeamMember => ({
  id: r.id,
  username: r.kick_username,
  kickUserId: r.kick_user_id,
  picture: r.profile_picture,
  permissions: parsePermissions(r.permissions),
  addedAt: r.added_at,
  lastLoginAt: r.last_login_at,
});

const cleanUsername = (u: string) => u.trim().replace(/^@/, '').toLowerCase();

const DELETION_COLUMNS = `id, message_id AS messageId, sender_id AS senderId, sender_username AS senderUsername, content,
  entry_value AS entryValue, entry_kind AS entryKind, status, error, created_at AS createdAt`;

export class BotDb {
  private db: Database.Database;

  constructor(path: string) {
    this.db = new Database(path);
    this.db.pragma('journal_mode = WAL');
    this.db.exec(SCHEMA);
  }

  listEntries(kind?: EntryKind): Entry[] {
    const rows = kind
      ? this.db.prepare('SELECT * FROM entries WHERE kind = ? ORDER BY id DESC').all(kind)
      : this.db.prepare('SELECT * FROM entries ORDER BY id DESC').all();
    return (rows as EntryRow[]).map(toEntry);
  }

  addEntries(kind: EntryKind, values: string[], mode: MatchMode): AddResult {
    const result: AddResult = { added: [], skipped: [] };
    const insert = this.db.prepare(
      'INSERT OR IGNORE INTO entries (kind, value, normalized, mode, created_at) VALUES (?, ?, ?, ?, ?) RETURNING *',
    );
    this.db.transaction(() => {
      for (const raw of values) {
        const value = raw.trim();
        const normalized = normalizeEntry(value);
        if (!normalized) {
          result.skipped.push({ value: raw, reason: 'empty' });
          continue;
        }
        const row = insert.get(kind, value, normalized, mode, new Date().toISOString()) as EntryRow | undefined;
        if (row) result.added.push(toEntry(row));
        else result.skipped.push({ value, reason: 'duplicate' });
      }
    })();
    return result;
  }

  deleteEntry(id: number): boolean {
    return this.db.prepare('DELETE FROM entries WHERE id = ?').run(id).changes > 0;
  }

  getSetting(key: SettingKey): boolean {
    const row = this.db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as { value: string } | undefined;
    return row ? row.value === '1' : true;
  }

  setSetting(key: SettingKey, value: boolean): void {
    this.db
      .prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
      .run(key, value ? '1' : '0');
  }

  getTokens(): Tokens | null {
    const r = this.db.prepare('SELECT * FROM tokens WHERE id = 1').get() as TokenRow | undefined;
    if (!r) return null;
    return {
      accessToken: r.access_token,
      refreshToken: r.refresh_token,
      expiresAt: r.expires_at,
      scope: r.scope,
      kickUserId: r.kick_user_id,
      kickUsername: r.kick_username,
    };
  }

  saveTokens(t: Tokens): void {
    this.db
      .prepare(
        `INSERT INTO tokens (id, access_token, refresh_token, expires_at, scope, kick_user_id, kick_username)
         VALUES (1, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET access_token = excluded.access_token, refresh_token = excluded.refresh_token,
           expires_at = excluded.expires_at, scope = excluded.scope, kick_user_id = excluded.kick_user_id,
           kick_username = excluded.kick_username`,
      )
      .run(t.accessToken, t.refreshToken, t.expiresAt, t.scope, t.kickUserId, t.kickUsername);
  }

  clearTokens(): void {
    this.db.prepare('DELETE FROM tokens').run();
  }

  insertDeletion(d: DeletionInput, createdAt: string = new Date().toISOString()): void {
    this.db
      .prepare(
        `INSERT INTO deletions (message_id, sender_id, sender_username, content, entry_value, entry_kind, status, error, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(d.messageId, d.senderId, d.senderUsername, d.content, d.entryValue, d.entryKind, d.status, d.error, createdAt);
  }

  listDeletions(q: { page: number; pageSize: number; user?: string }): { rows: DeletionRow[]; total: number } {
    const where = q.user ? 'WHERE instr(lower(sender_username), lower(?)) > 0' : '';
    const params = q.user ? [q.user] : [];
    const total = (this.db.prepare(`SELECT count(*) AS n FROM deletions ${where}`).get(...params) as { n: number }).n;
    const offset = (Math.max(1, q.page) - 1) * q.pageSize;
    const rows = this.db
      .prepare(`SELECT ${DELETION_COLUMNS} FROM deletions ${where} ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?`)
      .all(...params, q.pageSize, offset) as DeletionRow[];
    return { rows, total };
  }

  countDeletionsSince(iso: string): number {
    const row = this.db
      .prepare(`SELECT count(*) AS n FROM deletions WHERE status = 'deleted' AND created_at >= ?`)
      .get(iso) as { n: number };
    return row.n;
  }

  pruneDeletions(now: Date): number {
    const cutoff = new Date(now.getTime() - LOG_DAYS * 86400_000).toISOString();
    const old = this.db.prepare('DELETE FROM deletions WHERE created_at < ?').run(cutoff).changes;
    const extra = this.db
      .prepare('DELETE FROM deletions WHERE id NOT IN (SELECT id FROM deletions ORDER BY created_at DESC, id DESC LIMIT ?)')
      .run(MAX_LOG_ROWS).changes;
    return old + extra;
  }

  /** The owner's Kick user id, pinned on their first login so a later holder of the same username is not owner. */
  getOwnerKickUserId(): number | null {
    const row = this.db.prepare(`SELECT value FROM settings WHERE key = 'owner_kick_user_id'`).get() as { value: string } | undefined;
    return row ? Number(row.value) : null;
  }

  setOwnerKickUserId(id: number): void {
    this.db
      .prepare(`INSERT INTO settings (key, value) VALUES ('owner_kick_user_id', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`)
      .run(String(id));
  }

  getEntry(id: number): Entry | null {
    const r = this.db.prepare('SELECT * FROM entries WHERE id = ?').get(id) as EntryRow | undefined;
    return r ? toEntry(r) : null;
  }

  upsertUser(u: KickProfile): void {
    this.db
      .prepare(
        `INSERT INTO users (kick_user_id, username, profile_picture, last_login_at) VALUES (?, ?, ?, ?)
         ON CONFLICT(kick_user_id) DO UPDATE SET username = excluded.username, profile_picture = excluded.profile_picture,
           last_login_at = excluded.last_login_at`,
      )
      .run(u.id, u.username, u.picture, new Date().toISOString());
  }

  getUser(id: number): KickProfile | null {
    const r = this.db.prepare('SELECT * FROM users WHERE kick_user_id = ?').get(id) as
      | { kick_user_id: number; username: string; profile_picture: string | null }
      | undefined;
    return r ? { id: r.kick_user_id, username: r.username, picture: r.profile_picture } : null;
  }

  listTeam(): TeamMember[] {
    return (this.db.prepare(`${TEAM_SELECT} ORDER BY t.id`).all() as TeamRow[]).map(toTeam);
  }

  getTeamMember(id: number): TeamMember | null {
    const r = this.db.prepare(`${TEAM_SELECT} WHERE t.id = ?`).get(id) as TeamRow | undefined;
    return r ? toTeam(r) : null;
  }

  findTeamByUserId(kickUserId: number): TeamMember | null {
    const r = this.db.prepare(`${TEAM_SELECT} WHERE t.kick_user_id = ?`).get(kickUserId) as TeamRow | undefined;
    return r ? toTeam(r) : null;
  }

  /** Binds an unbound team row (added by username) to the Kick account that just logged in with that name. */
  bindTeamMember(username: string, kickUserId: number, picture: string | null): TeamMember | null {
    const res = this.db
      .prepare('UPDATE team SET kick_user_id = ?, profile_picture = ? WHERE kick_username = ? AND kick_user_id IS NULL')
      .run(kickUserId, picture, cleanUsername(username));
    return res.changes ? this.findTeamByUserId(kickUserId) : null;
  }

  addTeamMember(username: string, permissions: Permission[], kickUserId: number | null = null, picture: string | null = null): TeamMember | 'duplicate' {
    const name = cleanUsername(username);
    const res = this.db
      .prepare('INSERT OR IGNORE INTO team (kick_username, kick_user_id, profile_picture, permissions, added_at) VALUES (?, ?, ?, ?, ?)')
      .run(name, kickUserId, picture, JSON.stringify(permissions), new Date().toISOString());
    return res.changes ? this.getTeamMember(Number(res.lastInsertRowid))! : 'duplicate';
  }

  updateTeamPermissions(id: number, permissions: Permission[]): boolean {
    return this.db.prepare('UPDATE team SET permissions = ? WHERE id = ?').run(JSON.stringify(permissions), id).changes > 0;
  }

  removeTeamMember(id: number): boolean {
    return this.db.prepare('DELETE FROM team WHERE id = ?').run(id).changes > 0;
  }

  upsertSeenMod(m: KickProfile): void {
    this.db
      .prepare(
        `INSERT INTO seen_mods (kick_user_id, username, profile_picture, last_seen_at) VALUES (?, ?, ?, ?)
         ON CONFLICT(kick_user_id) DO UPDATE SET username = excluded.username, profile_picture = excluded.profile_picture,
           last_seen_at = excluded.last_seen_at`,
      )
      .run(m.id, m.username, m.picture, new Date().toISOString());
  }

  /** Moderators seen in chat who are not on the team yet (matched by id or username). */
  listSuggestions(): SeenMod[] {
    return this.db
      .prepare(
        `SELECT kick_user_id AS kickUserId, username, profile_picture AS picture, last_seen_at AS lastSeenAt FROM seen_mods s
         WHERE NOT EXISTS (SELECT 1 FROM team t WHERE t.kick_user_id = s.kick_user_id OR t.kick_username = lower(s.username))
         ORDER BY last_seen_at DESC, kick_user_id DESC LIMIT 20`,
      )
      .all() as SeenMod[];
  }

  insertAudit(a: AuditInput, createdAt: string = new Date().toISOString()): void {
    this.db
      .prepare('INSERT INTO audit (actor_sub, actor_name, actor_picture, action, detail, created_at) VALUES (?, ?, ?, ?, ?, ?)')
      .run(a.actorSub, a.actorName, a.actorPicture, a.action, JSON.stringify(a.detail), createdAt);
  }

  listAudit(q: { page: number; pageSize: number }): { rows: AuditRow[]; total: number } {
    const total = (this.db.prepare('SELECT count(*) AS n FROM audit').get() as { n: number }).n;
    const rows = this.db
      .prepare(
        `SELECT id, actor_sub AS actorSub, actor_name AS actorName, actor_picture AS actorPicture, action, detail, created_at AS createdAt
         FROM audit ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?`,
      )
      .all(q.pageSize, (Math.max(1, q.page) - 1) * q.pageSize) as (Omit<AuditRow, 'detail'> & { detail: string })[];
    const parse = (raw: string): Record<string, unknown> => {
      try {
        const v = JSON.parse(raw) as unknown;
        return v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {};
      } catch {
        return {};
      }
    };
    return { rows: rows.map((r) => ({ ...r, detail: parse(r.detail) })), total };
  }

  pruneAudit(now: Date): number {
    const cutoff = new Date(now.getTime() - LOG_DAYS * 86400_000).toISOString();
    const old = this.db.prepare('DELETE FROM audit WHERE created_at < ?').run(cutoff).changes;
    const extra = this.db
      .prepare('DELETE FROM audit WHERE id NOT IN (SELECT id FROM audit ORDER BY created_at DESC, id DESC LIMIT ?)')
      .run(MAX_LOG_ROWS).changes;
    return old + extra;
  }

  /** Seeds the starter word and allow lists only the very first time the database is used. */
  seedIfEmpty(words: string[], allow: string[] = []): number {
    if (this.db.prepare(`SELECT 1 FROM settings WHERE key = 'seeded'`).get()) return 0;
    const n = this.addEntries('word', words, 'word').added.length + this.addEntries('allow', allow, 'word').added.length;
    this.db.prepare(`INSERT INTO settings (key, value) VALUES ('seeded', '1')`).run();
    return n;
  }
}
