import type { BotDb } from './db.js';
import { Matcher } from './filter/matcher.js';

/** Holds the current Matcher; rebuild() after any list change. */
export class MatcherStore {
  private matcher: Matcher;

  constructor(private readonly db: BotDb) {
    this.matcher = new Matcher(db.listEntries());
  }

  get(): Matcher {
    return this.matcher;
  }

  rebuild(): void {
    this.matcher = new Matcher(this.db.listEntries());
  }
}
