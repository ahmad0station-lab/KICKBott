import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  // The server only accepts writes whose Origin is PUBLIC_URL; the dev proxy forwards from :5173,
  // so rewrite Origin to match what the server expects.
  const { PUBLIC_URL = 'http://localhost:3000' } = loadEnv(mode, '..', '');
  const target = 'http://localhost:3000';
  const proxy = {
    target,
    configure: (p: { on: (e: 'proxyReq', cb: (req: { setHeader: (k: string, v: string) => void }) => void) => void }) =>
      p.on('proxyReq', (req) => req.setHeader('origin', PUBLIC_URL.replace(/\/+$/, ''))),
  };
  return {
    plugins: [react()],
    server: { port: 5173, proxy: { '/api': proxy, '/auth': proxy } },
  };
});
