import { lazy, Suspense, useCallback, useEffect, useMemo, useState } from 'react';
import { FlaskConical, History, LayoutDashboard, ListFilter, ScrollText, Settings, Users, type LucideIcon } from 'lucide-react';
import { useAuth } from './hooks/useAuth';
import { LoginPage } from './pages/LoginPage';
import { OverviewPage } from './pages/OverviewPage';
import { Shell, type NavItem } from './components/Shell';
import { Spinner } from './components/Spinner';
import { ErrorState } from './components/States';
import { Toast, type ToastMessage } from './components/Toast';
import { can } from './lib/permissions';
import type { Principal } from './lib/api';

const ListsPage = lazy(() => import('./pages/ListsPage').then((m) => ({ default: m.ListsPage })));
const TesterPage = lazy(() => import('./pages/TesterPage').then((m) => ({ default: m.TesterPage })));
const LogPage = lazy(() => import('./pages/LogPage').then((m) => ({ default: m.LogPage })));
const TeamPage = lazy(() => import('./pages/TeamPage').then((m) => ({ default: m.TeamPage })));
const AuditPage = lazy(() => import('./pages/AuditPage').then((m) => ({ default: m.AuditPage })));
const SettingsPage = lazy(() => import('./pages/SettingsPage').then((m) => ({ default: m.SettingsPage })));

type Page = 'overview' | 'lists' | 'tester' | 'log' | 'team' | 'audit' | 'settings';

const ALL: (NavItem<Page> & { allowed: (p: Principal) => boolean })[] = [
  { id: 'overview', label: 'الرئيسية', icon: LayoutDashboard, allowed: () => true },
  { id: 'lists', label: 'القوايم', icon: ListFilter, allowed: (p) => can(p, 'lists.word') || can(p, 'lists.name') || can(p, 'lists.allow') },
  { id: 'log', label: 'السجل', icon: ScrollText, allowed: (p) => can(p, 'log.view') },
  { id: 'tester', label: 'التجربة', icon: FlaskConical, allowed: () => true },
  { id: 'team', label: 'الفريق', icon: Users, allowed: (p) => p.kind === 'owner' },
  { id: 'audit', label: 'سجل التعديلات', icon: History, allowed: (p) => p.kind === 'owner' },
  { id: 'settings', label: 'الإعدادات', icon: Settings, allowed: (p) => p.kind === 'owner' },
];

const hashPage = () => location.hash.slice(1) as Page;

/** Reads ?linked= / ?login= once, then cleans the URL. */
function useRedirectNotice() {
  const [params] = useState(() => new URLSearchParams(location.search));
  useEffect(() => {
    if (params.has('linked') || params.has('login')) history.replaceState(null, '', location.pathname + location.hash);
  }, [params]);
  return { linked: params.get('linked'), login: params.get('login') };
}

export function App() {
  const { state, me, logout } = useAuth();
  const notice = useRedirectNotice();
  const [page, setPage] = useState<Page>(hashPage);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const closeToast = useCallback(() => setToast(null), []);

  useEffect(() => {
    const onHash = () => setPage(hashPage());
    addEventListener('hashchange', onHash);
    return () => removeEventListener('hashchange', onHash);
  }, []);

  useEffect(() => {
    if (notice.linked === '1') setToast({ tone: 'success', text: 'اتربط حساب البوت، وبقى بيستقبل رسايل الشات.' });
    if (notice.linked === '0') setToast({ tone: 'error', text: 'ربط حساب البوت ما نجحش. الربط القديم لسه زي ما هو. جرّب تاني.' });
  }, [notice.linked]);

  const user = me.data?.user ?? null;
  const items = useMemo(() => (user ? ALL.filter((i) => i.allowed(user)) : []), [user]);
  const current: Page = items.some((i) => i.id === page) ? page : 'overview';

  if (state === 'loading') {
    return (
      <main className="flex min-h-dvh items-center justify-center">
        <Spinner size={28} label="بيحمّل..." />
      </main>
    );
  }
  if (state === 'error') {
    return (
      <main className="mx-auto flex min-h-dvh max-w-md items-center px-4">
        <ErrorState error={me.error} onRetry={() => void me.refetch()} />
      </main>
    );
  }
  if (!user) return <LoginPage google={me.data?.google ?? false} notice={notice.login} />;

  const navigate = (p: Page) => {
    location.hash = p;
    setPage(p);
  };

  return (
    <>
      <Shell items={items} current={current} onNavigate={navigate} user={user} onLogout={() => logout.mutate()} loggingOut={logout.isPending}>
        <Suspense fallback={<Spinner label="بيحمّل..." />}>
          {current === 'overview' && <OverviewPage user={user} onToast={setToast} onNavigate={navigate} />}
          {current === 'lists' && <ListsPage user={user} />}
          {current === 'tester' && <TesterPage />}
          {current === 'log' && <LogPage />}
          {current === 'team' && <TeamPage onToast={setToast} />}
          {current === 'audit' && <AuditPage />}
          {current === 'settings' && <SettingsPage />}
        </Suspense>
      </Shell>
      <Toast toast={toast} onClose={closeToast} />
    </>
  );
}
