import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { QueryClient, QueryClientProvider, QueryCache, MutationCache } from '@tanstack/react-query';
import { App } from './App';
import { ApiError, isUnauthorized, type Me } from './lib/api';
import './index.css';

const isForbidden = (e: unknown) => e instanceof ApiError && e.status === 403;

/**
 * 401: the session is gone (logged out or removed from the team) -> login screen.
 * 403: a permission was taken away -> refresh who we are so the navigation updates.
 */
const onError = (err: unknown) => {
  if (isUnauthorized(err)) queryClient.setQueryData<Me>(['me'], (prev) => ({ user: null, google: prev?.google ?? false }));
  else if (isForbidden(err)) void queryClient.invalidateQueries({ queryKey: ['me'] });
};

const queryClient = new QueryClient({
  queryCache: new QueryCache({ onError }),
  mutationCache: new MutationCache({ onError }),
  defaultOptions: {
    queries: {
      staleTime: 5_000,
      refetchOnWindowFocus: true,
      retry: (count, err) => !isUnauthorized(err) && !isForbidden(err) && count < 2,
    },
  },
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </StrictMode>,
);
