import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, type Me } from '../lib/api';

export const ME_KEY = ['me'] as const;
export const STATUS_KEY = ['status'] as const;

/** Who is signed in (or nobody). A 401 anywhere flips this back to signed-out (see main.tsx). */
export function useAuth() {
  const qc = useQueryClient();
  const me = useQuery({ queryKey: ME_KEY, queryFn: api.me, staleTime: 60_000, refetchOnWindowFocus: true });

  const logout = useMutation({
    mutationFn: api.logout,
    onSettled: () => {
      const google = qc.getQueryData<Me>(ME_KEY)?.google ?? false;
      qc.removeQueries({ predicate: (q) => q.queryKey[0] !== ME_KEY[0] });
      qc.setQueryData<Me>(ME_KEY, { user: null, google });
    },
  });

  const state: 'loading' | 'in' | 'out' | 'error' = me.isPending ? 'loading' : me.isError ? 'error' : me.data.user ? 'in' : 'out';
  return { state, me, logout };
}
