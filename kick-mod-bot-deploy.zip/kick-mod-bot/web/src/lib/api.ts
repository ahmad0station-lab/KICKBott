export type EntryKind = 'word' | 'name' | 'allow';
export const PERMISSIONS = ['lists.word', 'lists.name', 'lists.allow', 'log.view', 'bot.control'] as const;
export type Permission = (typeof PERMISSIONS)[number];
export type Principal = { kind: 'owner' | 'mod'; sub: string; name: string; picture: string | null; permissions: Permission[] };
export type Me = { user: Principal | null; google: boolean };
export type TeamMember = { id: number; username: string; kickUserId: number | null; picture: string | null; permissions: Permission[]; addedAt: string; lastLoginAt: string | null };
export type SeenMod = { kickUserId: number; username: string; picture: string | null; lastSeenAt: string };
export type AuditRow = { id: number; actorSub: string; actorName: string; actorPicture: string | null; action: string; detail: Record<string, unknown>; createdAt: string };
export type MatchMode = 'word' | 'contains';

export type Entry = { id: number; kind: EntryKind; value: string; normalized: string; mode: MatchMode; createdAt: string };

export type Status = {
  auth: 'connected' | 'needs_login';
  account: { id: number; username: string } | null;
  subscription: { ok: boolean; checkedAt: string | null; error: string | null };
  lastEventAt: string | null;
  enabled: boolean;
  exemptMods: boolean;
  deletedToday: number;
};

export type Settings = { enabled: boolean; exemptMods: boolean };

export type AddResult = { added: Entry[]; skipped: { value: string; reason: 'empty' | 'duplicate' }[] };

export type MatchResult =
  | { matched: false; tokens: string[] }
  | { matched: true; entry: { id: number; kind: EntryKind; value: string }; token: string; tokens: string[] };

export type Deletion = {
  id: number;
  messageId: string;
  senderId: number;
  senderUsername: string;
  content: string;
  entryValue: string;
  entryKind: EntryKind;
  status: 'deleted' | 'failed';
  error: string | null;
  createdAt: string;
};

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
  ) {
    super(code);
  }
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      method,
      credentials: 'same-origin',
      headers: body === undefined ? undefined : { 'content-type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new ApiError(0, 'network');
  }
  const data = (await res.json().catch(() => null)) as (T & { error?: string }) | null;
  if (!res.ok) throw new ApiError(res.status, data?.error ?? `http_${res.status}`);
  return data as T;
}

export const api = {
  me: () => request<Me>('GET', '/api/me'),
  logout: () => request<{ ok: true }>('POST', '/api/logout'),
  status: () => request<Status>('GET', '/api/status'),
  entries: (kind: EntryKind) => request<{ entries: Entry[] }>('GET', `/api/entries?kind=${kind}`),
  addEntries: (kind: EntryKind, values: string[], mode: MatchMode) => request<AddResult>('POST', '/api/entries', { kind, values, mode }),
  deleteEntry: (id: number) => request<{ ok: true }>('DELETE', `/api/entries/${id}`),
  test: (text: string) => request<MatchResult>('POST', '/api/test', { text }),
  deletions: (q: { page: number; pageSize: number; user?: string }) => {
    const params = new URLSearchParams({ page: String(q.page), pageSize: String(q.pageSize) });
    if (q.user) params.set('user', q.user);
    return request<{ rows: Deletion[]; total: number }>('GET', `/api/deletions?${params}`);
  },
  settings: (patch: Partial<Settings>) => request<Settings>('PATCH', '/api/settings', patch),
  team: () => request<{ members: TeamMember[]; suggestions: SeenMod[] }>('GET', '/api/team'),
  addMember: (b: { username: string; permissions: Permission[]; kickUserId?: number }) => request<{ member: TeamMember }>('POST', '/api/team', b),
  updateMember: (id: number, permissions: Permission[]) => request<{ member: TeamMember }>('PATCH', `/api/team/${id}`, { permissions }),
  removeMember: (id: number) => request<{ ok: true }>('DELETE', `/api/team/${id}`),
  audit: (page: number) => request<{ rows: AuditRow[]; total: number }>('GET', `/api/audit?page=${page}&pageSize=30`),
};

export const isUnauthorized = (e: unknown) => e instanceof ApiError && e.status === 401;

export function errorMessage(e: unknown): string {
  if (!(e instanceof ApiError)) return 'حصلت مشكلة غير متوقعة. جرّب تاني.';
  switch (e.code) {
    case 'network':
      return 'السيرفر مش بيرد. اتأكد إن البوت شغال وجرّب تاني.';
    case 'forbidden':
      return 'مالكش صلاحية تعمل ده. اطلب من صاحب القناة يدّيك الصلاحية.';
    case 'duplicate':
      return 'اليوزر ده موجود في الفريق بالفعل.';
    case 'invalid_body':
      return 'البيانات مش مظبوطة. كل بند لازم يكون من 1 لـ 100 حرف.';
    case 'not_found':
      return 'البند ده مش موجود. يمكن اتمسح قبل كده.';
    default:
      return `السيرفر رجّع خطأ (${e.status}). جرّب تاني.`;
  }
}
