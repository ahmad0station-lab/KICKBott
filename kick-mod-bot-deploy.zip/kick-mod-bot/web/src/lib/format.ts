const rtf = new Intl.RelativeTimeFormat('ar-EG', { numeric: 'auto' });
const num = new Intl.NumberFormat('ar-EG');
const dateTime = new Intl.DateTimeFormat('ar-EG', { dateStyle: 'medium', timeStyle: 'short' });

const STEPS: [Intl.RelativeTimeFormatUnit, number][] = [
  ['second', 60],
  ['minute', 60],
  ['hour', 24],
  ['day', 30],
  ['month', 12],
  ['year', Infinity],
];

export function relativeTime(iso: string, now = Date.now()): string {
  let value = (Date.parse(iso) - now) / 1000;
  for (const [unit, size] of STEPS) {
    if (Math.abs(value) < size) return rtf.format(Math.round(value), unit);
    value /= size;
  }
  return rtf.format(Math.round(value), 'year');
}

export const formatNumber = (n: number) => num.format(n);
export const formatDateTime = (iso: string) => dateTime.format(new Date(iso));

export const KIND_LABEL = { word: 'شتيمة', name: 'اسم', allow: 'مسموح' } as const;
