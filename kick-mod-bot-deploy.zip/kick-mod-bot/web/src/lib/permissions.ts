import type { EntryKind, Permission, Principal } from './api';

export const can = (p: Principal, perm: Permission) => p.kind === 'owner' || p.permissions.includes(perm);

export const listPermission = (kind: EntryKind): Permission => `lists.${kind}`;

export const PERMISSION_LABELS: Record<Permission, { label: string; hint: string }> = {
  'lists.word': { label: 'تعديل الشتايم', hint: 'يضيف ويشيل من قايمة الشتايم' },
  'lists.name': { label: 'تعديل الأسماء', hint: 'يضيف ويشيل من الأسماء الممنوعة' },
  'lists.allow': { label: 'تعديل المسموح', hint: 'يضيف كلمات عادية عشان ما تتمسحش بالغلط' },
  'log.view': { label: 'مشاهدة السجل', hint: 'يشوف الرسايل اللي اتمسحت ومين كتبها' },
  'bot.control': { label: 'التحكم في البوت', hint: 'يشغّل ويوقف البوت ويغيّر إعداد رسايل المودز' },
};

export const TEMPLATES: { id: string; label: string; permissions: Permission[] }[] = [
  { id: 'viewer', label: 'مراقب', permissions: ['log.view'] },
  { id: 'editor', label: 'محرر قوايم', permissions: ['lists.word', 'lists.name', 'lists.allow', 'log.view'] },
  { id: 'full', label: 'مساعد كامل', permissions: ['lists.word', 'lists.name', 'lists.allow', 'log.view', 'bot.control'] },
];

export function templateOf(perms: Permission[]): string | null {
  const key = [...perms].sort().join(',');
  return TEMPLATES.find((t) => [...t.permissions].sort().join(',') === key)?.label ?? null;
}

export const roleLabel = (p: Principal) => (p.kind === 'owner' ? 'صاحب القناة' : templateOf(p.permissions) ?? 'مود');
