import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Ellipsis, LogOut, ShieldCheck, type LucideIcon } from 'lucide-react';
import type { Principal } from '../lib/api';
import { roleLabel } from '../lib/permissions';
import { Avatar } from './Avatar';
import { ThemeToggle } from './ThemeToggle';
import { Spinner } from './Spinner';

export type NavItem<T extends string> = { id: T; label: string; icon: LucideIcon };

type Props<T extends string> = {
  items: NavItem<T>[];
  current: T;
  onNavigate: (id: T) => void;
  user: Principal;
  onLogout: () => void;
  loggingOut: boolean;
  children: ReactNode;
};

const MAX_BOTTOM = 5;

/** Sidebar from `lg` up, a top bar plus bottom tab bar (max 5, the rest under «المزيد») below it. */
export function Shell<T extends string>({ items, current, onNavigate, user, onLogout, loggingOut, children }: Props<T>) {
  const mainRef = useRef<HTMLElement>(null);
  const go = (id: T) => {
    onNavigate(id);
    mainRef.current?.focus({ preventScroll: true });
    window.scrollTo({ top: 0 });
  };

  const overflow = items.length > MAX_BOTTOM;
  const bottom = overflow ? items.slice(0, MAX_BOTTOM - 1) : items;
  const more = overflow ? items.slice(MAX_BOTTOM - 1) : [];

  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[16rem_minmax(0,1fr)]">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:start-4 focus:top-4 focus:z-[100] focus:rounded-md focus:bg-surface focus:px-4 focus:py-2">
        روح للمحتوى
      </a>

      <aside className="sticky top-0 hidden h-dvh flex-col border-e border-border bg-surface lg:flex">
        <Brand className="px-5 py-5" />
        <nav aria-label="أقسام اللوحة" className="flex-1 overflow-y-auto px-3">
          <ul className="flex flex-col gap-1">
            {items.map((it) => (
              <li key={it.id}>
                <SideLink item={it} active={it.id === current} onClick={() => go(it.id)} />
              </li>
            ))}
          </ul>
        </nav>
        <div className="border-t border-border p-3">
          <UserCard user={user} />
          <div className="mt-2 flex items-center gap-1">
            <ThemeToggle />
            <button
              type="button"
              onClick={onLogout}
              disabled={loggingOut}
              className="inline-flex min-h-11 flex-1 cursor-pointer items-center justify-center gap-2 rounded-md px-3 text-sm font-semibold text-text-muted transition-colors duration-150 hover:bg-danger/10 hover:text-danger disabled:opacity-50"
            >
              {loggingOut ? <Spinner size={16} /> : <LogOut size={18} aria-hidden />}
              خروج
            </button>
          </div>
        </div>
      </aside>

      <div className="flex min-h-dvh flex-col">
        <header className="sticky top-0 z-30 flex items-center justify-between gap-2 border-b border-border bg-bg/85 px-4 py-2 backdrop-blur lg:hidden">
          <Brand />
          <div className="flex items-center gap-1">
            <ThemeToggle />
            <UserMenu user={user} onLogout={onLogout} loggingOut={loggingOut} />
          </div>
        </header>

        <main id="main" ref={mainRef} tabIndex={-1} className="mx-auto w-full max-w-6xl flex-1 px-4 pb-28 pt-6 outline-none sm:px-6 lg:px-10 lg:pb-12 lg:pt-10">
          {children}
        </main>

        <nav aria-label="أقسام اللوحة" className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden">
          <ul className="mx-auto flex max-w-lg">
            {bottom.map((it) => (
              <li key={it.id} className="flex-1">
                <BottomLink item={it} active={it.id === current} onClick={() => go(it.id)} />
              </li>
            ))}
            {overflow && (
              <li className="flex-1">
                <MoreMenu items={more} current={current} onPick={go} />
              </li>
            )}
          </ul>
        </nav>
      </div>
    </div>
  );
}

function Brand({ className = '' }: { className?: string }) {
  return (
    <span className={`flex items-center gap-2 text-base font-bold ${className}`}>
      <span className="inline-flex size-8 items-center justify-center rounded-md bg-accent/15 text-accent-ink">
        <ShieldCheck size={18} aria-hidden />
      </span>
      منصوركو بوت
    </span>
  );
}

function SideLink<T extends string>({ item, active, onClick }: { item: NavItem<T>; active: boolean; onClick: () => void }) {
  const Icon = item.icon;
  return (
    <a
      href={`#${item.id}`}
      onClick={(e) => {
        e.preventDefault();
        onClick();
      }}
      aria-current={active ? 'page' : undefined}
      className={`flex min-h-11 cursor-pointer items-center gap-3 rounded-md px-3 text-sm font-semibold transition-colors duration-150 ${
        active ? 'bg-surface-2 text-text' : 'text-text-muted hover:bg-surface-2/70 hover:text-text'
      }`}
    >
      <Icon size={18} aria-hidden className={active ? 'text-accent-ink' : ''} />
      {item.label}
    </a>
  );
}

function BottomLink<T extends string>({ item, active, onClick }: { item: NavItem<T>; active: boolean; onClick: () => void }) {
  const Icon = item.icon;
  return (
    <a
      href={`#${item.id}`}
      onClick={(e) => {
        e.preventDefault();
        onClick();
      }}
      aria-current={active ? 'page' : undefined}
      className={`flex min-h-14 cursor-pointer flex-col items-center justify-center gap-0.5 px-1 text-[0.75rem] font-semibold transition-colors duration-150 ${
        active ? 'text-text' : 'text-text-muted hover:text-text'
      }`}
    >
      <Icon size={20} aria-hidden className={active ? 'text-accent-ink' : ''} />
      {item.label}
    </a>
  );
}

function MoreMenu<T extends string>({ items, current, onPick }: { items: NavItem<T>[]; current: T; onPick: (id: T) => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const active = items.some((i) => i.id === current);
  useDismiss(open, ref, () => setOpen(false));

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        aria-expanded={open}
        aria-haspopup="true"
        onClick={() => setOpen((v) => !v)}
        className={`flex min-h-14 w-full cursor-pointer flex-col items-center justify-center gap-0.5 text-[0.75rem] font-semibold ${active ? 'text-text' : 'text-text-muted'}`}
      >
        <Ellipsis size={20} aria-hidden className={active ? 'text-accent-ink' : ''} />
        المزيد
      </button>
      {open && (
        <ul className="absolute bottom-full end-1 mb-2 w-52 rounded-lg border border-border bg-surface p-1 shadow-panel">
          {items.map((it) => {
            const Icon = it.icon;
            return (
              <li key={it.id}>
                <button
                  type="button"
                  aria-current={it.id === current ? 'page' : undefined}
                  onClick={() => {
                    setOpen(false);
                    onPick(it.id);
                  }}
                  className="flex min-h-11 w-full cursor-pointer items-center gap-3 rounded-md px-3 text-sm font-semibold hover:bg-surface-2"
                >
                  <Icon size={18} aria-hidden />
                  {it.label}
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function UserCard({ user }: { user: Principal }) {
  return (
    <div className="flex items-center gap-3 rounded-md px-2 py-1">
      <Avatar name={user.name} src={user.picture} />
      <div className="min-w-0">
        <p className="truncate text-sm font-bold" dir="auto">{user.name}</p>
        <p className="text-xs text-text-muted">{roleLabel(user)}</p>
      </div>
    </div>
  );
}

function UserMenu({ user, onLogout, loggingOut }: { user: Principal; onLogout: () => void; loggingOut: boolean }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useDismiss(open, ref, () => setOpen(false));

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        aria-expanded={open}
        aria-haspopup="true"
        aria-label={`حسابك: ${user.name}`}
        onClick={() => setOpen((v) => !v)}
        className="inline-flex size-11 cursor-pointer items-center justify-center rounded-full"
      >
        <Avatar name={user.name} src={user.picture} size="sm" />
      </button>
      {open && (
        <div className="absolute end-0 top-full mt-2 w-60 rounded-lg border border-border bg-surface p-2 shadow-panel">
          <UserCard user={user} />
          <button
            type="button"
            onClick={onLogout}
            disabled={loggingOut}
            className="mt-2 flex min-h-11 w-full cursor-pointer items-center gap-2 rounded-md px-3 text-sm font-semibold text-danger hover:bg-danger/10 disabled:opacity-50"
          >
            <LogOut size={18} aria-hidden />
            خروج
          </button>
        </div>
      )}
    </div>
  );
}

/** Closes a popover on outside click or Escape. */
function useDismiss(open: boolean, ref: React.RefObject<HTMLElement>, close: () => void) {
  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) close();
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && close();
    document.addEventListener('pointerdown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('pointerdown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [open, ref, close]);
}
