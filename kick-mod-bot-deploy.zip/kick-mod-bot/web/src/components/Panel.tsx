import type { ReactNode } from 'react';

type Props = { title?: string; actions?: ReactNode; children: ReactNode; className?: string };

export function Panel({ title, actions, children, className = '' }: Props) {
  return (
    <section className={`rounded-lg bg-surface p-4 shadow-panel sm:p-5 ${className}`}>
      {(title || actions) && (
        <header className="mb-4 flex flex-wrap items-center justify-between gap-3">
          {title && <h2 className="text-lg font-bold">{title}</h2>}
          {actions}
        </header>
      )}
      {children}
    </section>
  );
}
