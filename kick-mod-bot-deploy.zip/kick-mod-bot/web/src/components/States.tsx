import type { ReactNode } from 'react';
import { CircleAlert, Inbox, RotateCw } from 'lucide-react';
import { Button } from './Button';
import { errorMessage } from '../lib/api';

export function ErrorState({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  return (
    <div role="alert" className="flex flex-col items-start gap-3 rounded-md bg-danger/10 p-4 text-danger">
      <p className="flex items-center gap-2 font-semibold">
        <CircleAlert size={18} aria-hidden />
        {errorMessage(error)}
      </p>
      {onRetry && (
        <Button onClick={onRetry} icon={<RotateCw size={16} aria-hidden />}>
          جرّب تاني
        </Button>
      )}
    </div>
  );
}

export function EmptyState({ title, hint, action }: { title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-md border border-dashed border-border px-4 py-8 text-center">
      <Inbox size={28} className="text-text-muted" aria-hidden />
      <p className="font-semibold">{title}</p>
      {hint && <p className="max-w-sm text-sm text-text-muted">{hint}</p>}
      {action}
    </div>
  );
}
