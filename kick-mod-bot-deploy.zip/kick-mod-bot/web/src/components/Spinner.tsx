import { LoaderCircle } from 'lucide-react';

export function Spinner({ size = 20, label }: { size?: number; label?: string }) {
  return (
    <span role={label ? 'status' : undefined} className="inline-flex items-center gap-2 text-text-muted">
      <LoaderCircle size={size} className="animate-spin motion-reduce:animate-none" aria-hidden />
      {label && <span className="text-sm">{label}</span>}
    </span>
  );
}
