import { useEffect } from 'react';
import { CircleAlert, CircleCheck, X } from 'lucide-react';

export type ToastMessage = { tone: 'success' | 'error'; text: string };

export function Toast({ toast, onClose }: { toast: ToastMessage | null; onClose: () => void }) {
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(onClose, 6000);
    return () => clearTimeout(t);
  }, [toast, onClose]);

  return (
    <div aria-live="polite" className="pointer-events-none fixed inset-x-4 bottom-4 z-50 flex justify-center">
      {toast && (
        <div
          role={toast.tone === 'error' ? 'alert' : 'status'}
          className={`pointer-events-auto flex max-w-md items-center gap-3 rounded-md px-4 py-3 font-semibold shadow-panel ${
            toast.tone === 'success' ? 'bg-success text-surface' : 'bg-danger text-surface'
          }`}
        >
          {toast.tone === 'success' ? <CircleCheck size={20} aria-hidden /> : <CircleAlert size={20} aria-hidden />}
          <span>{toast.text}</span>
          <button type="button" onClick={onClose} aria-label="اقفل الرسالة" className="-me-2 inline-flex size-11 cursor-pointer items-center justify-center rounded-sm">
            <X size={18} aria-hidden />
          </button>
        </div>
      )}
    </div>
  );
}
