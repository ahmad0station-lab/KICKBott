import { useRef, type KeyboardEvent } from 'react';

type Tab<T extends string> = { id: T; label: string; count?: number };

type Props<T extends string> = { tabs: Tab<T>[]; value: T; onChange: (id: T) => void; label: string; idPrefix: string };

/** Accessible tablist; arrow keys move between tabs (mirrored for RTL). */
export function Tabs<T extends string>({ tabs, value, onChange, label, idPrefix }: Props<T>) {
  const refs = useRef<(HTMLButtonElement | null)[]>([]);

  const onKey = (e: KeyboardEvent, i: number) => {
    const rtl = document.documentElement.dir === 'rtl';
    const step = e.key === 'ArrowLeft' ? (rtl ? 1 : -1) : e.key === 'ArrowRight' ? (rtl ? -1 : 1) : 0;
    if (!step) return;
    e.preventDefault();
    const next = (i + step + tabs.length) % tabs.length;
    onChange(tabs[next]!.id);
    refs.current[next]?.focus();
  };

  return (
    <div role="tablist" aria-label={label} className="flex gap-1 overflow-x-auto rounded-md bg-surface-2 p-1">
      {tabs.map((t, i) => {
        const active = t.id === value;
        return (
          <button
            key={t.id}
            ref={(el) => {
              refs.current[i] = el;
            }}
            id={`${idPrefix}-tab-${t.id}`}
            role="tab"
            type="button"
            aria-selected={active}
            aria-controls={`${idPrefix}-panel`}
            tabIndex={active ? 0 : -1}
            onClick={() => onChange(t.id)}
            onKeyDown={(e) => onKey(e, i)}
            className={`flex min-h-11 flex-1 cursor-pointer items-center justify-center gap-2 whitespace-nowrap rounded-sm px-3 text-sm font-bold transition-colors duration-150 ${
              active ? 'bg-surface text-text shadow-panel' : 'text-text-muted hover:text-text'
            }`}
          >
            {t.label}
            {t.count !== undefined && <span className="text-xs font-semibold text-text-muted">{t.count}</span>}
          </button>
        );
      })}
    </div>
  );
}
