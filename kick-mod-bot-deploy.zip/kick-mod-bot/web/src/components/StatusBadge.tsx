type Tone = 'ok' | 'warn' | 'bad';

const TONES: Record<Tone, string> = {
  ok: 'bg-success/10 text-success',
  warn: 'bg-warning/10 text-warning',
  bad: 'bg-danger/10 text-danger',
};

const DOTS: Record<Tone, string> = { ok: 'bg-success', warn: 'bg-warning', bad: 'bg-danger' };

export function StatusBadge({ tone, children }: { tone: Tone; children: string }) {
  return (
    <span className={`inline-flex items-center gap-2 rounded-sm px-2 py-0.5 text-sm font-semibold ${TONES[tone]}`}>
      <span className={`size-2 rounded-full ${DOTS[tone]}`} aria-hidden />
      {children}
    </span>
  );
}
