import { useState } from 'react';

const SIZES = { sm: 'size-8 text-xs', md: 'size-10 text-sm', lg: 'size-12 text-base' } as const;

/** Kick profile picture with an initial fallback when there is none or it fails to load. */
export function Avatar({ name, src, size = 'md' }: { name: string; src?: string | null; size?: keyof typeof SIZES }) {
  const [failed, setFailed] = useState(false);
  const initial = [...name.replace(/^@/, '')][0]?.toUpperCase() ?? '?';
  const base = `inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-surface-2 font-bold text-text-muted ring-1 ring-border ${SIZES[size]}`;

  if (!src || failed) {
    return (
      <span className={base} aria-hidden>
        {initial}
      </span>
    );
  }
  return (
    <img
      src={src}
      alt=""
      loading="lazy"
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={`${base} object-cover`}
    />
  );
}
