type Props = { checked: boolean; onChange: (next: boolean) => void; label: string; hint?: string; disabled?: boolean };

export function Switch({ checked, onChange, label, hint, disabled }: Props) {
  return (
    <label className={`flex min-h-11 items-center justify-between gap-4 ${disabled ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'}`}>
      <span className="flex flex-col">
        <span className="font-semibold">{label}</span>
        {hint && <span className="text-sm text-text-muted">{hint}</span>}
      </span>
      <span className="relative inline-flex shrink-0">
        <input
          type="checkbox"
          role="switch"
          className="peer sr-only"
          checked={checked}
          disabled={disabled}
          onChange={(e) => onChange(e.target.checked)}
        />
        <span
          aria-hidden
          className="h-7 w-12 rounded-full bg-border transition-colors duration-200 peer-checked:bg-accent peer-focus-visible:ring-2 peer-focus-visible:ring-accent peer-focus-visible:ring-offset-2 peer-focus-visible:ring-offset-surface"
        />
        <span
          aria-hidden
          className="absolute start-1 top-1 size-5 rounded-full bg-surface shadow transition-transform duration-200 peer-checked:-translate-x-5 ltr:peer-checked:translate-x-5"
        />
      </span>
    </label>
  );
}
