import { PERMISSIONS, type Permission } from '../lib/api';
import { PERMISSION_LABELS, TEMPLATES } from '../lib/permissions';

type Props = { value: Permission[]; onChange: (next: Permission[]) => void; idPrefix: string };

/** Quick templates plus one checkbox per permission. */
export function PermissionPicker({ value, onChange, idPrefix }: Props) {
  const has = (p: Permission) => value.includes(p);
  const toggle = (p: Permission) => onChange(has(p) ? value.filter((x) => x !== p) : PERMISSIONS.filter((x) => x === p || value.includes(x)));
  const same = (perms: Permission[]) => perms.length === value.length && perms.every(has);

  return (
    <fieldset className="flex flex-col gap-3">
      <legend className="mb-2 font-semibold">الصلاحيات</legend>
      <div className="flex flex-wrap gap-2" role="group" aria-label="قوالب جاهزة">
        {TEMPLATES.map((t) => (
          <button
            key={t.id}
            type="button"
            aria-pressed={same(t.permissions)}
            onClick={() => onChange([...t.permissions])}
            className={`min-h-11 cursor-pointer rounded-md border px-3 text-sm font-semibold transition-colors duration-150 ${
              same(t.permissions) ? 'border-accent bg-accent/15 text-text' : 'border-border text-text-muted hover:border-text-muted hover:text-text'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>
      <ul className="grid gap-1 sm:grid-cols-2">
        {PERMISSIONS.map((p) => (
          <li key={p}>
            <label htmlFor={`${idPrefix}-${p}`} className="flex min-h-11 cursor-pointer items-start gap-3 rounded-md p-2 hover:bg-surface-2">
              <input
                id={`${idPrefix}-${p}`}
                type="checkbox"
                checked={has(p)}
                onChange={() => toggle(p)}
                className="mt-1 size-4 shrink-0 accent-[rgb(var(--accent))]"
              />
              <span>
                <span className="block text-sm font-semibold">{PERMISSION_LABELS[p].label}</span>
                <span className="block text-xs text-text-muted">{PERMISSION_LABELS[p].hint}</span>
              </span>
            </label>
          </li>
        ))}
      </ul>
    </fieldset>
  );
}

export function PermissionChips({ value }: { value: Permission[] }) {
  if (!value.length) return <span className="text-sm text-text-muted">من غير صلاحيات (يشوف الرئيسية والتجربة بس)</span>;
  return (
    <ul className="flex flex-wrap gap-1.5">
      {value.map((p) => (
        <li key={p} className="rounded-sm bg-surface-2 px-2 py-0.5 text-xs font-semibold">
          {PERMISSION_LABELS[p].label}
        </li>
      ))}
    </ul>
  );
}
