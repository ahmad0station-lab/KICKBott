import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { Spinner } from './Spinner';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';

const VARIANTS: Record<Variant, string> = {
  primary: 'bg-accent text-on-accent hover:brightness-105 active:brightness-95',
  secondary: 'bg-surface-2 text-text hover:bg-border/70 active:bg-border',
  ghost: 'text-text-muted hover:bg-surface-2 hover:text-text active:bg-border/70',
  danger: 'bg-danger/10 text-danger hover:bg-danger/20 active:bg-danger/25',
};

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  loading?: boolean;
  icon?: ReactNode;
};

export const buttonClass = (variant: Variant = 'secondary', extra = '') =>
  `inline-flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-md px-4 text-sm font-bold transition-[background-color,filter,color] duration-150 disabled:cursor-not-allowed disabled:opacity-50 ${VARIANTS[variant]} ${extra}`;

export function Button({ variant = 'secondary', loading = false, icon, className = '', children, disabled, type = 'button', ...rest }: Props) {
  return (
    <button type={type} className={buttonClass(variant, className)} disabled={disabled || loading} aria-busy={loading || undefined} {...rest}>
      {loading ? <Spinner size={16} /> : icon}
      {children}
    </button>
  );
}
