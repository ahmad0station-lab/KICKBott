import { KIND_LABEL, formatDateTime, relativeTime } from '../lib/format';
import type { Deletion } from '../lib/api';
import { StatusBadge } from './StatusBadge';

/** Deleted messages: cards on phones, a table from `md` up. */
export function DeletionList({ rows }: { rows: Deletion[] }) {
  return (
    <>
      <ul className="flex flex-col gap-2 md:hidden">
        {rows.map((r) => (
          <li key={r.id} className="rounded-md bg-surface-2 p-3">
            <div className="flex items-center justify-between gap-2">
              <span className="font-bold" dir="auto">{r.senderUsername}</span>
              <time dateTime={r.createdAt} title={formatDateTime(r.createdAt)} className="text-sm text-text-muted">
                {relativeTime(r.createdAt)}
              </time>
            </div>
            <p className="mt-1 break-words" dir="auto">{r.content}</p>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-text-muted">
              <span>
                {KIND_LABEL[r.entryKind]}: <span className="font-semibold text-text" dir="auto">{r.entryValue}</span>
              </span>
              <Outcome row={r} />
            </div>
          </li>
        ))}
      </ul>

      <div className="hidden overflow-x-auto md:block">
        <table className="w-full text-start text-sm">
          <thead className="text-text-muted">
            <tr className="border-b border-border">
              <th scope="col" className="py-2 pe-3 text-start font-semibold">الوقت</th>
              <th scope="col" className="py-2 pe-3 text-start font-semibold">اليوزر</th>
              <th scope="col" className="py-2 pe-3 text-start font-semibold">الرسالة</th>
              <th scope="col" className="py-2 pe-3 text-start font-semibold">اتمسكت بسبب</th>
              <th scope="col" className="py-2 text-start font-semibold">النتيجة</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-b border-border/60 align-top last:border-0">
                <td className="whitespace-nowrap py-3 pe-3 text-text-muted">
                  <time dateTime={r.createdAt} title={formatDateTime(r.createdAt)}>{relativeTime(r.createdAt)}</time>
                </td>
                <td className="py-3 pe-3 font-bold" dir="auto">{r.senderUsername}</td>
                <td className="max-w-md break-words py-3 pe-3" dir="auto">{r.content}</td>
                <td className="py-3 pe-3">
                  <span className="text-text-muted">{KIND_LABEL[r.entryKind]}: </span>
                  <span className="font-semibold" dir="auto">{r.entryValue}</span>
                </td>
                <td className="py-3"><Outcome row={r} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function Outcome({ row }: { row: Deletion }) {
  if (row.status === 'deleted') return <StatusBadge tone="ok">اتمسحت</StatusBadge>;
  return (
    <span className="inline-flex flex-col gap-1">
      <StatusBadge tone="bad">ما اتمسحتش</StatusBadge>
      {row.error && <span className="text-xs text-danger" dir="auto">{failureReason(row.error)}</span>}
    </span>
  );
}

export function failureReason(error: string): string {
  if (error === 'not_logged_in' || error === 'needs_login') return 'الحساب مش مربوط بكيك';
  if (/forbidden|403/i.test(error)) return 'الحساب مش مود في القناة';
  return error;
}
