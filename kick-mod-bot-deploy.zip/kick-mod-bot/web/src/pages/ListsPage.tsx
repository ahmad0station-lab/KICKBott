import { useMemo, useState, type FormEvent } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus, Search, Trash2, X } from 'lucide-react';
import { api, errorMessage, type AddResult, type EntryKind, type MatchMode, type Principal } from '../lib/api';
import { can, listPermission } from '../lib/permissions';
import { PageHeader } from '../components/PageHeader';
import { formatNumber } from '../lib/format';
import { Tabs } from '../components/Tabs';
import { Panel } from '../components/Panel';
import { Button } from '../components/Button';
import { EmptyState, ErrorState } from '../components/States';
import { Spinner } from '../components/Spinner';

const KINDS: { id: EntryKind; label: string; hint: string; empty: string }[] = [
  { id: 'word', label: 'شتايم', hint: 'أي رسالة فيها كلمة من دول هتتمسح.', empty: 'مفيش شتايم في القايمة' },
  { id: 'name', label: 'أسماء', hint: 'أي رسالة فيها اسم من دول هتتمسح. ينفع تكتب الاسم كامل (مثلًا «محمد منصور»).', empty: 'مفيش أسماء ممنوعة لسه' },
  { id: 'allow', label: 'مسموح', hint: 'كلمات عادية جواها شتيمة بالصدفة. البوت عمره ما هيمسح رسالة بسببها.', empty: 'مفيش كلمات مسموحة لسه' },
];

const SKIP_REASON = { duplicate: 'موجودة قبل كده', empty: 'فاضية بعد التنضيف' } as const;

export function ListsPage({ user }: { user: Principal }) {
  const allowed = KINDS.filter((k) => can(user, listPermission(k.id)));
  const [picked, setKind] = useState<EntryKind>(allowed[0]?.id ?? 'word');
  const kind = allowed.some((k) => k.id === picked) ? picked : (allowed[0]?.id ?? 'word');
  const meta = KINDS.find((k) => k.id === kind)!;

  return (
    <div className="flex flex-col gap-4">
      <PageHeader title="القوايم" description="الكلمات والأسماء اللي البوت بيمسح أي رسالة فيها، والكلمات المسموحة." />
      {allowed.length > 1 && (
        <Tabs tabs={allowed.map(({ id, label }) => ({ id, label }))} value={kind} onChange={setKind} label="نوع القايمة" idPrefix="lists" />
      )}
      <div {...(allowed.length > 1 ? { id: "lists-panel", role: "tabpanel", "aria-labelledby": `lists-tab-${kind}` } : {})}>
        <ListEditor key={kind} kind={kind} hint={meta.hint} empty={meta.empty} />
      </div>
    </div>
  );
}

function ListEditor({ kind, hint, empty }: { kind: EntryKind; hint: string; empty: string }) {
  const qc = useQueryClient();
  const key = ['entries', kind];
  const entries = useQuery({ queryKey: key, queryFn: () => api.entries(kind) });
  const [text, setText] = useState('');
  const [mode, setMode] = useState<MatchMode>('word');
  const [result, setResult] = useState<AddResult | null>(null);
  const [query, setQuery] = useState('');
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const add = useMutation({
    mutationFn: (values: string[]) => api.addEntries(kind, values, mode),
    onSuccess: (r) => {
      setResult(r);
      if (r.added.length) setText('');
      void qc.invalidateQueries({ queryKey: key });
    },
  });

  const remove = useMutation({
    mutationFn: api.deleteEntry,
    onSuccess: () => {
      setConfirmId(null);
      void qc.invalidateQueries({ queryKey: key });
    },
  });

  const values = text.split('\n').map((v) => v.trim()).filter(Boolean);
  const submit = (e: FormEvent) => {
    e.preventDefault();
    setResult(null);
    if (values.length) add.mutate(values);
  };

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = entries.data?.entries ?? [];
    return q ? list.filter((e) => e.value.toLowerCase().includes(q) || e.normalized.includes(q)) : list;
  }, [entries.data, query]);

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
      <Panel title="ضيف للقايمة">
        <form onSubmit={submit} className="flex flex-col gap-3">
          <p className="text-sm text-text-muted">{hint}</p>
          <label htmlFor={`add-${kind}`} className="font-semibold">
            كل سطر بند لوحده
          </label>
          <textarea
            id={`add-${kind}`}
            rows={4}
            value={text}
            onChange={(e) => setText(e.target.value)}
            aria-describedby={`add-${kind}-hint`}
            className="rounded-md border border-border bg-bg p-3 text-base"
            dir="auto"
          />
          {kind !== 'allow' && (
            <p id={`add-${kind}-hint`} className="text-sm text-text-muted">
              ضيف كمان الشكل الفرانكو أو الإنجليزي (مثلًا «7mar»).
            </p>
          )}

          {kind !== 'allow' && (
            <fieldset className="flex flex-col gap-2">
              <legend className="mb-1 font-semibold">طريقة المسك</legend>
              {(
                [
                  ['word', 'الكلمة نفسها', 'تمسك «حمار» و«الحمار» و«ياحمار» و«حمارين».'],
                  ['contains', 'جوه أي كلمة', 'تمسكها في أي حتة جوه الكلمة. استخدمها للكلمات الطويلة بس.'],
                ] as const
              ).map(([value, label, desc]) => (
                <label key={value} className="flex min-h-11 cursor-pointer items-start gap-3 rounded-md p-2 hover:bg-surface-2">
                  <input type="radio" name={`mode-${kind}`} value={value} checked={mode === value} onChange={() => setMode(value)} className="mt-1 size-4 accent-[rgb(var(--accent))]" />
                  <span>
                    <span className="block font-semibold">{label}</span>
                    <span className="block text-sm text-text-muted">{desc}</span>
                  </span>
                </label>
              ))}
            </fieldset>
          )}

          <Button type="submit" variant="primary" loading={add.isPending} disabled={!values.length} icon={<Plus size={18} aria-hidden />}>
            {values.length > 1 ? `ضيف ${formatNumber(values.length)} بنود` : 'ضيف'}
          </Button>

          {add.isError && <ErrorState error={add.error} />}
          {result && (
            <div role="status" className="flex flex-col gap-1 rounded-md bg-surface-2 p-3 text-sm">
              {result.added.length > 0 && <p className="font-semibold text-success">اتضاف {formatNumber(result.added.length)}.</p>}
              {result.skipped.map((s, i) => (
                <p key={`${s.value}-${i}`} className="text-text-muted">
                  <span className="font-semibold text-text" dir="auto">{s.value}</span>: {SKIP_REASON[s.reason]}
                </p>
              ))}
            </div>
          )}
        </form>
      </Panel>

      <Panel title={`القايمة (${formatNumber(entries.data?.entries.length ?? 0)})`}>
        <div className="relative mb-3">
          <Search size={18} className="pointer-events-none absolute start-3 top-1/2 -translate-y-1/2 text-text-muted" aria-hidden />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="دوّر في القايمة"
            aria-label="دوّر في القايمة"
            className="min-h-11 w-full rounded-md border border-border bg-bg ps-10 pe-3 text-base"
          />
        </div>

        {entries.isPending ? (
          <Spinner label="بيحمّل..." />
        ) : entries.isError ? (
          <ErrorState error={entries.error} onRetry={() => entries.refetch()} />
        ) : filtered.length === 0 ? (
          <EmptyState title={query ? 'مفيش حاجة بالاسم ده' : empty} hint={query ? undefined : 'اكتب كلمة في الخانة وداس «ضيف».'} />
        ) : (
          <ul className="flex max-h-[32rem] flex-col divide-y divide-border overflow-y-auto">
            {filtered.map((e) => (
              <li key={e.id} className="flex min-h-12 items-center justify-between gap-3 py-1">
                <span className="flex min-w-0 flex-col">
                  <span className="truncate font-semibold" dir="auto">{e.value}</span>
                  {e.mode === 'contains' && <span className="text-xs text-text-muted">جوه أي كلمة</span>}
                </span>
                {confirmId === e.id ? (
                  <span className="flex shrink-0 items-center gap-1">
                    <Button variant="danger" loading={remove.isPending} onClick={() => remove.mutate(e.id)}>
                      امسح
                    </Button>
                    <button
                      type="button"
                      onClick={() => setConfirmId(null)}
                      aria-label="الغي المسح"
                      className="inline-flex size-11 cursor-pointer items-center justify-center rounded-md text-text-muted hover:bg-surface-2"
                    >
                      <X size={18} aria-hidden />
                    </button>
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => setConfirmId(e.id)}
                    aria-label={`امسح ${e.value}`}
                    className="inline-flex size-11 shrink-0 cursor-pointer items-center justify-center rounded-md text-text-muted transition-colors duration-150 hover:bg-danger/10 hover:text-danger"
                  >
                    <Trash2 size={18} aria-hidden />
                  </button>
                )}
              </li>
            ))}
          </ul>
        )}
        {remove.isError && <p role="alert" className="mt-2 text-sm font-semibold text-danger">{errorMessage(remove.error)}</p>}
      </Panel>
    </div>
  );
}
