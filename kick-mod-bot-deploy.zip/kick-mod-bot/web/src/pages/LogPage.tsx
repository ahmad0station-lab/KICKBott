import { useEffect, useState } from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { ChevronLeft, ChevronRight, Search } from 'lucide-react';
import { api } from '../lib/api';
import { formatNumber } from '../lib/format';
import { Panel } from '../components/Panel';
import { PageHeader } from '../components/PageHeader';
import { Button } from '../components/Button';
import { DeletionList } from '../components/DeletionList';
import { EmptyState, ErrorState } from '../components/States';
import { Spinner } from '../components/Spinner';

const PAGE_SIZE = 25;

export function LogPage() {
  const [page, setPage] = useState(1);
  const [input, setInput] = useState('');
  const [user, setUser] = useState('');

  useEffect(() => {
    const t = setTimeout(() => {
      setUser(input.trim());
      setPage(1);
    }, 300);
    return () => clearTimeout(t);
  }, [input]);

  const q = useQuery({
    queryKey: ['deletions', page, user],
    queryFn: () => api.deletions({ page, pageSize: PAGE_SIZE, user: user || undefined }),
    placeholderData: keepPreviousData,
  });

  const pages = Math.max(1, Math.ceil((q.data?.total ?? 0) / PAGE_SIZE));

  return (
    <>
    <PageHeader title="السجل" description="كل رسالة البوت مسحها أو حاول يمسحها في آخر 30 يوم." />
    <Panel>
      <div className="relative mb-4 max-w-sm">
        <Search size={18} className="pointer-events-none absolute start-3 top-1/2 -translate-y-1/2 text-text-muted" aria-hidden />
        <input
          type="search"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="فلتر باليوزر"
          aria-label="فلتر باليوزر"
          className="min-h-11 w-full rounded-md border border-border bg-bg ps-10 pe-3 text-base"
        />
      </div>

      {q.isPending ? (
        <Spinner label="بيحمّل..." />
      ) : q.isError ? (
        <ErrorState error={q.error} onRetry={() => q.refetch()} />
      ) : q.data.rows.length === 0 ? (
        <EmptyState title={user ? `مفيش رسايل اتمسحت لـ «${user}»` : 'السجل فاضي'} hint={user ? undefined : 'السجل بيحتفظ بآخر 30 يوم.'} />
      ) : (
        <>
          <DeletionList rows={q.data.rows} />
          <nav aria-label="صفحات السجل" className="mt-4 flex items-center justify-between gap-2">
            <Button onClick={() => setPage((p) => p - 1)} disabled={page <= 1} icon={<ChevronRight size={18} aria-hidden />}>
              الأحدث
            </Button>
            <span className="text-sm text-text-muted">
              صفحة {formatNumber(page)} من {formatNumber(pages)} ({formatNumber(q.data.total)} رسالة)
            </span>
            <Button onClick={() => setPage((p) => p + 1)} disabled={page >= pages}>
              الأقدم
              <ChevronLeft size={18} aria-hidden />
            </Button>
          </nav>
        </>
      )}
    </Panel>
    </>
  );
}
