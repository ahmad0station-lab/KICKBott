import { useRef, useState, type FormEvent } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Pencil, Trash2, UserPlus, X } from 'lucide-react';
import { api, errorMessage, type Permission, type SeenMod, type TeamMember } from '../lib/api';
import { relativeTime } from '../lib/format';
import { TEMPLATES, templateOf } from '../lib/permissions';
import { PageHeader } from '../components/PageHeader';
import { Panel } from '../components/Panel';
import { Button } from '../components/Button';
import { Avatar } from '../components/Avatar';
import { StatusBadge } from '../components/StatusBadge';
import { PermissionChips, PermissionPicker } from '../components/PermissionPicker';
import { EmptyState, ErrorState } from '../components/States';
import { Spinner } from '../components/Spinner';
import type { ToastMessage } from '../components/Toast';

const TEAM_KEY = ['team'];

export function TeamPage({ onToast }: { onToast: (t: ToastMessage) => void }) {
  const team = useQuery({ queryKey: TEAM_KEY, queryFn: api.team });
  const formRef = useRef<HTMLInputElement>(null);
  const [prefill, setPrefill] = useState<SeenMod | null>(null);

  const pick = (s: SeenMod) => {
    setPrefill(s);
    requestAnimationFrame(() => formRef.current?.focus());
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="الفريق"
        description="ضيف المودز بيوزر كيك بتاعهم، واختار كل واحد يقدر يعمل إيه. انت كصاحب القناة عندك كل الصلاحيات دايمًا."
      />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
        <div className="flex flex-col gap-6">
          <AddMemberForm key={prefill?.kickUserId ?? 'blank'} inputRef={formRef} prefill={prefill} onDone={() => setPrefill(null)} onToast={onToast} />
          {team.data && team.data.suggestions.length > 0 && (
            <Panel title="مودز شفناهم في الشات">
              <p className="mb-3 text-sm text-text-muted">دول كتبوا في الشات وعندهم علامة مود، ولسه مش في الفريق.</p>
              <ul className="flex flex-col divide-y divide-border">
                {team.data.suggestions.map((s) => (
                  <li key={s.kickUserId} className="flex items-center justify-between gap-3 py-2">
                    <span className="flex min-w-0 items-center gap-3">
                      <Avatar name={s.username} src={s.picture} size="sm" />
                      <span className="min-w-0">
                        <span className="block truncate font-semibold" dir="auto">{s.username}</span>
                        <span className="block text-xs text-text-muted">آخر ظهور {relativeTime(s.lastSeenAt)}</span>
                      </span>
                    </span>
                    <Button onClick={() => pick(s)} icon={<UserPlus size={16} aria-hidden />}>
                      ضيف
                    </Button>
                  </li>
                ))}
              </ul>
            </Panel>
          )}
        </div>

        <Panel title={`أعضاء الفريق${team.data ? ` (${team.data.members.length})` : ''}`}>
          {team.isPending ? (
            <Spinner label="بيحمّل..." />
          ) : team.isError ? (
            <ErrorState error={team.error} onRetry={() => void team.refetch()} />
          ) : team.data.members.length === 0 ? (
            <EmptyState title="لسه مفيش حد في الفريق" hint="ضيف أول مود من الخانة اللي جنبك. أول ما يدخل بحساب كيك هيلاقي الصلاحيات اللي اخترتها." />
          ) : (
            <ul className="flex flex-col divide-y divide-border">
              {team.data.members.map((m) => (
                <MemberRow key={m.id} member={m} onToast={onToast} />
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </div>
  );
}

function AddMemberForm({
  prefill,
  inputRef,
  onDone,
  onToast,
}: {
  prefill: SeenMod | null;
  inputRef: React.RefObject<HTMLInputElement>;
  onDone: () => void;
  onToast: (t: ToastMessage) => void;
}) {
  const qc = useQueryClient();
  const [username, setUsername] = useState(prefill?.username ?? '');
  const [permissions, setPermissions] = useState<Permission[]>([...TEMPLATES[1]!.permissions]);

  const add = useMutation({
    mutationFn: () => api.addMember({ username: username.trim(), permissions, kickUserId: prefill?.kickUserId }),
    onSuccess: ({ member }) => {
      onToast({ tone: 'success', text: `${member.username} اتضاف للفريق.` });
      setUsername('');
      onDone();
      void qc.invalidateQueries({ queryKey: TEAM_KEY });
    },
  });

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (username.trim()) add.mutate();
  };

  return (
    <Panel title="ضيف مود">
      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        <div>
          <label htmlFor="member-username" className="block font-semibold">
            يوزر كيك
          </label>
          <input
            id="member-username"
            ref={inputRef}
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoComplete="off"
            spellCheck={false}
            dir="ltr"
            placeholder="ahmed_mod"
            aria-describedby="member-username-hint"
            className="mt-2 block min-h-11 w-full rounded-md border border-border bg-bg px-3 text-base"
          />
          <p id="member-username-hint" className="mt-1 text-xs text-text-muted">
            اليوزر زي ما هو مكتوب في رابط قناته على كيك. أول ما يدخل اللوحة بحسابه هيترتبط بيه.
          </p>
        </div>
        <PermissionPicker value={permissions} onChange={setPermissions} idPrefix="new" />
        {add.isError && (
          <p role="alert" className="text-sm font-semibold text-danger">
            {errorMessage(add.error)}
          </p>
        )}
        <Button type="submit" variant="primary" loading={add.isPending} disabled={!username.trim()} icon={<UserPlus size={18} aria-hidden />}>
          ضيف للفريق
        </Button>
      </form>
    </Panel>
  );
}

function MemberRow({ member, onToast }: { member: TeamMember; onToast: (t: ToastMessage) => void }) {
  const qc = useQueryClient();
  const [editing, setEditing] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [draft, setDraft] = useState<Permission[]>(member.permissions);

  const save = useMutation({
    mutationFn: () => api.updateMember(member.id, draft),
    onSuccess: () => {
      setEditing(false);
      onToast({ tone: 'success', text: `صلاحيات ${member.username} اتحدّثت.` });
      void qc.invalidateQueries({ queryKey: TEAM_KEY });
    },
  });

  const remove = useMutation({
    mutationFn: () => api.removeMember(member.id),
    onSuccess: () => {
      onToast({ tone: 'success', text: `${member.username} اتشال من الفريق.` });
      void qc.invalidateQueries({ queryKey: TEAM_KEY });
    },
  });

  const role = templateOf(member.permissions) ?? 'صلاحيات مخصصة';

  return (
    <li className="py-4 first:pt-0 last:pb-0">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <Avatar name={member.username} src={member.picture} />
          <div className="min-w-0">
            <p className="truncate font-bold" dir="ltr">{member.username}</p>
            <p className="text-sm text-text-muted">{role}</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {member.lastLoginAt ? (
            <span className="text-xs text-text-muted">دخل {relativeTime(member.lastLoginAt)}</span>
          ) : (
            <StatusBadge tone="warn">لسه ما دخلش</StatusBadge>
          )}
        </div>
      </div>

      {editing ? (
        <div className="mt-3 rounded-md border border-border p-3">
          <PermissionPicker value={draft} onChange={setDraft} idPrefix={`m${member.id}`} />
          {save.isError && <p role="alert" className="mt-2 text-sm font-semibold text-danger">{errorMessage(save.error)}</p>}
          <div className="mt-3 flex flex-wrap gap-2">
            <Button variant="primary" loading={save.isPending} onClick={() => save.mutate()}>
              احفظ الصلاحيات
            </Button>
            <Button
              variant="ghost"
              onClick={() => {
                setDraft(member.permissions);
                setEditing(false);
              }}
            >
              الغي
            </Button>
          </div>
        </div>
      ) : (
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <PermissionChips value={member.permissions} />
          <div className="flex items-center gap-1">
            {confirming ? (
              <>
                <Button variant="danger" loading={remove.isPending} onClick={() => remove.mutate()}>
                  أيوه، شيله
                </Button>
                <button
                  type="button"
                  onClick={() => setConfirming(false)}
                  aria-label="الغي الشيل"
                  className="inline-flex size-11 cursor-pointer items-center justify-center rounded-md text-text-muted hover:bg-surface-2"
                >
                  <X size={18} aria-hidden />
                </button>
              </>
            ) : (
              <>
                <Button
                  variant="ghost"
                  onClick={() => {
                    setDraft(member.permissions);
                    setEditing(true);
                  }}
                  icon={<Pencil size={16} aria-hidden />}
                >
                  عدّل
                </Button>
                <button
                  type="button"
                  onClick={() => setConfirming(true)}
                  aria-label={`شيل ${member.username} من الفريق`}
                  className="inline-flex size-11 cursor-pointer items-center justify-center rounded-md text-text-muted transition-colors duration-150 hover:bg-danger/10 hover:text-danger"
                >
                  <Trash2 size={18} aria-hidden />
                </button>
              </>
            )}
          </div>
        </div>
      )}
      {remove.isError && <p role="alert" className="mt-2 text-sm font-semibold text-danger">{errorMessage(remove.error)}</p>}
    </li>
  );
}
