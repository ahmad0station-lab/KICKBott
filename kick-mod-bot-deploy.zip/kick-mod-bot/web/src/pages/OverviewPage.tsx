import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Settings as SettingsIcon } from 'lucide-react';
import { api, errorMessage, type Principal, type Settings, type Status } from '../lib/api';
import { formatNumber, relativeTime } from '../lib/format';
import { can } from '../lib/permissions';
import { STATUS_KEY } from '../hooks/useAuth';
import { Panel } from '../components/Panel';
import { StatusBadge } from '../components/StatusBadge';
import { Switch } from '../components/Switch';
import { Button } from '../components/Button';
import { DeletionList } from '../components/DeletionList';
import { EmptyState, ErrorState } from '../components/States';
import { Spinner } from '../components/Spinner';
import type { ToastMessage } from '../components/Toast';

type Tone = 'ok' | 'warn' | 'bad';
type Props = { user: Principal; onToast: (t: ToastMessage) => void; onNavigate: (p: 'settings') => void };

function headline(s: Status): { text: string; tone: Tone } {
  if (s.auth === 'needs_login') return { text: 'البوت محتاج حساب كيك يمسح بيه', tone: 'bad' };
  if (!s.enabled) return { text: 'البوت متوقف مؤقتًا', tone: 'warn' };
  if (!s.subscription.ok && s.subscription.checkedAt) return { text: 'البوت مش بيستقبل رسايل الشات', tone: 'bad' };
  return { text: 'البوت شغال وبيراقب الشات', tone: 'ok' };
}

const TONE_DOT: Record<Tone, string> = { ok: 'bg-success', warn: 'bg-warning', bad: 'bg-danger' };

export function OverviewPage({ user, onToast, onNavigate }: Props) {
  const qc = useQueryClient();
  const status = useQuery({ queryKey: STATUS_KEY, queryFn: api.status, refetchInterval: 15_000 });
  const canControl = can(user, 'bot.control');
  const canLog = can(user, 'log.view');

  const settings = useMutation({
    mutationFn: (patch: Partial<Settings>) => api.settings(patch),
    onMutate: async (patch) => {
      await qc.cancelQueries({ queryKey: STATUS_KEY });
      const prev = qc.getQueryData<Status>(STATUS_KEY);
      if (prev) qc.setQueryData<Status>(STATUS_KEY, { ...prev, ...patch });
      return { prev };
    },
    onError: (err, _patch, ctx) => {
      if (ctx?.prev) qc.setQueryData(STATUS_KEY, ctx.prev);
      onToast({ tone: 'error', text: errorMessage(err) });
    },
    onSettled: () => qc.invalidateQueries({ queryKey: STATUS_KEY }),
  });

  const recent = useQuery({
    queryKey: ['deletions', 'recent'],
    queryFn: () => api.deletions({ page: 1, pageSize: 10 }),
    refetchInterval: 15_000,
    enabled: canLog,
  });

  if (status.isPending) return <Spinner label="بيحمّل..." />;
  if (status.isError) return <ErrorState error={status.error} onRetry={() => void status.refetch()} />;

  const s = status.data;
  const h = headline(s);

  return (
    <div className="flex flex-col gap-6">
      <section aria-labelledby="bot-headline" className="rounded-lg border border-border bg-surface p-5 shadow-panel sm:p-6">
        <p className="text-sm text-text-muted">أهلًا {user.name}</p>
        <h1 id="bot-headline" className="mt-1 flex items-baseline gap-3 text-status text-balance">
          <span className={`inline-block size-3 shrink-0 translate-y-[-0.1em] rounded-full ${TONE_DOT[h.tone]}`} aria-hidden />
          {h.text}
        </h1>

        {s.auth === 'needs_login' &&
          (user.kind === 'owner' ? (
            <Button variant="primary" className="mt-4" onClick={() => onNavigate('settings')} icon={<SettingsIcon size={18} aria-hidden />}>
              اربط حساب البوت من الإعدادات
            </Button>
          ) : (
            <p className="mt-3 text-sm text-text-muted">صاحب القناة لازم يربط حساب البوت من صفحة الإعدادات.</p>
          ))}

        <dl className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Stat
            label="اتمسح النهارده"
            value={s.deletedToday === 0 ? 'ولا رسالة' : formatNumber(s.deletedToday)}
            hint={s.deletedToday === 0 ? undefined : 'رسالة'}
          />
          <Stat
            label="حساب البوت"
            value={s.account ? s.account.username : 'مش مربوط'}
            badge={<StatusBadge tone={s.auth === 'connected' ? 'ok' : 'bad'}>{s.auth === 'connected' ? 'متصل' : 'محتاج ربط'}</StatusBadge>}
          />
          <Stat
            label="آخر رسالة وصلت"
            value={s.lastEventAt ? relativeTime(s.lastEventAt) : 'لسه'}
            badge={
              <StatusBadge tone={s.subscription.ok ? 'ok' : s.subscription.checkedAt ? 'bad' : 'warn'}>
                {s.subscription.ok ? 'الاستقبال شغال' : s.subscription.checkedAt ? 'الاستقبال واقف' : 'لسه ما اتفحصش'}
              </StatusBadge>
            }
          />
        </dl>
      </section>

      <Panel title="التحكم في البوت">
        {!canControl && <p className="mb-3 text-sm text-text-muted">الإعدادات دي للمشاهدة بس. صاحب القناة يقدر يديك صلاحية «التحكم في البوت».</p>}
        <div className="flex flex-col divide-y divide-border">
          <div className="pb-3">
            <Switch
              label="البوت شغال"
              hint="لو قفلته، البوت هيسيب كل الرسايل لحد ما يتشغل تاني."
              checked={s.enabled}
              disabled={!canControl || settings.isPending}
              onChange={(enabled) => settings.mutate({ enabled })}
            />
          </div>
          <div className="pt-3">
            <Switch
              label="سيب رسايل المودز"
              hint="رسايل صاحب القناة عمرها ما بتتمسح. ده بيتحكم في رسايل المودز بس."
              checked={s.exemptMods}
              disabled={!canControl || settings.isPending}
              onChange={(exemptMods) => settings.mutate({ exemptMods })}
            />
          </div>
        </div>
      </Panel>

      {canLog && (
        <Panel title="آخر الرسايل اللي اتمسحت">
          {recent.isPending ? (
            <Spinner label="بيحمّل..." />
          ) : recent.isError ? (
            <ErrorState error={recent.error} onRetry={() => void recent.refetch()} />
          ) : recent.data.rows.length === 0 ? (
            <EmptyState title="لسه ما اتمسحش أي رسالة" hint="أول ما حد يكتب كلمة من القوايم هتلاقيها هنا." />
          ) : (
            <DeletionList rows={recent.data.rows} />
          )}
        </Panel>
      )}
    </div>
  );
}

function Stat({ label, value, hint, badge }: { label: string; value: string; hint?: string; badge?: React.ReactNode }) {
  return (
    <div className="rounded-md bg-surface-2 px-4 py-3">
      <dt className="text-sm text-text-muted">{label}</dt>
      <dd className="mt-1 flex flex-wrap items-baseline gap-x-2 gap-y-1">
        <span className="truncate text-xl font-bold" dir="auto">{value}</span>
        {hint && <span className="text-sm text-text-muted">{hint}</span>}
      </dd>
      {badge && <dd className="mt-2">{badge}</dd>}
    </div>
  );
}
