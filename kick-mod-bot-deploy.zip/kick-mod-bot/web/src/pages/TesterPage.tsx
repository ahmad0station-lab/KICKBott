import { useState, type FormEvent } from 'react';
import { useMutation } from '@tanstack/react-query';
import { FlaskConical } from 'lucide-react';
import { api } from '../lib/api';
import { KIND_LABEL } from '../lib/format';
import { Panel } from '../components/Panel';
import { PageHeader } from '../components/PageHeader';
import { Button } from '../components/Button';
import { ErrorState } from '../components/States';

export function TesterPage() {
  const [text, setText] = useState('');
  const test = useMutation({ mutationFn: api.test });

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (text.trim()) test.mutate(text);
  };

  const r = test.data;

  return (
    <>
    <PageHeader title="التجربة" description="اكتب أي رسالة وشوف البوت هيمسحها ولا لأ، من غير ما تكتبها في الشات." />
    <Panel>
      <form onSubmit={submit} className="flex flex-col gap-3 sm:flex-row sm:items-end">
        <label className="flex flex-1 flex-col gap-2">
          <span className="font-semibold">اكتب رسالة زي ما حد هيكتبها في الشات</span>
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="min-h-11 rounded-md border border-border bg-bg px-3 text-base"
            dir="auto"
            maxLength={500}
          />
        </label>
        <Button type="submit" variant="primary" loading={test.isPending} disabled={!text.trim()} icon={<FlaskConical size={18} aria-hidden />}>
          جرّب
        </Button>
      </form>

      {test.isError && <div className="mt-4"><ErrorState error={test.error} /></div>}

      {r && (
        <div role="status" className="mt-5 flex flex-col gap-3">
          <p className={`text-2xl font-extrabold ${r.matched ? 'text-danger' : 'text-success'}`}>
            {r.matched ? 'هتتمسح' : 'مش هتتمسح'}
          </p>
          {r.matched && (
            <p>
              مسكها البند <span className="font-bold" dir="auto">«{r.entry.value}»</span> من قايمة {KIND_LABEL[r.entry.kind]}، في الكلمة{' '}
              <span className="font-bold" dir="auto">«{r.token}»</span>.
            </p>
          )}
          <div>
            <p className="text-sm text-text-muted">الرسالة بعد ما البوت نضّفها:</p>
            {r.tokens.length ? (
              <ul className="mt-2 flex flex-wrap gap-2">
                {r.tokens.map((t, i) => (
                  <li key={`${t}-${i}`} className="rounded-sm bg-surface-2 px-2 py-1 font-semibold" dir="auto">
                    {t}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-1 font-semibold">فاضية (إيموتس بس أو رموز)</p>
            )}
          </div>
        </div>
      )}
    </Panel>
    </>
  );
}
