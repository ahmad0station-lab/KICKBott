import { CircleAlert, LogIn, Mail, ShieldCheck } from 'lucide-react';
import { buttonClass } from '../components/Button';
import { ThemeToggle } from '../components/ThemeToggle';

const NOTICES: Record<string, string> = {
  denied: 'الحساب ده مش في فريق القناة. اطلب من صاحب القناة يضيف اليوزر بتاعك من صفحة «الفريق»، وبعدها ادخل تاني.',
  failed: 'الدخول ما كملش. ممكن تكون لغيت الموافقة أو الصفحة اتأخرت. جرّب تاني.',
};

export function LoginPage({ google, notice }: { google: boolean; notice: string | null }) {
  const message = notice ? NOTICES[notice] : null;

  return (
    <main className="relative flex min-h-dvh items-center justify-center px-4 py-10">
      <div className="absolute end-4 top-4">
        <ThemeToggle />
      </div>
      <div className="w-full max-w-sm">
        <div className="rounded-lg border border-border bg-surface p-6 shadow-panel sm:p-8">
          <span className="inline-flex size-11 items-center justify-center rounded-md bg-accent/15 text-accent-ink">
            <ShieldCheck size={24} aria-hidden />
          </span>
          <h1 className="mt-4 text-2xl font-bold tracking-tight">منصوركو بوت</h1>
          <p className="mt-1 text-text-muted">لوحة التحكم في فلتر الشات. ادخل بحساب كيك بتاعك.</p>

          {message && (
            <p role="alert" className="mt-5 flex gap-2 rounded-md bg-danger/10 p-3 text-sm font-semibold text-danger">
              <CircleAlert size={18} className="mt-0.5 shrink-0" aria-hidden />
              {message}
            </p>
          )}

          <a href="/auth/kick/login" className={buttonClass('primary', 'mt-6 w-full')}>
            <LogIn size={18} aria-hidden />
            ادخل بحساب كيك
          </a>

          {google && (
            <>
              <div className="my-5 flex items-center gap-3 text-xs text-text-muted" aria-hidden>
                <span className="h-px flex-1 bg-border" />
                أو
                <span className="h-px flex-1 bg-border" />
              </div>
              <a href="/auth/google/login" className={buttonClass('secondary', 'w-full')}>
                <Mail size={18} aria-hidden />
                ادخل بجوجل (لصاحب القناة بس)
              </a>
            </>
          )}
        </div>
        <p className="mt-4 text-center text-sm text-text-muted">كيك هيسألك توافق إن البوت يعرف اسمك وصورتك بس.</p>
      </div>
    </main>
  );
}
