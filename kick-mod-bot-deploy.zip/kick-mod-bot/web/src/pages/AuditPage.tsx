import { useState } from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { api, type AuditRow, type EntryKind } from '../lib/api';
import { formatDateTime, formatNumber, relativeTime } from '../lib/format';
import { PageHeader } from '../components/PageHeader';
import { Panel } from '../components/Panel';
import { Button } from '../components/Button';
import { Avatar } from '../components/Avatar';
import { EmptyState, ErrorState } from '../components/States';
import { Spinner } from '../components/Spinner';

const PAGE_SIZE = 30;
const LIST_NAME: Record<EntryKind, string> = { word: 'الشتايم', name: 'الأسماء', allow: 'المسموح' };

const str = (v: unknown) => (typeof v === 'string' ? v : '');
const listName = (v: unknown) => LIST_NAME[(v as EntryKind) in LIST_NAME ? (v as EntryKind) : 'word'];

/** One readable sentence per change. */
export function describe(row: AuditRow): string {
  const d = row.detail;
  switch (row.action) {
    case 'entry.add': {
      const values = Array.isArray(d.values) ? (d.values as string[]) : [];
      const shown = values.slice(0, 3).map((v) => `«${v}»`).join('، ');
      const more = values.length > 3 ? ` و${formatNumber(values.length - 3)} كمان` : '';
      return `ضاف ${shown}${more} لقايمة ${listName(d.kind)}`;
    }
    case 'entry.delete':
      return `شال «${str(d.value)}» من قايمة ${listName(d.kind)}`;
    case 'settings.update': {
      const parts: string[] = [];
      if (d.enabled === true) parts.push('شغّل البوت');
      if (d.enabled === false) parts.push('وقّف البوت');
      if (d.exemptMods === true) parts.push('خلّى البوت يسيب رسايل المودز');
      if (d.exemptMods === false) parts.push('خلّى البوت يفلتر رسايل المودز كمان');
      return parts.join('، ') || 'غيّر إعدادات البوت';
    }
    case 'team.add':
      return `ضاف ${str(d.username)} للفريق`;
    case 'team.update':
      return `غيّر صلاحيات ${str(d.username)}`;
    case 'team.remove':
      return `شال ${str(d.username)} من الفريق`;
    case 'bot.link':
      return `ربط حساب البوت ${str(d.username)}`;
    default:
      return row.action;
  }
}

export function AuditPage() {
  const [page, setPage] = useState(1);
  const q = useQuery({ queryKey: ['audit', page], queryFn: () => api.audit(page), placeholderData: keepPreviousData });
  const pages = Math.max(1, Math.ceil((q.data?.total ?? 0) / PAGE_SIZE));

  return (
    <>
      <PageHeader title="سجل التعديلات" description="مين غيّر إيه في القوايم والإعدادات والفريق، في آخر 30 يوم." />
      <Panel>
        {q.isPending ? (
          <Spinner label="بيحمّل..." />
        ) : q.isError ? (
          <ErrorState error={q.error} onRetry={() => void q.refetch()} />
        ) : q.data.rows.length === 0 ? (
          <EmptyState title="مفيش تعديلات لسه" hint="أي إضافة أو مسح أو تغيير في الإعدادات هيظهر هنا باسم اللي عمله." />
        ) : (
          <>
            <ol className="flex flex-col divide-y divide-border">
              {q.data.rows.map((r) => (
                <li key={r.id} className="flex items-start gap-3 py-3 first:pt-0">
                  <Avatar name={r.actorName} src={r.actorPicture} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="break-words">
                      <span className="font-bold" dir="auto">{r.actorName}</span> {describe(r)}
                    </p>
                    <time dateTime={r.createdAt} title={formatDateTime(r.createdAt)} className="text-xs text-text-muted">
                      {relativeTime(r.createdAt)}
                    </time>
                  </div>
                </li>
              ))}
            </ol>
            {pages > 1 && (
              <nav aria-label="صفحات السجل" className="mt-4 flex items-center justify-between gap-2">
                <Button onClick={() => setPage((p) => p - 1)} disabled={page <= 1} icon={<ChevronRight size={18} aria-hidden />}>
                  الأحدث
                </Button>
                <span className="text-sm text-text-muted">
                  صفحة {formatNumber(page)} من {formatNumber(pages)}
                </span>
                <Button onClick={() => setPage((p) => p + 1)} disabled={page >= pages}>
                  الأقدم
                  <ChevronLeft size={18} aria-hidden />
                </Button>
              </nav>
            )}
          </>
        )}
      </Panel>
    </>
  );
}
