import { useQuery } from '@tanstack/react-query';
import { Bot, KeyRound, Link2 } from 'lucide-react';
import { api } from '../lib/api';
import { relativeTime } from '../lib/format';
import { STATUS_KEY, ME_KEY } from '../hooks/useAuth';
import { PageHeader } from '../components/PageHeader';
import { Panel } from '../components/Panel';
import { StatusBadge } from '../components/StatusBadge';
import { buttonClass } from '../components/Button';
import { ErrorState } from '../components/States';
import { Spinner } from '../components/Spinner';

export function SettingsPage() {
  const status = useQuery({ queryKey: STATUS_KEY, queryFn: api.status, refetchInterval: 15_000 });
  const me = useQuery({ queryKey: ME_KEY, queryFn: api.me });

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="الإعدادات" description="الحساب اللي البوت بيمسح بيه الرسايل، وطرق دخولك للوحة." />

      <Panel title="حساب البوت">
        {status.isPending ? (
          <Spinner label="بيحمّل..." />
        ) : status.isError ? (
          <ErrorState error={status.error} onRetry={() => void status.refetch()} />
        ) : (
          <div className="flex flex-col gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <span className="inline-flex size-10 items-center justify-center rounded-md bg-surface-2 text-text-muted">
                <Bot size={20} aria-hidden />
              </span>
              <div className="min-w-0 flex-1">
                <p className="font-bold" dir="auto">{status.data.account?.username ?? 'مفيش حساب مربوط'}</p>
                <p className="text-sm text-text-muted">
                  {status.data.subscription.checkedAt
                    ? `آخر فحص للاستقبال ${relativeTime(status.data.subscription.checkedAt)}`
                    : 'الاستقبال لسه ما اتفحصش'}
                </p>
              </div>
              <StatusBadge tone={status.data.auth === 'connected' ? 'ok' : 'bad'}>
                {status.data.auth === 'connected' ? 'متصل' : 'محتاج ربط'}
              </StatusBadge>
            </div>
            {status.data.subscription.error && (
              <p role="alert" className="rounded-md bg-danger/10 p-3 text-sm font-semibold text-danger" dir="auto">
                مشكلة في استقبال رسايل الشات: {status.data.subscription.error}
              </p>
            )}
            <p className="max-w-2xl text-sm text-text-muted">
              الحساب ده هو اللي بيمسح الرسايل. ينفع يكون حسابك، أو حساب بوت منفصل متعمل مود في قناتك. وانت بتربط، سجّل دخول في كيك بالحساب اللي عايزه.
            </p>
            <a href="/auth/kick/link" className={buttonClass(status.data.auth === 'connected' ? 'secondary' : 'primary', 'self-start')}>
              <Link2 size={18} aria-hidden />
              {status.data.auth === 'connected' ? 'غيّر حساب البوت' : 'اربط حساب البوت'}
            </a>
          </div>
        )}
      </Panel>

      <Panel title="الدخول للوحة">
        <ul className="flex flex-col gap-3 text-sm">
          <li className="flex items-start gap-3">
            <KeyRound size={18} className="mt-0.5 shrink-0 text-text-muted" aria-hidden />
            <span>
              <span className="block font-semibold">حساب كيك</span>
              <span className="text-text-muted">انت والمودز اللي في الفريق بتدخلوا بزرار «ادخل بحساب كيك».</span>
            </span>
          </li>
          <li className="flex items-start gap-3">
            <KeyRound size={18} className="mt-0.5 shrink-0 text-text-muted" aria-hidden />
            <span>
              <span className="flex items-center gap-2 font-semibold">
                الدخول الاحتياطي بجوجل
                <StatusBadge tone={me.data?.google ? 'ok' : 'warn'}>{me.data?.google ? 'مفعّل' : 'مش متظبط'}</StatusBadge>
              </span>
              <span className="text-text-muted">
                {me.data?.google
                  ? 'لو كيك وقع، تقدر تدخل بإيميلك على جوجل. الإيميل ده بس هو اللي مسموح.'
                  : 'عشان تفعّله، حط GOOGLE_CLIENT_ID و GOOGLE_CLIENT_SECRET و OWNER_EMAIL في إعدادات Railway. الخطوات في ملف README.'}
              </span>
            </span>
          </li>
        </ul>
      </Panel>
    </div>
  );
}
