import type { Config } from 'tailwindcss';

const token = (name: string) => `rgb(var(--${name}) / <alpha-value>)`;

export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        bg: token('bg'),
        surface: token('surface'),
        'surface-2': token('surface-2'),
        border: token('border'),
        text: token('text'),
        'text-muted': token('text-muted'),
        accent: token('accent'),
        'accent-ink': token('accent-ink'),
        'on-accent': token('on-accent'),
        danger: token('danger'),
        warning: token('warning'),
        success: token('success'),
      },
      fontFamily: { sans: ['"IBM Plex Sans Arabic"', 'system-ui', 'sans-serif'] },
      borderRadius: { sm: '6px', md: '10px', lg: '14px' },
      boxShadow: { panel: '0 1px 0 rgb(var(--border) / 1), 0 8px 24px -12px rgb(var(--shadow) / 0.35)' },
      fontSize: {
        status: ['clamp(1.5rem, 1.1rem + 1.6vw, 2.125rem)', { lineHeight: '1.3', fontWeight: '700' }],
      },
    },
  },
  plugins: [],
} satisfies Config;
